<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>AbstractWidgetList</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="52"/>
        <source>Add New</source>
        <translation>新增</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="103"/>
        <source>Move Up</source>
        <translation>上移</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="104"/>
        <source>Move Down</source>
        <translation>下移</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="105"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
</context>
<context>
    <name>AcceptTool</name>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="31"/>
        <source>Accept</source>
        <translation>接受</translation>
    </message>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="41"/>
        <source>Accept the capture</source>
        <translation>接受捕获的截图</translation>
    </message>
</context>
<context>
    <name>AppLauncher</name>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="23"/>
        <source>App Launcher</source>
        <translation>应用启动器</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="33"/>
        <source>Choose an app to open the capture</source>
        <translation>选择一个应用打开此截图</translation>
    </message>
</context>
<context>
    <name>AppLauncherWidget</name>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="50"/>
        <source>Open With</source>
        <translation>用...打开</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="79"/>
        <source>Launch in terminal</source>
        <translation>在终端中启动</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="80"/>
        <source>Keep open after selection</source>
        <translation>选择后保持此窗口打开</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="116"/>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="150"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="150"/>
        <source>Unable to launch in terminal.</source>
        <translation>无法在终端中启动。</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="116"/>
        <source>Unable to write in</source>
        <translation>无法写入</translation>
    </message>
</context>
<context>
    <name>ArrowTool</name>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="77"/>
        <source>Arrow</source>
        <translation>箭头</translation>
    </message>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="87"/>
        <source>Set the Arrow as the paint tool</source>
        <translation>选择箭头作为绘画工具</translation>
    </message>
</context>
<context>
    <name>BlurTool</name>
    <message>
        <source>Blur</source>
        <translation type="vanished">模糊</translation>
    </message>
    <message>
        <source>Set Blur as the paint tool</source>
        <translation type="vanished">选择模糊作为绘画工具</translation>
    </message>
</context>
<context>
    <name>CaptureLauncher</name>
    <message>
        <source>&lt;b&gt;Capture Mode&lt;/b&gt;</source>
        <translation type="vanished">&lt;b&gt;捕获模式&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="33"/>
        <source>Rectangular Region</source>
        <translation>方形区域</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="39"/>
        <source>Full Screen (Current Display)</source>
        <translation>全屏（当前屏幕）</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="42"/>
        <source>Full Screen (All Monitors)</source>
        <translation>全屏（所有显示器）</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="45"/>
        <source>No Delay</source>
        <translation>无延迟</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="53"/>
        <source> second</source>
        <translation> 秒</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="100"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="184"/>
        <location filename="../../src/widgets/capturelauncher.cpp" line="53"/>
        <source> seconds</source>
        <translation> 秒</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="165"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="185"/>
        <source>Take new screenshot</source>
        <translation>获取新屏幕截图</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="66"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="180"/>
        <source>Area:</source>
        <translation>区域：</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="177"/>
        <source>Capture Launcher</source>
        <translation>捕获启动器</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="34"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="178"/>
        <source>TextLabel</source>
        <translation>文本标签</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="51"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="179"/>
        <source>Capture Mode</source>
        <translation>捕获模式</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="80"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="182"/>
        <source>Delay:</source>
        <translation>延迟：</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="93"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="183"/>
        <source>WxH+x+y</source>
        <translation>宽x高+x+y</translation>
    </message>
</context>
<context>
    <name>CaptureWidget</name>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="112"/>
        <source>Unable to capture screen</source>
        <translatorcomment>无法捕获屏幕</translatorcomment>
        <translation>无法捕获屏幕</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="456"/>
        <source>Mouse</source>
        <translation>鼠标</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="456"/>
        <source>Select screenshot area</source>
        <translation>选择截屏区域</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="470"/>
        <source>Mouse Wheel</source>
        <translation>鼠标滚轮</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="470"/>
        <source>Change tool size</source>
        <translation>改变工具大小</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="471"/>
        <source>Right Click</source>
        <translation>右键单击</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="471"/>
        <source>Show color picker</source>
        <translation>显示颜色选择器</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="473"/>
        <source>Open side panel</source>
        <translation>打开侧边栏</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="474"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="474"/>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="515"/>
        <source>Quit Capture</source>
        <translation>退出截图</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="516"/>
        <source>Are you sure you want to quit capture?</source>
        <translation>确定要退出截屏吗？</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="521"/>
        <source>Do not show this again</source>
        <translation>不再显示</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="727"/>
        <source>Flameshot has lost focus. Keyboard shortcuts won&apos;t work until you click somewhere.</source>
        <translation>火焰截图丢失了屏幕焦点。您需要点击一次屏幕才能正常使用键盘快捷键。</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="733"/>
        <source>Configuration error resolved. Launch `flameshot gui` again to apply it.</source>
        <translation>已解决配置文件错误。请再次运行 `flameshot gui` 命令以应用更改。</translation>
    </message>
    <message>
        <source>Select an area with the mouse, or press Esc to exit.
Press Enter to capture the screen.
Press Right Click to show the color picker.
Use the Mouse Wheel to change the thickness of your tool.
Press Space to open the side panel.</source>
        <translation type="vanished">用鼠标选择一个区域,或按 Esc 退出。
按 Enter 键捕捉屏幕。
按住鼠标右键显示颜色选择器。
使用鼠标滚轮来改变绘画工具的宽度。
按下空格键以打开侧边面板。</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="1167"/>
        <source>Tool Settings</source>
        <translation>工具设置</translation>
    </message>
</context>
<context>
    <name>CircleCountTool</name>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="68"/>
        <source>Circle Counter</source>
        <translation>圆圈计数</translation>
    </message>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="86"/>
        <source>Add an autoincrementing counter bubble</source>
        <translation>添加数字自动递增的计数圆圈</translation>
    </message>
</context>
<context>
    <name>CircleTool</name>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="20"/>
        <source>Circle</source>
        <translation>圆环</translation>
    </message>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="30"/>
        <source>Set the Circle as the paint tool</source>
        <translation>选择圆环作为绘画工具</translation>
    </message>
</context>
<context>
    <name>ColorDialog</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="19"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="312"/>
        <source>Select Color</source>
        <translation>选择颜色</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="60"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="313"/>
        <source>Saturation</source>
        <translation>饱和度</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="67"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="314"/>
        <source>Hue</source>
        <translation>色相</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="84"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="315"/>
        <source>Hex</source>
        <translation>Hex</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="91"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="316"/>
        <source>Blue</source>
        <translation>蓝</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="128"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="317"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="135"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="318"/>
        <source>Green</source>
        <translation>绿</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="142"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="319"/>
        <source>Alpha</source>
        <translation>透明</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="149"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="320"/>
        <source>Red</source>
        <translation>红</translation>
    </message>
</context>
<context>
    <name>ColorGrabWidget</name>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="58"/>
        <source>Accept color</source>
        <translation>接受颜色</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="58"/>
        <source>Enter or Left Click</source>
        <translation>回车或左键单击</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="59"/>
        <source>Precisely select color</source>
        <translation>精确选择颜色</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="59"/>
        <source>Hold Left Click</source>
        <translation>按住左键</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="60"/>
        <source>Toggle magnifier</source>
        <translation>切换放大镜</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="60"/>
        <source>Space or Right Click</source>
        <translation>空格键或右键单击</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="61"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="61"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>ColorPickerEditor</name>
    <message>
        <source>Select Preset:</source>
        <translation type="vanished">选择预设：</translation>
    </message>
    <message>
        <source>Select preset using the spinbox</source>
        <translation type="vanished">使用spinbox选择预设</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="40"/>
        <source>Edit Preset:</source>
        <translation>编辑预设：</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="45"/>
        <source>Enter color to update preset</source>
        <translation>输入颜色以更新预设</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="65"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="67"/>
        <source>Press button to update the selected preset</source>
        <translation>点击按钮以更新选中的预设</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="74"/>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="76"/>
        <source>Press button to delete the selected preset</source>
        <translation>按下按钮删除选定的预设</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="90"/>
        <source>Add Preset:</source>
        <translation>添加预设：</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="96"/>
        <source>Enter color manually or select it using the color-wheel</source>
        <translation>手动输入颜色或使用色轮选择颜色</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="106"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="107"/>
        <source>Press button to add preset</source>
        <translation>按下按钮添加预设</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="130"/>
        <location filename="../../src/config/colorpickereditor.cpp" line="147"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="131"/>
        <source>Unable to add preset. Maximum limit reached.</source>
        <translation>无法添加预设。达到最大限度。</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="148"/>
        <source>Unable to remove preset. Minimum limit reached.</source>
        <translation>无法删除预设。已达到最低限制。</translation>
    </message>
</context>
<context>
    <name>ConfigErrorDetails</name>
    <message>
        <location filename="../../src/config/configerrordetails.cpp" line="20"/>
        <source>Configuration errors</source>
        <translation>配置错误</translation>
    </message>
</context>
<context>
    <name>ConfigHandler</name>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="579"/>
        <source>Unrecognized setting: &apos;%1&apos;
</source>
        <translation>无法识别的设置：“%1”
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="587"/>
        <source>Unrecognized shortcut name: &apos;%1&apos;.
</source>
        <translation>无法识别的快捷键名称：“%1”
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="630"/>
        <source>Shortcut conflict: &apos;%1&apos; and &apos;%2&apos; have the same shortcut: %3
</source>
        <translation>快捷键冲突：“%1”和“%2”有同样的快捷键：%3
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="668"/>
        <source>Bad value in &apos;%1&apos;. Expected: %2
</source>
        <translation>“%1”使用了不正确的值，期望为：%2
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="717"/>
        <source>You have successfully resolved the configuration error.</source>
        <translation>您已成功解决配置文件错误。</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="740"/>
        <source>The configuration contains an error. Open configuration to resolve.</source>
        <translation>配置文件存在错误。请打开配置界面进行处理。</translation>
    </message>
    <message>
        <source>The configuration contains an error. Falling back to default.</source>
        <translation type="vanished">配置文件存在错误。已回退到使用默认配置。</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="794"/>
        <source>Bad config key &apos;%1&apos; in ConfigHandler. Please report this as a bug.</source>
        <translation>ConfigHandler 中存在错误的配置键“%1”。请向我们报告这个问题。</translation>
    </message>
</context>
<context>
    <name>ConfigResolver</name>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="14"/>
        <source>Resolve configuration errors</source>
        <translation>处理配置文件错误</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="50"/>
        <source>&lt;b&gt;You must resolve all errors before continuing:&lt;/b&gt;</source>
        <translation>&lt;b&gt;您必须解决所有错误才能继续：&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="61"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="63"/>
        <source>Reset to the default value.</source>
        <translation>重置为默认值。</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="77"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="79"/>
        <source>Remove this setting.</source>
        <translation>移除此项设置。</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="90"/>
        <source>Some keyboard shortcuts have conflicts.
This will NOT prevent flameshot from starting.
Please solve them manually in the configuration file.</source>
        <translation>一些键盘快捷键存在冲突。
这不会阻碍火焰截图程序的启动。
请在配置文件中手动解决这些问题。</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="112"/>
        <source>Resolve all</source>
        <translation>处理全部</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="113"/>
        <source>Resolve all listed errors.</source>
        <translation>处理全部列出的错误。</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="125"/>
        <source>Details</source>
        <translation>细节</translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="40"/>
        <source>Configuration</source>
        <translation>配置</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="68"/>
        <source>Interface</source>
        <translation>界面</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="78"/>
        <source>Filename Editor</source>
        <translation>文件名编辑器</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="59"/>
        <source>General</source>
        <translation>常规</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="87"/>
        <source>Shortcuts</source>
        <translation>快捷键</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="120"/>
        <source>Resolve</source>
        <translation>处理</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="124"/>
        <source>&lt;b&gt;Configuration file has errors. Resolve them before continuing.&lt;/b&gt;</source>
        <translation>&lt;b&gt;配置文件存在错误。请在继续操作前进行处理。&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>Controller</name>
    <message>
        <source>New version %1 is available</source>
        <translation type="vanished">新版本 %1 已经可用</translation>
    </message>
    <message>
        <source>You have the latest version</source>
        <translation type="vanished">您正在运行最新版本</translation>
    </message>
    <message>
        <source>Failed to get information about the latest version.</source>
        <translation type="vanished">获取最新版本信息时失败。</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">错误</translation>
    </message>
    <message>
        <source>Unable to close active modal widgets</source>
        <translation type="vanished">无法关闭活动模态组件</translation>
    </message>
    <message>
        <source>&amp;Take Screenshot</source>
        <translation type="vanished">进行截图(&amp;T)</translation>
    </message>
    <message>
        <source>&amp;Open Launcher</source>
        <translation type="vanished">打开启动器(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Configuration</source>
        <translation type="vanished">配置(&amp;C)</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation type="vanished">关于(&amp;A)</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation type="vanished">检查更新</translation>
    </message>
    <message>
        <source>&amp;Latest Uploads</source>
        <translation type="vanished">最近的上传(&amp;L)</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">链接已复制到剪贴板。</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="vanished">信息(&amp;I)</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="vanished">退出(&amp;Q)</translation>
    </message>
</context>
<context>
    <name>CopyTool</name>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="24"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="34"/>
        <source>Copy selection to clipboard</source>
        <translation>将选区复制到剪贴板</translation>
    </message>
    <message>
        <source>Copy the selection into the clipboard</source>
        <translation type="vanished">复制选择到剪贴板</translation>
    </message>
</context>
<context>
    <name>DBusUtils</name>
    <message>
        <source>Unable to connect via DBus</source>
        <translation type="vanished">无法通过 DBus 进行连接</translation>
    </message>
</context>
<context>
    <name>ExitTool</name>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="23"/>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="33"/>
        <source>Leave the capture screen</source>
        <translation>离开屏幕捕获</translation>
    </message>
</context>
<context>
    <name>FileNameEditor</name>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="24"/>
        <source>Edit the name of your captures:</source>
        <translation>编辑您的截图名称:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="28"/>
        <source>Edit:</source>
        <translation>编辑器:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="30"/>
        <source>Preview:</source>
        <translation>预览:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="73"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="76"/>
        <source>Saves the pattern</source>
        <translation>保存样式</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="78"/>
        <source>Restore</source>
        <translation>恢复</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">恢复</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="81"/>
        <source>Restores the saved pattern</source>
        <translation>恢复保存的样式</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="83"/>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="89"/>
        <source>Deletes the name</source>
        <translation>删除这个名字</translation>
    </message>
</context>
<context>
    <name>Flameshot</name>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="119"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="119"/>
        <source>Unable to close active modal widgets</source>
        <translation>无法关闭活动模态微件</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="431"/>
        <source>URL copied to clipboard.</source>
        <translation>链接已复制至剪贴板。</translation>
    </message>
</context>
<context>
    <name>FlameshotDaemon</name>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="407"/>
        <source>New version %1 is available</source>
        <translation>新版本 %1 可用</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="413"/>
        <source>You have the latest version</source>
        <translation>你正在运行最新版本</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="422"/>
        <source>Failed to get information about the latest version.</source>
        <translation>未能获取最新版本信息。</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="445"/>
        <source>Unable to connect via DBus</source>
        <translation>无法使用 DBus 连接</translation>
    </message>
</context>
<context>
    <name>GeneneralConf</name>
    <message>
        <source>Show help message</source>
        <translation type="vanished">显示帮助文档</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="vanished">在捕获之前显示帮助信息。</translation>
    </message>
    <message>
        <source>Show desktop notifications</source>
        <translation type="vanished">显示桌面通知</translation>
    </message>
    <message>
        <source>Show tray icon</source>
        <translation type="vanished">显示托盘图标</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="vanished">显示任务栏图标</translation>
    </message>
    <message>
        <source>Import</source>
        <translation type="vanished">导入</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">错误</translation>
    </message>
    <message>
        <source>Unable to read file.</source>
        <translation type="vanished">无法读取文件。</translation>
    </message>
    <message>
        <source>Unable to write file.</source>
        <translation type="vanished">无法写入文件。</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation type="vanished">保存到文件</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation type="vanished">确定重置</translation>
    </message>
    <message>
        <source>Are you sure you want to reset the configuration?</source>
        <translation type="vanished">你确定你想要重置配置？</translation>
    </message>
    <message>
        <source>Show the side panel button</source>
        <translation type="vanished">显示侧边栏按钮</translation>
    </message>
    <message>
        <source>Show the side panel toggle button in the capture mode.</source>
        <translation type="vanished">在捕获模式下显示侧边栏切换按钮。</translation>
    </message>
    <message>
        <source>Configuration File</source>
        <translation type="vanished">配置文件</translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="vanished">导出</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">重置</translation>
    </message>
    <message>
        <source>Launch at startup</source>
        <translation type="vanished">开机时启动</translation>
    </message>
    <message>
        <source>Launch Flameshot</source>
        <translation type="vanished">启动 Flameshot</translation>
    </message>
    <message>
        <source>Close after capture</source>
        <translation type="vanished">捕获后关闭</translation>
    </message>
    <message>
        <source>Close after taking a screenshot</source>
        <translation type="vanished">获取屏幕截图后关闭</translation>
    </message>
    <message>
        <source>Copy URL after upload</source>
        <translation type="vanished">上传后复制 URL</translation>
    </message>
    <message>
        <source>Copy URL and close window after upload</source>
        <translation type="vanished">上传后复制 URL 并关闭窗口</translation>
    </message>
    <message>
        <source>Save image after copy</source>
        <translation type="vanished">复制后保存图像</translation>
    </message>
    <message>
        <source>Save image file after copying it</source>
        <translation type="vanished">复制到剪贴板后保存图像文件</translation>
    </message>
    <message>
        <source>Save Path</source>
        <translation type="vanished">保存路径</translation>
    </message>
    <message>
        <source>Change...</source>
        <translation type="vanished">变更…</translation>
    </message>
    <message>
        <source>Choose a Folder</source>
        <translation type="vanished">选择文件夹</translation>
    </message>
    <message>
        <source>Unable to write to directory.</source>
        <translation type="vanished">无法写入目录。</translation>
    </message>
</context>
<context>
    <name>GeneralConf</name>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="192"/>
        <location filename="../../src/config/generalconf.cpp" line="394"/>
        <source>Import</source>
        <translation>导入</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="198"/>
        <location filename="../../src/config/generalconf.cpp" line="207"/>
        <location filename="../../src/config/generalconf.cpp" line="232"/>
        <location filename="../../src/config/generalconf.cpp" line="763"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="198"/>
        <source>Unable to read file.</source>
        <translation>无法读取文件。</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="207"/>
        <location filename="../../src/config/generalconf.cpp" line="232"/>
        <source>Unable to write file.</source>
        <translation>无法写入文件。</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="219"/>
        <source>Save File</source>
        <translation>保存到文件</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="241"/>
        <source>Confirm Reset</source>
        <translation>确定重置</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="242"/>
        <source>Are you sure you want to reset the configuration?</source>
        <translation>你确定你想要重置配置？</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="273"/>
        <source>Show help message</source>
        <translation>显示帮助信息</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="vanished">在捕获之前显示帮助信息。</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="298"/>
        <source>Show the side panel button</source>
        <translation>显示侧边栏按钮</translation>
    </message>
    <message>
        <source>Show the side panel toggle button in the capture mode.</source>
        <translation type="vanished">在捕获模式下显示侧边栏切换按钮。</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="311"/>
        <source>Show desktop notifications</source>
        <translation>显示桌面通知</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="336"/>
        <source>Show tray icon</source>
        <translation>显示托盘图标</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="vanished">显示任务栏图标</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="367"/>
        <source>Confirmation required to delete screenshot from the latest uploads</source>
        <translation>从最近的上传历史中删除屏幕截图需要进行确认</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="382"/>
        <source>Configuration File</source>
        <translation>配置文件</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="387"/>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="401"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="412"/>
        <source>Automatic check for updates</source>
        <translation>自动检查更新</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="426"/>
        <source>Allow multiple flameshot GUI instances simultaneously</source>
        <translation>允许同时运行多个 flameshot GUI 实例</translation>
    </message>
    <message>
        <source>This allows you to take screenshots of flameshot itself for example.</source>
        <translation type="vanished">这样能允许您获取火焰截图自身的截图。</translation>
    </message>
    <message>
        <source>Automatically close daemon when it is not needed</source>
        <translation type="vanished">不需要时自动关闭守护程序</translation>
    </message>
    <message>
        <source>Launch at startup</source>
        <translation type="vanished">开机时启动</translation>
    </message>
    <message>
        <source>Launch Flameshot</source>
        <translation type="vanished">启动火焰截图</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="463"/>
        <source>Show welcome message on launch</source>
        <translation>启动时显示欢迎消息</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="491"/>
        <source>Use large predefined color palette</source>
        <translation>使用大型预定义调色盘</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="515"/>
        <source>Copy URL after upload</source>
        <translation>上传后复制 URL</translation>
    </message>
    <message>
        <source>Copy URL and close window after upload</source>
        <translation type="vanished">上传后复制 URL 并关闭窗口</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="527"/>
        <source>Save image after copy</source>
        <translation>复制后保存图像</translation>
    </message>
    <message>
        <source>Save image file after copying it</source>
        <translation type="vanished">复制到剪贴板后保存图像文件</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="274"/>
        <source>Show the help message at the beginning in the capture mode</source>
        <translation>在捕获之前显示帮助信息</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="284"/>
        <source>Use last region for GUI mode</source>
        <translation>在图形用户界面模式下使用最后一个区域</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="286"/>
        <source>Use the last region as the default selection for the next screenshot in GUI mode</source>
        <translation>在图形界面模式下，将最后一个区域作为下次截图的默认选择</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="300"/>
        <source>Show the side panel toggle button in the capture mode</source>
        <translation>在捕获模式下显示侧边栏切换按钮</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="312"/>
        <source>Enable desktop notifications</source>
        <translation>启用桌面通知</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="323"/>
        <source>Show abort notifications</source>
        <translation>显示中断提示</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="324"/>
        <source>Enable abort notifications</source>
        <translation>启用中断通知</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="337"/>
        <source>Show icon in the system tray</source>
        <translation>在系统托盘中显示图标</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="350"/>
        <source>Use grim to capture screenshots</source>
        <translation>用grim 截图</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="352"/>
        <source>Grim is a wayland only utility to capture screens based on the screencopy protocol. Generally only enable on minimal wayland window managers like sway, hyprland, etc.</source>
        <translation>Grim是一个只用于wayland的截图工具,基于screencopy protocol, 通常仅在最小化的wayland合成器中启用,如sway,hyprland等.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="370"/>
        <source>Ask for confirmation to delete screenshot from the latest uploads</source>
        <translation>从最近的上传历史中删除屏幕截图需要进行确认</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="413"/>
        <source>Check for updates automatically</source>
        <translation>自动检查更新</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="427"/>
        <source>This allows you to take screenshots of Flameshot itself for example</source>
        <translation>例如，这允许您截取 Flameshot 本身作为屏幕截图</translation>
    </message>
    <message>
        <source>Launch Flameshot daemon when computer is booted</source>
        <translation type="vanished">开机自启动</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="466"/>
        <source>Show the welcome message box in the middle of the screen while taking a screenshot</source>
        <translation>在截取屏幕截图时在屏幕中间显示欢迎消息框</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="493"/>
        <source>Use a large predefined color palette</source>
        <translation>使用一个大的预定义调色板</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="503"/>
        <source>Copy on double click</source>
        <translation>双击以复制</translation>
    </message>
    <message>
        <source>Enable Copy on Double Click</source>
        <translation type="vanished">启用双击时复制</translation>
    </message>
    <message>
        <source>Copy URL and close window after uploading was successful</source>
        <translation type="vanished">上传成功后复制 URL 并关闭窗口</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="439"/>
        <source>Automatically unload from memory when it is not needed</source>
        <translation>在不需要时自动从内存中卸载</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="440"/>
        <source>Automatically close daemon (background process) when it is not needed</source>
        <translation>在不需要时自动关闭守护程序（后台进程）</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="451"/>
        <source>Launch in background at startup</source>
        <translation>在启动时在后台启动</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="452"/>
        <source>Launch Flameshot daemon (background process) when computer is booted</source>
        <translation>当计算机启动时启动 Flameshot 守护进程（后台进程）</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="477"/>
        <source>Ask before quit capture</source>
        <translation>退出截图前请询问</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="480"/>
        <source>Show the confirmation prompt before ESC quit</source>
        <translation>在退出时显示确认提示</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="505"/>
        <source>Enable Copy to clipboard on Double Click</source>
        <translation>在双击时启用复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="517"/>
        <source>Copy URL after uploading was successful</source>
        <translation>上传成功后复制网址</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="529"/>
        <source>After copying the screenshot, save it to a file as well</source>
        <translation>复制屏幕截图后，也将其保存到文件中</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="536"/>
        <source>Save Path</source>
        <translation>保存路径</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="552"/>
        <source>Change...</source>
        <translation>变更…</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="560"/>
        <source>Use fixed path for screenshots to save</source>
        <translation>使用固定的屏幕截图保存路径</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="572"/>
        <source>Preferred save file extension:</source>
        <translation>偏好的保存文件扩展名：</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="601"/>
        <source>Latest Uploads Max Size</source>
        <translation>之前的上传最大数量</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="623"/>
        <source>Imgur Application Client ID</source>
        <translation>Imgur 应用程序客户端 ID</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="654"/>
        <source>Undo limit</source>
        <translation>撤销次数限制</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="683"/>
        <source>Use JPG format for clipboard (PNG default)</source>
        <translation>剪贴板使用 JPG 格式（默认为 PNG）</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="685"/>
        <source>Use lossy JPG format for clipboard (lossless PNG default)</source>
        <translation>对剪贴板使用有损JPG格式（默认无损PNG）</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="711"/>
        <source>Copy file path after save</source>
        <translation>保存文件后复制文件路径</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="712"/>
        <source>Copy the file path to clipboard after the file is saved</source>
        <translation>文件保存后将文件路径复制到剪贴板上</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="723"/>
        <source>Anti-aliasing image when zoom the pinned image</source>
        <translation>缩放贴图时应用反锯齿</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="725"/>
        <source>After zooming the pinned image, should the image get smoothened or stay pixelated</source>
        <translation>对贴图进行缩放后，对图像进行平滑处理还是维持像素化状态</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="736"/>
        <location filename="../../src/config/generalconf.cpp" line="738"/>
        <source>Upload image without confirmation</source>
        <translation>上传图像无需确认</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="754"/>
        <source>Choose a Folder</source>
        <translation>选择文件夹</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="763"/>
        <source>Unable to write to directory.</source>
        <translation>无法写入目录。</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="772"/>
        <source>Show magnifier</source>
        <translation>显示放大镜</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="773"/>
        <source>Enable a magnifier while selecting the screenshot area</source>
        <translation>选择屏幕截图区域时启用放大镜</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="784"/>
        <source>Square shaped magnifier</source>
        <translation>方形放大镜</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="785"/>
        <source>Make the magnifier to be square-shaped</source>
        <translation>使放大镜呈方形</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="801"/>
        <source>Milliseconds before geometry display hides; 0 means do not hide</source>
        <translation>几何显示隐藏前的毫秒数；设为0则不隐藏</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="804"/>
        <source>Set geometry display timeout (ms)</source>
        <translation>设置几何显示时间(毫秒）</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="812"/>
        <source>Selection Geometry Display</source>
        <translation>选取几何显示</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="819"/>
        <source>Display Location</source>
        <translation>显示位置</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="822"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="823"/>
        <source>Top Left</source>
        <translation>左上</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="825"/>
        <source>Top Right</source>
        <translation>右上</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="827"/>
        <source>Bottom Left</source>
        <translation>左下</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="829"/>
        <source>Bottom Right</source>
        <translation>右下</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="831"/>
        <source>Center</source>
        <translation>中心</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="856"/>
        <source>Quality range of 0-100; Higher number is better quality and larger file size</source>
        <translation>质量范围为0-100；数字越大，质量越好，文件大小也越大</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="860"/>
        <source>JPEG Quality</source>
        <translation>JPEG质量</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="871"/>
        <source>Reverse arrow</source>
        <translation>反向箭头</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="872"/>
        <source>Draw the arrow head first</source>
        <translation>先画箭头</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="881"/>
        <source>Insecure Pixelate</source>
        <translation>不安全Pixelate</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="883"/>
        <source>Draw the pixelation effect in an insecure but more asethetic way.</source>
        <translation>用一种不安全但更美观的方式画出像素效果。</translation>
    </message>
</context>
<context>
    <name>HistoryWidget</name>
    <message>
        <source>Latest Uploads</source>
        <translation type="vanished">最近的上传</translation>
    </message>
    <message>
        <source>Screenshots history is empty</source>
        <translation type="vanished">屏幕截图历史为空</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="vanished">复制链接</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">链接已复制到剪贴板。</translation>
    </message>
    <message>
        <source>Open in browser</source>
        <translation type="vanished">在浏览器中打开</translation>
    </message>
    <message>
        <source>Confirm to delete</source>
        <translation type="vanished">确认进行删除</translation>
    </message>
    <message>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation type="vanished">您确认要从最近的上传历史和服务器上删除该屏幕截图吗？</translation>
    </message>
</context>
<context>
    <name>ImgS3Uploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">正在上传</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="obsolete">错误</translation>
    </message>
</context>
<context>
    <name>ImgUploadDialog</name>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="18"/>
        <source>Upload Confirmation</source>
        <translation>上传确认</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="22"/>
        <source>Do you want to upload this capture?</source>
        <translation>您是否想要上传该捕获图像？</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="35"/>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="36"/>
        <source>Upload without confirmation</source>
        <translation>上传无需确认</translation>
    </message>
</context>
<context>
    <name>ImgUploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">正在上传</translation>
    </message>
    <message>
        <source>Unable to open the URL.</source>
        <translation type="obsolete">无法打开此链接。</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="obsolete">截图复制到剪贴板。</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="obsolete">复制链接</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="obsolete">打开链接</translation>
    </message>
    <message>
        <source>Delete image</source>
        <translation type="obsolete">删除图像</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="obsolete">保存文件到剪贴板。</translation>
    </message>
</context>
<context>
    <name>ImgUploaderBase</name>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="37"/>
        <source>Upload image</source>
        <translation>上传图像</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="49"/>
        <source>Uploading Image</source>
        <translation>正在上传图像</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="128"/>
        <source>Copy URL</source>
        <translation>复制链接</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="129"/>
        <source>Open URL</source>
        <translation>打开链接</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="130"/>
        <source>Delete image</source>
        <translation>删除图像</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="131"/>
        <source>Image to Clipboard.</source>
        <translation>图像到剪贴板。</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="132"/>
        <source>Save image</source>
        <translation>保存图片</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="162"/>
        <source>Unable to open the URL.</source>
        <translation>无法打开链接。</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="169"/>
        <source>URL copied to clipboard.</source>
        <translation>链接已复制到剪贴板。</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="175"/>
        <source>Screenshot copied to clipboard.</source>
        <translation>截图已复制到剪贴板。</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="189"/>
        <source>Unable to save the screenshot to disk.</source>
        <translation>无法将屏幕截图保存到磁盘。</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="192"/>
        <source>Screenshot saved.</source>
        <translation>截图已保存。</translation>
    </message>
</context>
<context>
    <name>ImgUploaderTool</name>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="23"/>
        <source>Image Uploader</source>
        <translation>图像上传工具</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="33"/>
        <source>Upload the selection</source>
        <translation>上传选中区域</translation>
    </message>
</context>
<context>
    <name>ImgurUploader</name>
    <message>
        <source>Upload to Imgur</source>
        <translation type="vanished">上传到Imgur</translation>
    </message>
    <message>
        <source>Uploading Image</source>
        <translation type="vanished">正在上传</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="vanished">复制链接</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="vanished">打开链接</translation>
    </message>
    <message>
        <source>Delete image</source>
        <translation type="vanished">删除图像</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="vanished">保存文件到剪贴板。</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imgur/imguruploader.cpp" line="107"/>
        <source>Unable to open the URL.</source>
        <translation>无法打开此链接。</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">复制链接到剪贴板。</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="vanished">截图复制到剪贴板。</translation>
    </message>
</context>
<context>
    <name>ImgurUploaderTool</name>
    <message>
        <source>Image Uploader</source>
        <translation type="vanished">上传图片</translation>
    </message>
    <message>
        <source>Upload the selection to Imgur</source>
        <translation type="vanished">上传选择到 Imgur</translation>
    </message>
</context>
<context>
    <name>InfoWindow</name>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="116"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="26"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="117"/>
        <source>Icon</source>
        <translation>图标</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="43"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="118"/>
        <source>License</source>
        <translation>许可证</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="56"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="119"/>
        <source>GPLv3+</source>
        <translation>GPLv3+</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="89"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="120"/>
        <source>Version</source>
        <translation>版本</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="102"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="121"/>
        <source>Flameshot v</source>
        <translation>Flameshot v</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="115"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="122"/>
        <source>OS Info</source>
        <translation>操作系统信息</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="128"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="123"/>
        <source>Copy Info</source>
        <translation>复制信息</translation>
    </message>
    <message>
        <source>SPACEBAR</source>
        <translation type="vanished">空格</translation>
    </message>
    <message>
        <source>Right Click</source>
        <translation type="vanished">右键</translation>
    </message>
    <message>
        <source>Mouse Wheel</source>
        <translation type="vanished">鼠标滑轮</translation>
    </message>
    <message>
        <source>Move selection 1px</source>
        <translation type="vanished">移动选择 1 px</translation>
    </message>
    <message>
        <source>Resize selection 1px</source>
        <translation type="vanished">调整选择大小 1 px</translation>
    </message>
    <message>
        <source>Quit capture</source>
        <translation type="vanished">退出捕获</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation type="vanished">复制到剪贴板</translation>
    </message>
    <message>
        <source>Save selection as a file</source>
        <translation type="vanished">将选择保存为文件</translation>
    </message>
    <message>
        <source>Undo the last modification</source>
        <translation type="vanished">撤消上次修改</translation>
    </message>
    <message>
        <source>Toggle visibility of sidebar with options of the selected tool</source>
        <translation type="vanished">切换侧边栏可见性</translation>
    </message>
    <message>
        <source>Show color picker</source>
        <translation type="vanished">显示颜色选择器</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="vanished">改变工具的厚度</translation>
    </message>
    <message>
        <source>Key</source>
        <translation type="vanished">键</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="vanished">描述</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;License&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;许可证&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Version&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;版本&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Shortcuts&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;快捷键&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation type="vanished">屏幕捕捉模式中的可用快捷键。</translation>
    </message>
</context>
<context>
    <name>InvertTool</name>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="25"/>
        <source>Invert</source>
        <translation>反色</translation>
    </message>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="35"/>
        <source>Set Inverter as the paint tool</source>
        <translation>将反色设置为绘画工具</translation>
    </message>
</context>
<context>
    <name>LineTool</name>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="22"/>
        <source>Line</source>
        <translation>直线</translation>
    </message>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="32"/>
        <source>Set the Line as the paint tool</source>
        <translation>将直线设置为绘画工具</translation>
    </message>
</context>
<context>
    <name>MarkerTool</name>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="23"/>
        <source>Marker</source>
        <translation>标记</translation>
    </message>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="33"/>
        <source>Set the Marker as the paint tool</source>
        <translation>将标记设置为绘画工具</translation>
    </message>
</context>
<context>
    <name>MoveTool</name>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="23"/>
        <source>Move</source>
        <translation>移动</translation>
    </message>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="33"/>
        <source>Move the selection area</source>
        <translation>移动选择区域</translation>
    </message>
</context>
<context>
    <name>PencilTool</name>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="18"/>
        <source>Pencil</source>
        <translation>铅笔</translation>
    </message>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="28"/>
        <source>Set the Pencil as the paint tool</source>
        <translation>将铅笔设置为绘画工具</translation>
    </message>
</context>
<context>
    <name>PinTool</name>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="25"/>
        <source>Pin Tool</source>
        <translation>贴图工具</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="35"/>
        <source>Pin image on the desktop</source>
        <translation>在桌面上固定图像</translation>
    </message>
</context>
<context>
    <name>PinWidget</name>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="282"/>
        <source>Context menu</source>
        <translation>上下文菜单</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="284"/>
        <source>Copy to clipboard</source>
        <translation>复制到剪贴板</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="291"/>
        <source>Save to file</source>
        <translation>保存到文件</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="298"/>
        <source>Rotate Right</source>
        <translation>向右旋转</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="303"/>
        <source>Rotate Left</source>
        <translation>向左旋转</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="308"/>
        <source>Increase Opacity</source>
        <translation>增加不透明度</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="315"/>
        <source>Decrease Opacity</source>
        <translation>降低不透明度</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="322"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>PixelateTool</name>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="27"/>
        <source>Pixelate</source>
        <translation>像素化</translation>
    </message>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="37"/>
        <source>Set Pixelate as the paint tool.</source>
        <translation>将像素化设置为绘画工具。</translation>
    </message>
    <message>
        <source>Set Pixelate as the paint tool</source>
        <translation type="vanished">将像素化设置为绘画工具</translation>
    </message>
</context>
<context>
    <name>PrimaryInstanceWidget</name>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/primaryinstancewidget.cpp" line="21"/>
        <source>Primary instance</source>
        <translation>主实例</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/primaryinstancewidget.cpp" line="22"/>
        <source>&lt;b&gt;Primary instance.&lt;/b&gt; Messages received from secondaries:</source>
        <translation>&lt;b&gt;主要实例。&lt;/b&gt;从secondary收到的消息：</translation>
    </message>
</context>
<context>
    <name>QHotkey</name>
    <message>
        <source>Failed to register %1. Error: %2</source>
        <translation type="vanished">注册 %1 失败。错误：%2</translation>
    </message>
    <message>
        <source>Failed to unregister %1. Error: %2</source>
        <translation type="vanished">取消注册 %1 失败。错误：%2</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="286"/>
        <source>Save Error</source>
        <translation>保存错误</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="62"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="267"/>
        <source>Capture saved as </source>
        <translation>捕获已保存为 </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="196"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="198"/>
        <source>Capture saved to clipboard.</source>
        <translation>捕获已保存至剪贴板。</translation>
    </message>
    <message>
        <source>Capture saved to clipboard</source>
        <translation type="vanished">捕获已保存至剪贴板</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="182"/>
        <source>Error while saving to clipboard</source>
        <translation>保存到剪贴板时出错</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="66"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="279"/>
        <source>Error trying to save as </source>
        <translation>尝试另存为时出错 </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="244"/>
        <source>Save screenshot</source>
        <translation>保存屏幕截图</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="275"/>
        <source>Path copied to clipboard as </source>
        <translation>路径已复制到剪贴板 </translation>
    </message>
    <message>
        <source>Saving canceled</source>
        <translation type="vanished">已取消保存</translation>
    </message>
    <message>
        <source>Save canceled</source>
        <translation type="vanished">已取消保存</translation>
    </message>
    <message>
        <source>Capture is saved and copied to the clipboard as </source>
        <translation type="vanished">捕获已保存并复制到剪贴板，作为 </translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="220"/>
        <source>Unable to connect via DBus</source>
        <translation>无法通过DBus进行连接</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="237"/>
        <source>Powerful yet simple to use screenshot software.</source>
        <translation>强大又易用的屏幕截图软件。</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="238"/>
        <source>See</source>
        <translation>参见</translation>
    </message>
    <message>
        <source>Capture the entire desktop.</source>
        <translation type="vanished">捕获整个桌面。</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="244"/>
        <source>Open the capture launcher.</source>
        <translation>打开截图启动器。</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="247"/>
        <source>Start a manual capture in GUI mode.</source>
        <translation>以图形界面模式进行手动截图。</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="249"/>
        <source>Configure</source>
        <translation>配置</translation>
    </message>
    <message>
        <source>Capture a single screen.</source>
        <translation type="vanished">捕获单个屏幕。</translation>
    </message>
    <message>
        <source>Path where the capture will be saved</source>
        <translation type="vanished">截图保存路径</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="242"/>
        <source>Capture screenshot of all monitors at the same time.</source>
        <translation>同时截取所有显示器的屏幕截图。</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="252"/>
        <source>Capture a screenshot of the specified monitor.</source>
        <translation>截取指定显示器的屏幕截图。</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="257"/>
        <source>Existing directory or new file to save to</source>
        <translation>要保存的目标目录路径或新文件</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="260"/>
        <source>Save the capture to the clipboard</source>
        <translation>将截图保存至剪贴板</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="262"/>
        <source>Pin the capture to the screen</source>
        <translation>将捕获图像作为贴图放置在屏幕上</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="264"/>
        <source>Upload screenshot</source>
        <translation>上传截图</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="266"/>
        <source>Delay time in milliseconds</source>
        <translation>延迟时间，以毫秒计</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="271"/>
        <source>Repeat screenshot with previously selected region</source>
        <translation>使用之前的选区重复截图</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="274"/>
        <source>Screenshot region to select</source>
        <translation>要选择的屏幕区域</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="277"/>
        <source>Set the filename pattern</source>
        <translation>设置文件名模式</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="281"/>
        <source>Accept capture as soon as a selection is made</source>
        <translation>在选中选区后立刻接受捕获图像</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="283"/>
        <source>Enable or disable the trayicon</source>
        <translation>启用或禁用托盘图标</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="287"/>
        <source>Enable or disable run at startup</source>
        <translation>启用或禁用开机启动</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="291"/>
        <source>Enable or disable the notifications</source>
        <translation>启用或禁用通知</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="294"/>
        <source>Check the configuration for errors</source>
        <translation>检查配置文件错误</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="297"/>
        <source>Show the help message in the capture mode</source>
        <translation>在捕获模式中显示帮助信息</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="300"/>
        <source>Define the main UI color</source>
        <translation>定义用户界面主颜色</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="304"/>
        <source>Define the contrast UI color</source>
        <translation>定义用户界面对比色</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="307"/>
        <source>Print raw PNG capture</source>
        <translation>输出原始 PNG 图像</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="310"/>
        <source>Print geometry of the selection in the format WxH+X+Y. Does nothing if raw is specified</source>
        <translation>使用 WxH+X+Y 的格式输出选区几何参数。如果指定了 raw 参数则什么也不做</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="314"/>
        <source>Define the screen to capture (starting from 0)</source>
        <translation>定义要捕获的屏幕（从 0 开始）</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="334"/>
        <source>Invalid delay, it must be a number greater than 0</source>
        <translation>无效的延时，必须提供大于零的数值</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="337"/>
        <source>Invalid region, use &apos;WxH+X+Y&apos; or &apos;all&apos; or &apos;screen0/screen1/...&apos;.</source>
        <translation>无效的区域，请使用“WxH+X+Y”或“all”或“screen0/screen1/...”。</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="350"/>
        <source>Invalid path, must be an existing directory or a new file in an existing directory</source>
        <translation>无效的路径，必须为已有目录或者已有目录中的一个新文件</translation>
    </message>
    <message>
        <source>Define the screen to capture</source>
        <translation type="vanished">定义要捕获的屏幕</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="315"/>
        <source>default: screen containing the cursor</source>
        <translation>默认：包含鼠标指针的屏幕</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="316"/>
        <source>Screen number</source>
        <translation>屏幕编号</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="325"/>
        <source>Invalid color, this flag supports the following formats:
- #RGB (each of R, G, and B is a single hex digit)
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- Named colors like &apos;blue&apos; or &apos;red&apos;
You may need to escape the &apos;#&apos; sign as in &apos;\#FFF&apos;</source>
        <translation>颜色无效，该选项支持以下格式：
- #RGB（R、G、B 每项均为单个十六进制数字）
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- 常用英文颜色名称，如“blue”或“red”
您可能需要对 # 字符进行转义，如“\#FFF”</translation>
    </message>
    <message>
        <source>Invalid delay, it must be higher than 0</source>
        <translation type="vanished">无效的延迟时间，数字必须大于0</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="336"/>
        <source>Invalid screen number, it must be non negative</source>
        <translation>无效的屏幕编号，编号不能为负数</translation>
    </message>
    <message>
        <source>Invalid path, it must be a real path in the system</source>
        <translation type="vanished">无效的路径，必须为系统中真实存在的路径</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="363"/>
        <source>Invalid value, it must be defined as &apos;true&apos; or &apos;false&apos;</source>
        <translation>无效的值，必须指定“true”或“false”</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="30"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="31"/>
        <source>Unable to write in</source>
        <translation>无法写入</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="156"/>
        <source>Requested screen exceeds screen count</source>
        <translation>请求的屏幕超出了屏幕编号</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="408"/>
        <source>Full screen screenshot pinned to screen</source>
        <translation>已将全屏截图作为贴图固定到屏幕</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">URL 已复制到剪贴板。</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="54"/>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <source>Arguments</source>
        <translation type="vanished">参数</translation>
    </message>
    <message>
        <source>arguments</source>
        <translation type="vanished">参数</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="68"/>
        <source>Subcommands</source>
        <translation>子命令</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="328"/>
        <source>subcommands</source>
        <translation>子命令</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="329"/>
        <source>Usage</source>
        <translation>用法</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="329"/>
        <source>options</source>
        <translation>选项</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="334"/>
        <source>Per default runs Flameshot in the background and adds a tray icon for configuration.</source>
        <translation>默认情况下火焰截图将在后台持续运行并显示一个托盘图标以方便用户控制。</translation>
    </message>
    <message>
        <source>Per default runs Flameshot in the background and   adds a tray icon for configuration.</source>
        <translation type="vanished">默认情况下，火焰截图启动后将在后台运行，并在托盘显示一个图标。</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="71"/>
        <source>Hello, I&apos;m here! Click icon in the tray to take a screenshot or click with a right button to see more options.</source>
        <translation>我已启动并在后台运行！点击托盘图标即可进行屏幕截图，右键点击托盘图标可查看更多选项。</translation>
    </message>
    <message>
        <source>Toggle side panel</source>
        <translation type="vanished">切换侧面板</translation>
    </message>
    <message>
        <source>Resize selection left 1px</source>
        <translation type="vanished">向左改变选区大小1像素</translation>
    </message>
    <message>
        <source>Resize selection right 1px</source>
        <translation type="vanished">向右改变选区大小1像素</translation>
    </message>
    <message>
        <source>Resize selection up 1px</source>
        <translation type="vanished">向上改变选区大小1像素</translation>
    </message>
    <message>
        <source>Resize selection down 1px</source>
        <translation type="vanished">向下改变选区大小1像素</translation>
    </message>
    <message>
        <source>Select entire screen</source>
        <translation type="vanished">选择整个屏幕</translation>
    </message>
    <message>
        <source>Move selection left 1px</source>
        <translation type="vanished">向左移动选区1像素</translation>
    </message>
    <message>
        <source>Move selection right 1px</source>
        <translation type="vanished">向右移动选区1像素</translation>
    </message>
    <message>
        <source>Move selection up 1px</source>
        <translation type="vanished">向上移动选区1像素</translation>
    </message>
    <message>
        <source>Move selection down 1px</source>
        <translation type="vanished">向下移动选区1像素</translation>
    </message>
    <message>
        <source>Commit text in text area</source>
        <translation type="vanished">在文本区域提交文本</translation>
    </message>
    <message>
        <source>Delete current tool</source>
        <translation type="vanished">删除当前工具</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="195"/>
        <source>Quit capture</source>
        <translation>退出捕获</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="207"/>
        <source>Screenshot history</source>
        <translation>屏幕截图历史</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="211"/>
        <source>Capture screen</source>
        <translation>捕获屏幕</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="218"/>
        <source>Show color picker</source>
        <translation>显示颜色选择器</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="219"/>
        <source>Change the tool&apos;s size</source>
        <translation>更改工具大小</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="vanished">改变工具的厚度</translation>
    </message>
</context>
<context>
    <name>RectangleTool</name>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="22"/>
        <source>Rectangle</source>
        <translation>实心矩形</translation>
    </message>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="32"/>
        <source>Set the Rectangle as the paint tool</source>
        <translation>将实心矩形设置为绘画工具</translation>
    </message>
</context>
<context>
    <name>RedoTool</name>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="23"/>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="33"/>
        <source>Redo the next modification</source>
        <translation>重做上次修改</translation>
    </message>
</context>
<context>
    <name>SaveTool</name>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="24"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="34"/>
        <source>Save screenshot to a file</source>
        <translation>保存屏幕截图到文件</translation>
    </message>
    <message>
        <source>Save the capture</source>
        <translation type="vanished">保存捕获</translation>
    </message>
</context>
<context>
    <name>ScreenGrabber</name>
    <message>
        <source>Unable to detect desktop environment (GNOME? KDE? Sway? ...)</source>
        <translation type="vanished">无法探测当前桌面环境（GNOME？KDE？Sway？……）</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="53"/>
        <source>The universal wayland screen capture adapter requires Grim as the screen capture component of wayland. If the screen capture component is missing, please install it!</source>
        <translation>通用的 Wayland 屏幕捕获适配器需要 Grim 作为 Wayland 的屏幕捕获组件。如果缺少屏幕捕获组件，请安装它！</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="171"/>
        <source>If the useGrimAdapter setting is not enabled, the dbus protocol will be used. It should be noted that using the dbus protocol under wayland is not recommended. It is recommended to enable the useGrimAdapter setting in flameshot.ini to activate the grim-based general wayland screenshot adapter</source>
        <translation>如果未启用 useGrimAdapter 设置，将使用 dbus 协议。需要注意的是，在 wayland 下使用 dbus 协议并不推荐。建议在 flameshot.ini 中启用 useGrimAdapter 设置，以激活基于 grim 的通用 wayland 屏幕截图适配器</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="182"/>
        <source>grim&apos;s screenshot component is implemented based on wlroots, it may not be used in GNOME or similar desktop environments</source>
        <translation>grim 的截图组件是基于 wlroots 实现的，可能无法在 GNOME 或类似的桌面环境中使用</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="194"/>
        <source>Unable to detect desktop environment (GNOME? KDE? Qile? Sway? ...)</source>
        <translation>无法检测桌面环境（GNOME? KDE? Qile? Sway? …）</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="197"/>
        <source>Hint: try setting the XDG_CURRENT_DESKTOP environment variable.</source>
        <translation>提示：请尝试设置 XDG_CURRENT_DESKTOP 环境变量。</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="202"/>
        <source>Unable to capture screen</source>
        <translation>无法捕获屏幕</translation>
    </message>
</context>
<context>
    <name>SecondaryInstanceWidget</name>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="26"/>
        <source>Secondary instance</source>
        <translation>次级实例</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="27"/>
        <source>&lt;b&gt;Secondary instance.&lt;/b&gt; Send message to primary:</source>
        <translation>&lt;b&gt;第二个例子。&lt;/b&gt;发送消息到主服务器：</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="29"/>
        <source>Type something here...</source>
        <translation>在这里输入一些东西…</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="31"/>
        <source>&amp;Send</source>
        <translation>发送（&amp; S）</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="54"/>
        <source>Error sending message</source>
        <translation>发送消息时出错</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="55"/>
        <source>The message &apos;%1&apos; could not be sent to the primary.</source>
        <translation>无法将邮件&apos;%1&apos;发送到主服务器。</translation>
    </message>
</context>
<context>
    <name>SelectionTool</name>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="25"/>
        <source>Rectangular Selection</source>
        <translation>矩形选择</translation>
    </message>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="35"/>
        <source>Set Selection as the paint tool</source>
        <translation>将矩形选择设置为绘画工具</translation>
    </message>
</context>
<context>
    <name>SetShortcutDialog</name>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="18"/>
        <source>Set Shortcut</source>
        <translation>设置快捷键</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="24"/>
        <source>Enter new shortcut to change </source>
        <translation>键入新的快捷键以进行修改 </translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="38"/>
        <source>Press Esc to cancel or ⌘+Backspace to disable the keyboard shortcut.</source>
        <translation>按下 Esc 键以取消，或使用 ⌘+Backspace 来禁用键盘快捷键。</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="42"/>
        <source>Press Esc to cancel or Backspace to disable the keyboard shortcut.</source>
        <translation>按下 Esc 键以取消或按下退格键以禁用键盘快捷键。</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="48"/>
        <location filename="../../src/config/setshortcutwidget.cpp" line="53"/>
        <source>Flameshot must be restarted for changes to take effect.</source>
        <translation>火焰截图必须重新启动以使修改生效。</translation>
    </message>
</context>
<context>
    <name>ShortcutsWidget</name>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="27"/>
        <source>Hot Keys</source>
        <translation>热键</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="48"/>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation>屏幕捕捉模式中的可用快捷键。</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="59"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="59"/>
        <source>Key</source>
        <translation>键</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="162"/>
        <source>Left Double-click</source>
        <translation>左键双击</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="169"/>
        <source>Toggle side panel</source>
        <translation>切换侧面板</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="170"/>
        <source>Grab a color from the screen</source>
        <translation>从屏幕上抓取颜色</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="171"/>
        <source>Resize selection left 1px</source>
        <translation>将选区大小向左调整 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="172"/>
        <source>Resize selection right 1px</source>
        <translation>将选区大小向右调整 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="173"/>
        <source>Resize selection up 1px</source>
        <translation>将选区大小向上调整 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="174"/>
        <source>Resize selection down 1px</source>
        <translation>将选区大小向下调整 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="176"/>
        <source>Symmetrically decrease width by 2px</source>
        <translation>对称地将宽度减少2px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="178"/>
        <source>Symmetrically increase width by 2px</source>
        <translation>对称地增加宽度 2 px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="180"/>
        <source>Symmetrically increase height by 2px</source>
        <translation>对称地增加高度 2 px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="182"/>
        <source>Symmetrically decrease height by 2px</source>
        <translation>对称地减少高度 2 px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="183"/>
        <source>Select entire screen</source>
        <translation>选择整个屏幕</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="184"/>
        <source>Move selection left 1px</source>
        <translation>将选区向左调整 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="185"/>
        <source>Move selection right 1px</source>
        <translation>将选区向右移动 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="186"/>
        <source>Move selection up 1px</source>
        <translation>将选区向上移动 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="187"/>
        <source>Move selection down 1px</source>
        <translation>将选区向下移动 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="188"/>
        <source>Commit text in text area</source>
        <translation>在文本区域提交文本</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="190"/>
        <source>Delete selected drawn object</source>
        <translation>删除选定的绘制对象</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="191"/>
        <source>Cancel current selection</source>
        <translation>取消当前选择</translation>
    </message>
    <message>
        <source>Delete current tool</source>
        <translation type="vanished">删除当前工具</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="200"/>
        <source>Capture screen</source>
        <translation>捕获屏幕</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="202"/>
        <source>Screenshot history</source>
        <translation>屏幕截图历史</translation>
    </message>
</context>
<context>
    <name>SidePanelWidget</name>
    <message>
        <source>Active thickness:</source>
        <translation type="vanished">当前宽度：</translation>
    </message>
    <message>
        <source>Active color:</source>
        <translation type="vanished">活动颜色：</translation>
    </message>
    <message>
        <source>Press ESC to cancel</source>
        <translation type="vanished">按下 ESC 键以取消</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="37"/>
        <source>Active tool size: </source>
        <translation>当前工具大小: </translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="57"/>
        <source>Active Color: </source>
        <translation>当前颜色: </translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="78"/>
        <source>Grab Color</source>
        <translation>获取颜色</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="85"/>
        <source>Display grid</source>
        <translation>显示网格</translation>
    </message>
</context>
<context>
    <name>SizeDecreaseTool</name>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="37"/>
        <source>Decrease Tool Size</source>
        <translation>减小工具尺寸</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="47"/>
        <source>Decrease the size of the other tools</source>
        <translation>减小其它工具的尺寸</translation>
    </message>
</context>
<context>
    <name>SizeIncreaseTool</name>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="37"/>
        <source>Increase Tool Size</source>
        <translation>增大工具尺寸</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="47"/>
        <source>Increase the size of the other tools</source>
        <translation>增大其它工具的尺寸</translation>
    </message>
</context>
<context>
    <name>SizeIndicatorTool</name>
    <message>
        <source>Selection Size Indicator</source>
        <translation type="vanished">选择尺寸指示</translation>
    </message>
    <message>
        <source>Show X and Y dimensions of the selection</source>
        <translation type="vanished">显示选区的横纵尺寸</translation>
    </message>
    <message>
        <source>Show the dimensions of the selection (X Y)</source>
        <translation type="vanished">显示选择的尺寸 (X Y)</translation>
    </message>
</context>
<context>
    <name>StrftimeChooserWidget</name>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="43"/>
        <source>Century (00-99)</source>
        <translation>世纪（00-99）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="44"/>
        <source>Year (00-99)</source>
        <translation>年（00-99）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="45"/>
        <source>Year (2000)</source>
        <translation>年（2000）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="48"/>
        <source>Month Name (jan)</source>
        <translation>月（1月 - 12月）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="49"/>
        <source>Month Name (january)</source>
        <translation>月（一月 - 十二月）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="51"/>
        <source>Month (01-12)</source>
        <translation>月 (01-12)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="52"/>
        <source>Week Day (1-7)</source>
        <translation>周内的日（1-7）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="53"/>
        <source>Week (01-53)</source>
        <translation>周（01-53）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="56"/>
        <source>Day Name (mon)</source>
        <translation>星期（一 - 七）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="57"/>
        <source>Day Name (monday)</source>
        <translation>星期（星期一 - 星期日）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="59"/>
        <source>Day (01-31)</source>
        <translation>天（01-31）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="60"/>
        <source>Day of Month (1-31)</source>
        <translation>一月中的某天（1-31）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="61"/>
        <source>Day (001-366)</source>
        <translation>天（001-366）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="64"/>
        <source>Time (%H-%M-%S)</source>
        <translation>时间（%H-%M-%S）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="65"/>
        <source>Time (%H-%M)</source>
        <translation>时间（%H-%M）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="67"/>
        <source>Hour (00-23)</source>
        <translation>小时（00-23）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="68"/>
        <source>Hour (01-12)</source>
        <translation>小时（01-12）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="69"/>
        <source>Minute (00-59)</source>
        <translation>分钟（00-59）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="70"/>
        <source>Second (00-59)</source>
        <translation>秒（00-59）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="73"/>
        <source>Full Date (%m/%d/%y)</source>
        <translation>完整日期（%m/%d/%y）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="75"/>
        <source>Full Date (%Y-%m-%d)</source>
        <translation>完整日期（%Y-%m-%d）</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="76"/>
        <source>Full Date (%d-%m-%Y)</source>
        <translation>完整日期（% d—% m—%Y）</translation>
    </message>
</context>
<context>
    <name>SystemNotification</name>
    <message>
        <location filename="../../src/utils/systemnotification.cpp" line="42"/>
        <source>Flameshot Info</source>
        <translation>火焰截图消息</translation>
    </message>
</context>
<context>
    <name>TextConfig</name>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="44"/>
        <source>StrikeOut</source>
        <translation>删除线</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="53"/>
        <source>Underline</source>
        <translation>下划线</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="62"/>
        <source>Bold</source>
        <translation>粗体</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="71"/>
        <source>Italic</source>
        <translation>斜体</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="81"/>
        <source>Left Align</source>
        <translation>左对齐</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="90"/>
        <source>Center Align</source>
        <translation>中心对齐</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="99"/>
        <source>Right Align</source>
        <translation>右对齐</translation>
    </message>
</context>
<context>
    <name>TextTool</name>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="73"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="97"/>
        <source>Add text to your capture</source>
        <translation>在您的捕获中添加文本</translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="100"/>
        <source>&amp;Take Screenshot</source>
        <translation>进行截图(&amp;T)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="118"/>
        <source>&amp;Open Launcher</source>
        <translation>打开启动器(&amp;O)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="123"/>
        <source>&amp;Configuration</source>
        <translation>配置(&amp;C)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="128"/>
        <source>&amp;About</source>
        <translation>关于(&amp;A)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="133"/>
        <source>Check for updates</source>
        <translation>检查更新</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="144"/>
        <source>New version %1 is available</source>
        <translation>新版本 %1 可用</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="149"/>
        <source>&amp;Quit</source>
        <translation>退出(&amp;Q)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="154"/>
        <source>&amp;Latest Uploads</source>
        <translation>最近的上传(&amp;L)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="160"/>
        <source>&amp;Open Save Path</source>
        <translation>打开保存路径(&amp;O)</translation>
    </message>
</context>
<context>
    <name>UIcolorEditor</name>
    <message>
        <source>UI Color Editor</source>
        <translation type="vanished">用户界面颜色编辑器</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="88"/>
        <source>Change the color moving the selectors and see the changes in the preview buttons.</source>
        <translation>移动颜色选择并在预览按钮查看。</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="99"/>
        <source>Select a Button to modify it</source>
        <translation>选择一个按钮以进行修改</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="109"/>
        <source>Main Color</source>
        <translation>主色</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="113"/>
        <source>Click on this button to set the edition mode of the main color.</source>
        <translation>点击按钮设置主色。</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="124"/>
        <source>Contrast Color</source>
        <translation>对比色</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="129"/>
        <source>Click on this button to set the edition mode of the contrast color.</source>
        <translation>点击按钮设置对比色。</translation>
    </message>
</context>
<context>
    <name>UndoTool</name>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="23"/>
        <source>Undo</source>
        <translation>撤消</translation>
    </message>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="33"/>
        <source>Undo the last modification</source>
        <translation>撤消上次修改</translation>
    </message>
</context>
<context>
    <name>UpdateNotificationWidget</name>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="70"/>
        <source>New Flameshot version %1 is available</source>
        <translation>新的 Flameshot %1 版已经可用</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="123"/>
        <source>Ignore</source>
        <translation>忽略</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="131"/>
        <source>Later</source>
        <translation>稍后</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="139"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
</context>
<context>
    <name>UploadHistory</name>
    <message>
        <location filename="../../src/widgets/uploadhistory.ui" line="14"/>
        <source>Upload History</source>
        <translation>上传历史记录</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadhistory.cpp" line="60"/>
        <source>Screenshots history is empty</source>
        <translation>屏幕截图历史为空</translation>
    </message>
</context>
<context>
    <name>UploadLineItem</name>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="20"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="49"/>
        <source>TextLabel</source>
        <translation>文本标签</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="82"/>
        <source>Copy URL</source>
        <translation>复制链接</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="95"/>
        <source>Open In Browser</source>
        <translation>在浏览器中打开</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="50"/>
        <source>Confirm to delete</source>
        <translation>确认进行删除</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="51"/>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation>您确认要从最近的上传和服务器上删除该屏幕截图吗？</translation>
    </message>
</context>
<context>
    <name>UtilityPanel</name>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="196"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="206"/>
        <source>&lt;Empty&gt;</source>
        <translation>&lt;空&gt;</translation>
    </message>
</context>
<context>
    <name>VisualsEditor</name>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="41"/>
        <source>Opacity of area outside selection:</source>
        <translation>选中区域之外的不透明度：</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="68"/>
        <source>UI Color Editor</source>
        <translation>用户界面颜色编辑器</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="74"/>
        <source>Colorpicker Editor</source>
        <translation>拾色器编辑器</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="79"/>
        <source>Button Selection</source>
        <translation>按钮选择</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="85"/>
        <source>Select All</source>
        <translation>全选</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorDialog</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.cpp" line="63"/>
        <source>Pick</source>
        <translation>选取</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPalette</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette.cpp" line="417"/>
        <source>Unnamed</source>
        <translation>未命名</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteModel</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_model.cpp" line="55"/>
        <source>Unnamed</source>
        <translation>未命名</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_model.cpp" line="130"/>
        <source>%1 (%2 colors)</source>
        <translation>%1（%2 个颜色）</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteWidget</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="64"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="231"/>
        <source>Open a new palette from file</source>
        <translation>从文件打开新调色板</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="75"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="234"/>
        <source>Create a new palette</source>
        <translation>创建新调色板</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="86"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="237"/>
        <source>Duplicate the current palette</source>
        <translation>制作当前调色板的副本</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="170"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="240"/>
        <source>Delete the current palette</source>
        <translation>删除当前调色板</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="181"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="243"/>
        <source>Revert changes to the current palette</source>
        <translation>将修改回退到当前调色板</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="192"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="246"/>
        <source>Save changes to the current palette</source>
        <translation>将修改保存到当前调色板</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="216"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="249"/>
        <source>Add a color to the palette</source>
        <translation>向调色板添加颜色</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="227"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="252"/>
        <source>Remove the selected color from the palette</source>
        <translation>从调色板移除选中的颜色</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="181"/>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="196"/>
        <source>New Palette</source>
        <translation>新建调色板</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="182"/>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="197"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="223"/>
        <source>GIMP Palettes (*.gpl)</source>
        <translation>GIMP 调色板 (*.gpl)</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="224"/>
        <source>Palette Image (%1)</source>
        <translation>调色板图像 (%1)</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="225"/>
        <source>All Files (*)</source>
        <translation>所有文件 (*)</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="226"/>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="239"/>
        <source>Open Palette</source>
        <translation>打开调色盘</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="240"/>
        <source>Failed to load the palette file
%1</source>
        <translation>加载调色板文件失败
%1</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientEditor</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_editor.cpp" line="321"/>
        <source>Add Color</source>
        <translation>添加颜色</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_editor.cpp" line="330"/>
        <source>Remove Color</source>
        <translation>移除颜色</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_editor.cpp" line="338"/>
        <source>Edit Color...</source>
        <translation>编辑颜色……</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientListModel</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_list_model.cpp" line="215"/>
        <source>%1 (%2 colors)</source>
        <translation>%1（%2 个颜色）</translation>
    </message>
</context>
<context>
    <name>color_widgets::Swatch</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/swatch.cpp" line="855"/>
        <source>Clear Color</source>
        <translation>清除颜色</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/swatch.cpp" line="864"/>
        <source>%1 (%2)</source>
        <translation>%1 (%2)</translation>
    </message>
</context>
</TS>
