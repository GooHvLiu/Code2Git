<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ca_ES">
<context>
    <name>AbstractWidgetList</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="52"/>
        <source>Add New</source>
        <translation>Afegir nou</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="103"/>
        <source>Move Up</source>
        <translation>Mou a Dalt</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="104"/>
        <source>Move Down</source>
        <translation>Mou Avall</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="105"/>
        <source>Remove</source>
        <translation>Elimina</translation>
    </message>
</context>
<context>
    <name>AcceptTool</name>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="31"/>
        <source>Accept</source>
        <translation>Accepta</translation>
    </message>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="41"/>
        <source>Accept the capture</source>
        <translation>Accepta la captura</translation>
    </message>
</context>
<context>
    <name>AppLauncher</name>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="23"/>
        <source>App Launcher</source>
        <translation>Llançador d&apos;aplicacions</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="33"/>
        <source>Choose an app to open the capture</source>
        <translation>Trieu una aplicació per obrir la captura</translation>
    </message>
</context>
<context>
    <name>AppLauncherWidget</name>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="50"/>
        <source>Open With</source>
        <translation>Obrir Amb</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="79"/>
        <source>Launch in terminal</source>
        <translation>Llança a la terminal</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="80"/>
        <source>Keep open after selection</source>
        <translation>Mantén obert després d&apos;una selecció</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="116"/>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="150"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="150"/>
        <source>Unable to launch in terminal.</source>
        <translation>No s&apos;ha pogut iniciar a la terminal.</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="116"/>
        <source>Unable to write in</source>
        <translation>No es pot escriure a</translation>
    </message>
</context>
<context>
    <name>ArrowTool</name>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="77"/>
        <source>Arrow</source>
        <translation>Fletxa</translation>
    </message>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="87"/>
        <source>Set the Arrow as the paint tool</source>
        <translation>Estableix la fletxa com a eina de dibuix</translation>
    </message>
</context>
<context>
    <name>BlurTool</name>
    <message>
        <source>Blur</source>
        <translation type="vanished">Desenfocament</translation>
    </message>
    <message>
        <source>Set Blur as the paint tool</source>
        <translation type="vanished">Estableix el desenfocament com a eina de dibuix</translation>
    </message>
</context>
<context>
    <name>CaptureLauncher</name>
    <message>
        <source>&lt;b&gt;Capture Mode&lt;/b&gt;</source>
        <translation type="vanished">&lt;b&gt;Mode de captura&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="33"/>
        <source>Rectangular Region</source>
        <translation>Regió rectangular</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="39"/>
        <source>Full Screen (Current Display)</source>
        <translation>Pantalla completa (monitor actual)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="42"/>
        <source>Full Screen (All Monitors)</source>
        <translation>Pantalla completa (tots els monitors)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="45"/>
        <source>No Delay</source>
        <translation>Sense demora</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="53"/>
        <source> second</source>
        <translation> segon</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="100"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="184"/>
        <location filename="../../src/widgets/capturelauncher.cpp" line="53"/>
        <source> seconds</source>
        <translation> segons</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="165"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="185"/>
        <source>Take new screenshot</source>
        <translation>Fes una nova captura de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="66"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="180"/>
        <source>Area:</source>
        <translation>Àrea:</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="177"/>
        <source>Capture Launcher</source>
        <translation>Llançador de Captures</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="34"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="178"/>
        <source>TextLabel</source>
        <translation>EtiquetaDeText</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="51"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="179"/>
        <source>Capture Mode</source>
        <translation>Mode de Captura</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="80"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="182"/>
        <source>Delay:</source>
        <translation>Demora:</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="93"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="183"/>
        <source>WxH+x+y</source>
        <translation>WxH+x+y</translation>
    </message>
</context>
<context>
    <name>CaptureWidget</name>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="112"/>
        <source>Unable to capture screen</source>
        <translatorcomment>Impossible capturar la pantalla</translatorcomment>
        <translation>Impossible capturar la pantalla</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="456"/>
        <source>Mouse</source>
        <translation>Ratolí</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="456"/>
        <source>Select screenshot area</source>
        <translation>Selecciona l&apos;àrea de captura de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="470"/>
        <source>Mouse Wheel</source>
        <translation>Roda del Ratolí</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="470"/>
        <source>Change tool size</source>
        <translation>Canvia mida de l&apos;eina</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="471"/>
        <source>Right Click</source>
        <translation>Clic Dret</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="471"/>
        <source>Show color picker</source>
        <translation>Mostra el selector de color</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="473"/>
        <source>Open side panel</source>
        <translation>Obre el panell lateral</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="474"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="474"/>
        <source>Exit</source>
        <translation>Surt</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="515"/>
        <source>Quit Capture</source>
        <translation>Surt de la Captura</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="516"/>
        <source>Are you sure you want to quit capture?</source>
        <translation>Esteu segur que voleu sortir de la captura?</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="521"/>
        <source>Do not show this again</source>
        <translation>No ho tornis a mostrar</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="727"/>
        <source>Flameshot has lost focus. Keyboard shortcuts won&apos;t work until you click somewhere.</source>
        <translation>Flameshot ha perdut el focus. Les dreceres de teclat no funcionaran fins que no facis clic en algun lloc.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="733"/>
        <source>Configuration error resolved. Launch `flameshot gui` again to apply it.</source>
        <translation>Error de configuració resolt. Torneu a iniciar `flameshot gui` per aplicar-lo.</translation>
    </message>
    <message>
        <source>Select an area with the mouse, or press Esc to exit.
Press Enter to capture the screen.
Press Right Click to show the color picker.
Use the Mouse Wheel to change the thickness of your tool.
Press Space to open the side panel.</source>
        <translation type="vanished">Escolliu una àrea amb el ratolí, o premeu Esc per sortir.
Premeu Entrar per capturar la pantalla.
Premeu clic dret per mostrar l&apos;eina de selecció de color.
Gireu la rodeta del ratolí per canviar el gruix de l&apos;eina de dibuix.
Premeu Espai per obrir el calaix lateral.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="1167"/>
        <source>Tool Settings</source>
        <translation>Ajustaments de l&apos;eina</translation>
    </message>
</context>
<context>
    <name>CircleCountTool</name>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="68"/>
        <source>Circle Counter</source>
        <translation>Comptador circular</translation>
    </message>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="86"/>
        <source>Add an autoincrementing counter bubble</source>
        <translation>Afegeix-hi un comptador automàtic</translation>
    </message>
</context>
<context>
    <name>CircleTool</name>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="20"/>
        <source>Circle</source>
        <translation>Cercle</translation>
    </message>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="30"/>
        <source>Set the Circle as the paint tool</source>
        <translation>Estableix el cercle com a eina de dibuix</translation>
    </message>
</context>
<context>
    <name>ColorDialog</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="19"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="312"/>
        <source>Select Color</source>
        <translation>Selecciona el Color</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="60"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="313"/>
        <source>Saturation</source>
        <translation>Saturació</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="67"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="314"/>
        <source>Hue</source>
        <translation>To</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="84"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="315"/>
        <source>Hex</source>
        <translation>Hex</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="91"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="316"/>
        <source>Blue</source>
        <translation>Blau</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="128"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="317"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="135"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="318"/>
        <source>Green</source>
        <translation>Verd</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="142"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="319"/>
        <source>Alpha</source>
        <translation>Alfa</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="149"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="320"/>
        <source>Red</source>
        <translation>Vermell</translation>
    </message>
</context>
<context>
    <name>ColorGrabWidget</name>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="58"/>
        <source>Accept color</source>
        <translation>Accepta el color</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="58"/>
        <source>Enter or Left Click</source>
        <translation>Enter o Clic amb el Botó Esquerre</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="59"/>
        <source>Precisely select color</source>
        <translation>Selecciona el color amb precisió</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="59"/>
        <source>Hold Left Click</source>
        <translation>Mantingueu premut el Botó Esquerre</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="60"/>
        <source>Toggle magnifier</source>
        <translation>Activa/desactiva la lupa</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="60"/>
        <source>Space or Right Click</source>
        <translation>Espai o Clic amb el Botó Dret</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="61"/>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="61"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>ColorPickerEditor</name>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="40"/>
        <source>Edit Preset:</source>
        <translation>Edita la Preconfiguració:</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="45"/>
        <source>Enter color to update preset</source>
        <translation>Introduïu el color per actualitzar la configuració predefinida</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="65"/>
        <source>Update</source>
        <translation>Actualitza</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="67"/>
        <source>Press button to update the selected preset</source>
        <translation>Premeu el botó per actualitzar la configuració predefinida seleccionada</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="74"/>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="76"/>
        <source>Press button to delete the selected preset</source>
        <translation>Premeu el botó per suprimir la configuració predefinida seleccionada</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="90"/>
        <source>Add Preset:</source>
        <translation>Afegeix un valor predefinit:</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="96"/>
        <source>Enter color manually or select it using the color-wheel</source>
        <translation>Introduïu el color manualment o seleccioneu-lo utilitzant la roda de colors</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="106"/>
        <source>Add</source>
        <translation>Afegir</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="107"/>
        <source>Press button to add preset</source>
        <translation>Premeu el botó per a afegir un predefinit</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="130"/>
        <location filename="../../src/config/colorpickereditor.cpp" line="147"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="131"/>
        <source>Unable to add preset. Maximum limit reached.</source>
        <translation>No s&apos;ha pogut afegir el predefinit. S&apos;ha arribat al límit màxim.</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="148"/>
        <source>Unable to remove preset. Minimum limit reached.</source>
        <translation>No s&apos;ha pogut eliminar el predefinit. S&apos;ha arribat al límit mínim.</translation>
    </message>
</context>
<context>
    <name>ConfigErrorDetails</name>
    <message>
        <location filename="../../src/config/configerrordetails.cpp" line="20"/>
        <source>Configuration errors</source>
        <translation>Errors de configuració</translation>
    </message>
</context>
<context>
    <name>ConfigHandler</name>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="579"/>
        <source>Unrecognized setting: &apos;%1&apos;
</source>
        <translation>Configuració no reconeguda: &apos;%1&apos;
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="587"/>
        <source>Unrecognized shortcut name: &apos;%1&apos;.
</source>
        <translation>Nom de drecera no reconegut: &apos;%1&apos;.
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="630"/>
        <source>Shortcut conflict: &apos;%1&apos; and &apos;%2&apos; have the same shortcut: %3
</source>
        <translation>Conflicte de drecera: &apos;%1&apos; i &apos;%2&apos; tenen la mateixa drecera: %3
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="668"/>
        <source>Bad value in &apos;%1&apos;. Expected: %2
</source>
        <translation>Valor incorrecte a &apos;%1&apos;. S&apos;esperava: %2
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="717"/>
        <source>You have successfully resolved the configuration error.</source>
        <translation>Heu resolt correctament l&apos;error de configuració.</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="740"/>
        <source>The configuration contains an error. Open configuration to resolve.</source>
        <translation>La configuració conté un error. Obre la configuració per resoldre-ho.</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="794"/>
        <source>Bad config key &apos;%1&apos; in ConfigHandler. Please report this as a bug.</source>
        <translation>La clau de configuració &apos;%1&apos; és incorrecta a ConfigHandler. Si us plau, informeu-nos d&apos;aquest error.</translation>
    </message>
</context>
<context>
    <name>ConfigResolver</name>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="14"/>
        <source>Resolve configuration errors</source>
        <translation>Resol els errors de configuració</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="50"/>
        <source>&lt;b&gt;You must resolve all errors before continuing:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Heu de resoldre tots els errors abans de continuar:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="61"/>
        <source>Reset</source>
        <translation>Reinicia</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="63"/>
        <source>Reset to the default value.</source>
        <translation>Restableix al valor per defecte.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="77"/>
        <source>Remove</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="79"/>
        <source>Remove this setting.</source>
        <translation>Elimina aquest paràmetre.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="90"/>
        <source>Some keyboard shortcuts have conflicts.
This will NOT prevent flameshot from starting.
Please solve them manually in the configuration file.</source>
        <translation>Algunes dreceres de teclat tenen conflictes.
Això NO impedirà que flameshot s&apos;iniciï.
Solucioneu-les manualment al fitxer de configuració.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="112"/>
        <source>Resolve all</source>
        <translation>Resol-ho tot</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="113"/>
        <source>Resolve all listed errors.</source>
        <translation>Resol tots els errors llistats.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="125"/>
        <source>Details</source>
        <translation>Detalls</translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="40"/>
        <source>Configuration</source>
        <translation>Ajustaments</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="68"/>
        <source>Interface</source>
        <translation>Interfície</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="78"/>
        <source>Filename Editor</source>
        <translation>Editor de noms de fitxer</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="59"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="87"/>
        <source>Shortcuts</source>
        <translation>Dreceres</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="120"/>
        <source>Resolve</source>
        <translation>Resol</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="124"/>
        <source>&lt;b&gt;Configuration file has errors. Resolve them before continuing.&lt;/b&gt;</source>
        <translation>&lt;b&gt;El fitxer de configuració té errors. Soluciona&apos;ls abans de continuar.&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>Controller</name>
    <message>
        <source>New version %1 is available</source>
        <translation type="vanished">La nova versió %1 ja és disponible</translation>
    </message>
    <message>
        <source>You have the latest version</source>
        <translation type="vanished">Teniu la versió més recent</translation>
    </message>
    <message>
        <source>Failed to get information about the latest version.</source>
        <translation type="vanished">Error a l&apos;intentar obtenir informació sobre actualitzacions.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="obsolete">Error</translation>
    </message>
    <message>
        <source>Unable to close active modal widgets</source>
        <translation type="vanished">No s&apos;han pogut tancar els widgets modals actius</translation>
    </message>
    <message>
        <source>&amp;Open Launcher</source>
        <translation type="vanished">&amp;Obre el llançador d&apos;aplicacions</translation>
    </message>
    <message>
        <source>&amp;Configuration</source>
        <translation type="vanished">&amp;Ajustaments</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation type="vanished">&amp;Quant a</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation type="vanished">Comprova si hi ha actualitzacions disponibles</translation>
    </message>
    <message>
        <source>&amp;Latest Uploads</source>
        <translation type="vanished">&amp;Últimes càrregues</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="vanished">&amp;Informació</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="vanished">&amp;Surt</translation>
    </message>
    <message>
        <source>&amp;Take Screenshot</source>
        <translation type="vanished">&amp;Captura</translation>
    </message>
</context>
<context>
    <name>CopyTool</name>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="24"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="34"/>
        <source>Copy selection to clipboard</source>
        <translation>Copia la selecció al porta-retalls</translation>
    </message>
    <message>
        <source>Copy the selection into the clipboard</source>
        <translation type="vanished">Copia la selecció al porta-retalls</translation>
    </message>
</context>
<context>
    <name>DBusUtils</name>
    <message>
        <source>Unable to connect via DBus</source>
        <translation type="vanished">No s&apos;ha pogut connectar mitjançant DBus</translation>
    </message>
</context>
<context>
    <name>ExitTool</name>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="23"/>
        <source>Exit</source>
        <translation>Surt</translation>
    </message>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="33"/>
        <source>Leave the capture screen</source>
        <translation>Surt de la pantalla de captura</translation>
    </message>
</context>
<context>
    <name>FileNameEditor</name>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="24"/>
        <source>Edit the name of your captures:</source>
        <translation>Editeu el nom de les vostres captures:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="28"/>
        <source>Edit:</source>
        <translation>Edita:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="30"/>
        <source>Preview:</source>
        <translation>Previsualització:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="73"/>
        <source>Save</source>
        <translation>Desa</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="76"/>
        <source>Saves the pattern</source>
        <translation>Desa el patró</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="78"/>
        <source>Restore</source>
        <translation>Restaura</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">Reinicialitza</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="81"/>
        <source>Restores the saved pattern</source>
        <translation>Restaura el patró desat</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="83"/>
        <source>Clear</source>
        <translation>Neteja</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="89"/>
        <source>Deletes the name</source>
        <translation>Elimina el nom</translation>
    </message>
</context>
<context>
    <name>Flameshot</name>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="119"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="119"/>
        <source>Unable to close active modal widgets</source>
        <translation>No s&apos;han pogut tancar els widgets modals actius</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="431"/>
        <source>URL copied to clipboard.</source>
        <translation>L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
</context>
<context>
    <name>FlameshotDaemon</name>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="407"/>
        <source>New version %1 is available</source>
        <translation>Nova versió %1 disponible</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="413"/>
        <source>You have the latest version</source>
        <translation>Teniu la versió més recent</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="422"/>
        <source>Failed to get information about the latest version.</source>
        <translation>Error a l&apos;intentar obtenir informació sobre actualitzacions.</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="445"/>
        <source>Unable to connect via DBus</source>
        <translation>No s&apos;ha pogut connectar a través del DBus</translation>
    </message>
</context>
<context>
    <name>GeneneralConf</name>
    <message>
        <source>Show help message</source>
        <translation type="vanished">Mostra el missatge d&apos;ajuda</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="vanished">Mostra el missatge d&apos;ajuda en iniciar el mode de captura.</translation>
    </message>
    <message>
        <source>Show desktop notifications</source>
        <translation type="vanished">Mostra les notificacions d&apos;escriptori</translation>
    </message>
    <message>
        <source>Show tray icon</source>
        <translation type="vanished">Mostra la icona en la barra de tasques</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="vanished">Mostra la icona en la barra de tasques</translation>
    </message>
    <message>
        <source>Import</source>
        <translation type="vanished">Importar</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">Error</translation>
    </message>
    <message>
        <source>Unable to read file.</source>
        <translation type="vanished">Impossible llegir el fitxer.</translation>
    </message>
    <message>
        <source>Unable to write file.</source>
        <translation type="vanished">Impossible escriure al fitxer.</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation type="vanished">Guardar Arxiu</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation type="vanished">Confirmar Reset</translation>
    </message>
    <message>
        <source>Are you sure you want to reset the configuration?</source>
        <translation type="vanished">Esteu segur que voleu reiniciar la configuració?</translation>
    </message>
    <message>
        <source>Configuration File</source>
        <translation type="vanished">Fitxer de Configuració</translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="vanished">Exportar</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">Reset</translation>
    </message>
    <message>
        <source>Launch at startup</source>
        <translation type="vanished">Llançament a l&apos;inici</translation>
    </message>
</context>
<context>
    <name>GeneralConf</name>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="192"/>
        <location filename="../../src/config/generalconf.cpp" line="394"/>
        <source>Import</source>
        <translation>Importa</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="198"/>
        <location filename="../../src/config/generalconf.cpp" line="207"/>
        <location filename="../../src/config/generalconf.cpp" line="232"/>
        <location filename="../../src/config/generalconf.cpp" line="763"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="198"/>
        <source>Unable to read file.</source>
        <translation>No s&apos;ha pogut llegir el fitxer.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="207"/>
        <location filename="../../src/config/generalconf.cpp" line="232"/>
        <source>Unable to write file.</source>
        <translation>No s&apos;ha pogut escriure al fitxer.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="219"/>
        <source>Save File</source>
        <translation>Desa l&apos;arxiu</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="241"/>
        <source>Confirm Reset</source>
        <translation>Confirma la reinicialització</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="242"/>
        <source>Are you sure you want to reset the configuration?</source>
        <translation>Esteu segur de voler reinicialitzar els ajustaments?</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="273"/>
        <source>Show help message</source>
        <translation>Mostra el missatge d&apos;ajuda</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="obsolete">Mostra el missatge d&apos;ajuda en iniciar el mode de captura.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="298"/>
        <source>Show the side panel button</source>
        <translation>Mostra el botó del calaix lateral</translation>
    </message>
    <message>
        <source>Show the side panel toggle button in the capture mode.</source>
        <translation type="vanished">Mostra el botó del calaix lateral en el mode de captura.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="311"/>
        <source>Show desktop notifications</source>
        <translation>Mostra les notificacions d&apos;escriptori</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="336"/>
        <source>Show tray icon</source>
        <translation>Mostra la icona de la safata</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="vanished">Mostra la icona a la barra de tasques del sistema</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="367"/>
        <source>Confirmation required to delete screenshot from the latest uploads</source>
        <translation>Es requereix confirmació per esborrar la captura de pantalla de les darreres càrregues</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="382"/>
        <source>Configuration File</source>
        <translation>Fitxer d&apos;Ajustaments</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="387"/>
        <source>Export</source>
        <translation>Exporta</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="401"/>
        <source>Reset</source>
        <translation>Reinicialitza</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="412"/>
        <source>Automatic check for updates</source>
        <translation>Comprova les actualitzacions de forma automàtica</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="426"/>
        <source>Allow multiple flameshot GUI instances simultaneously</source>
        <translation>Permet múltiples instàncies de la interfície gràfica de flameshot simultàniament</translation>
    </message>
    <message>
        <source>This allows you to take screenshots of flameshot itself for example.</source>
        <translation type="vanished">This allows you to take screenshots of flameshot itself for example.</translation>
    </message>
    <message>
        <source>Automatically close daemon when it is not needed</source>
        <translation type="vanished">Automatically close daemon when it is not needed</translation>
    </message>
    <message>
        <source>Launch at startup</source>
        <translation type="vanished">Llança a l&apos;inici</translation>
    </message>
    <message>
        <source>Launch Flameshot</source>
        <translation type="vanished">Inicia el Flameshot</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="463"/>
        <source>Show welcome message on launch</source>
        <translation>Mostra el missatge de benvinguda a l&apos;inici</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="491"/>
        <source>Use large predefined color palette</source>
        <translation>Usa paleta de colors gran predefinida</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="515"/>
        <source>Copy URL after upload</source>
        <translation>Copia l&apos;URL després de la càrrega</translation>
    </message>
    <message>
        <source>Copy URL and close window after upload</source>
        <translation type="vanished">Copia la URL i tanca la finestra després de la càrrega</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="527"/>
        <source>Save image after copy</source>
        <translation>Desa la imatge després d&apos;haver-la copiat</translation>
    </message>
    <message>
        <source>Save image file after copying it</source>
        <translation type="vanished">Desa el fitxer d&apos;imatge després d&apos;haver-lo copiat</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="274"/>
        <source>Show the help message at the beginning in the capture mode</source>
        <translation>Mostra el missatge d&apos;ajuda al començament en el mode de captura</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="284"/>
        <source>Use last region for GUI mode</source>
        <translation>Utilitza l&apos;última regió per al mode GUI</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="286"/>
        <source>Use the last region as the default selection for the next screenshot in GUI mode</source>
        <translation>Utilitza l&apos;última regió com a selecció predeterminada per a la següent captura de pantalla en mode GUI</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="300"/>
        <source>Show the side panel toggle button in the capture mode</source>
        <translation>Mostra el botó de commutació del plafó lateral en el mode de captura</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="312"/>
        <source>Enable desktop notifications</source>
        <translation>Habilita les notificacions de l&apos;escriptori</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="323"/>
        <source>Show abort notifications</source>
        <translation>Mostra les notificacions d&apos;avortament</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="324"/>
        <source>Enable abort notifications</source>
        <translation>Habilita les notificacions d&apos;avortament</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="337"/>
        <source>Show icon in the system tray</source>
        <translation>Mostra la icona a la safata del sistema</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="350"/>
        <source>Use grim to capture screenshots</source>
        <translation>Usa grim per a fer les captures de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="352"/>
        <source>Grim is a wayland only utility to capture screens based on the screencopy protocol. Generally only enable on minimal wayland window managers like sway, hyprland, etc.</source>
        <translation>Grim és una utilitat només de wayland per capturar pantalles basades en el protocol de còpia de pantalla. En general, només s&apos;habilita en gestors de finestres minimalistes de wayland com sway, hyprland, etc.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="370"/>
        <source>Ask for confirmation to delete screenshot from the latest uploads</source>
        <translation>Demana confirmació per suprimir la captura de pantalla de les darreres pujades</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="413"/>
        <source>Check for updates automatically</source>
        <translation>Comprova automàticament si hi ha actualitzacions</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="427"/>
        <source>This allows you to take screenshots of Flameshot itself for example</source>
        <translation>Això permet prendre captures de pantalla del mateix Flameshot per exemple</translation>
    </message>
    <message>
        <source>Launch Flameshot daemon when computer is booted</source>
        <translation type="vanished">Launch Flameshot daemon when computer is booted</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="466"/>
        <source>Show the welcome message box in the middle of the screen while taking a screenshot</source>
        <translation>Mostra el quadre de missatge de benvinguda al mig de la pantalla mentre es pren una captura de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="493"/>
        <source>Use a large predefined color palette</source>
        <translation>Usa una paleta de colors gran predefinida</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="503"/>
        <source>Copy on double click</source>
        <translation>Copia en fer doble clic</translation>
    </message>
    <message>
        <source>Enable Copy on Double Click</source>
        <translation type="vanished">Enable Copy on Double Click</translation>
    </message>
    <message>
        <source>Copy URL and close window after uploading was successful</source>
        <translation type="vanished">Copy URL and close window after uploading was successful</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="439"/>
        <source>Automatically unload from memory when it is not needed</source>
        <translation>Descarrega automàticament de la memòria quan no sigui necessari</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="440"/>
        <source>Automatically close daemon (background process) when it is not needed</source>
        <translation>Tanca automàticament el dimoni (procés de fons) quan no sigui necessari</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="451"/>
        <source>Launch in background at startup</source>
        <translation>Llança en segon pla a l&apos;inici</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="452"/>
        <source>Launch Flameshot daemon (background process) when computer is booted</source>
        <translation>Llança el dimoni Flameshot (procés de fons) quan s&apos;arrenqui l&apos;ordinador</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="477"/>
        <source>Ask before quit capture</source>
        <translation>Pregunta abans de sortir de la captura</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="480"/>
        <source>Show the confirmation prompt before ESC quit</source>
        <translation>Mostra el missatge de confirmació abans de sortir amb ESC</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="505"/>
        <source>Enable Copy to clipboard on Double Click</source>
        <translation>Habilita la Còpia al porta-retalls en fer Doble Clic</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="517"/>
        <source>Copy URL after uploading was successful</source>
        <translation>Copia l&apos;URL després que la càrrega sigui correcta</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="529"/>
        <source>After copying the screenshot, save it to a file as well</source>
        <translation>Després de copiar la captura de pantalla, desa-la també en un fitxer</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="536"/>
        <source>Save Path</source>
        <translation>Desa la Ruta</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="552"/>
        <source>Change...</source>
        <translation>Canvia...</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="560"/>
        <source>Use fixed path for screenshots to save</source>
        <translation>Fes servir una ruta fixada per desar-hi les captures de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="572"/>
        <source>Preferred save file extension:</source>
        <translation>Extensió de fitxer preferida al desar:</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="601"/>
        <source>Latest Uploads Max Size</source>
        <translation>Mida Màxima de les Últimes Càrregues</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="623"/>
        <source>Imgur Application Client ID</source>
        <translation>Client ID de l&apos;Aplicació Imgur</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="654"/>
        <source>Undo limit</source>
        <translation>Desfes el límit</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="683"/>
        <source>Use JPG format for clipboard (PNG default)</source>
        <translation>Fes servir el format JPG per les imatges del porta-retalls (per defecte és PNG)</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="685"/>
        <source>Use lossy JPG format for clipboard (lossless PNG default)</source>
        <translation>Usa el format JPG amb pèrdua per al porta-retalls (per defecte PNG sense pèrdua)</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="711"/>
        <source>Copy file path after save</source>
        <translation>Copia la ruta a l&apos;arxiu després d&apos;haver-lo desat</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="712"/>
        <source>Copy the file path to clipboard after the file is saved</source>
        <translation>Copia la ruta del fitxer al porta-retalls després que el fitxer sigui desat</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="723"/>
        <source>Anti-aliasing image when zoom the pinned image</source>
        <translation>Antialiasing de la imatge quan es fa zoom a la imatge fixada</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="725"/>
        <source>After zooming the pinned image, should the image get smoothened or stay pixelated</source>
        <translation>Després de fer zoom a la imatge fixada, s&apos;hauria de suavitzar la imatge o quedar pixelada</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="736"/>
        <location filename="../../src/config/generalconf.cpp" line="738"/>
        <source>Upload image without confirmation</source>
        <translation>Puja la imatge sense confirmació</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="754"/>
        <source>Choose a Folder</source>
        <translation>Escull una carpeta</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="763"/>
        <source>Unable to write to directory.</source>
        <translation>No s&apos;ha pogut escriure al directori.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="772"/>
        <source>Show magnifier</source>
        <translation>Mostra la lupa</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="773"/>
        <source>Enable a magnifier while selecting the screenshot area</source>
        <translation>Habilita la lupa mentre se selecciona l&apos;àrea de captura de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="784"/>
        <source>Square shaped magnifier</source>
        <translation>Lupa en forma de quadrat</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="785"/>
        <source>Make the magnifier to be square-shaped</source>
        <translation>Fes que la lupa sigui de forma quadrada</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="801"/>
        <source>Milliseconds before geometry display hides; 0 means do not hide</source>
        <translation>Mil·lisegons abans que s&apos;oculti la visualització de la geometria; 0 significa que no s&apos;oculta</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="804"/>
        <source>Set geometry display timeout (ms)</source>
        <translation>Estableix el temps d&apos;espera de la visualització de la geometria (ms)</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="812"/>
        <source>Selection Geometry Display</source>
        <translation>Visualització de la Geometria de la Selecció</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="819"/>
        <source>Display Location</source>
        <translation>Mostra la Ubicació</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="822"/>
        <source>None</source>
        <translation>Cap</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="823"/>
        <source>Top Left</source>
        <translation>A Dalt a l&apos;Esquerra</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="825"/>
        <source>Top Right</source>
        <translation>A Dalt a la Dreta</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="827"/>
        <source>Bottom Left</source>
        <translation>A Baix a l&apos;Esquerra</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="829"/>
        <source>Bottom Right</source>
        <translation>A Baix a la Dreta</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="831"/>
        <source>Center</source>
        <translation>Centre</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="856"/>
        <source>Quality range of 0-100; Higher number is better quality and larger file size</source>
        <translation>Interval de qualitat de 0-100; un valor més alt és una millor qualitat i una mida de fitxer més gran</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="860"/>
        <source>JPEG Quality</source>
        <translation>Qualitat JPEG</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="871"/>
        <source>Reverse arrow</source>
        <translation>Fletxa inversa</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="872"/>
        <source>Draw the arrow head first</source>
        <translation>Dibuixa primer la punta de la fletxa</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="881"/>
        <source>Insecure Pixelate</source>
        <translation>Pixelat Insegur</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="883"/>
        <source>Draw the pixelation effect in an insecure but more asethetic way.</source>
        <translation>Dibuixa l&apos;efecte de pixelació d&apos;una manera insegura però més asètica.</translation>
    </message>
</context>
<context>
    <name>HistoryWidget</name>
    <message>
        <source>Latest Uploads</source>
        <translation type="vanished">Últimes càrregues</translation>
    </message>
    <message>
        <source>Screenshots history is empty</source>
        <translation type="vanished">L&apos;historial de captures de pantalla és buit</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="obsolete">Copia l&apos;URL</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>Open in browser</source>
        <translation type="vanished">Obre al navegador</translation>
    </message>
    <message>
        <source>Confirm to delete</source>
        <translation type="vanished">Confirmeu per esborrar</translation>
    </message>
    <message>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation type="vanished">Esteu segur de voler esborrar la captura de les últimes càrregues i del servidor?</translation>
    </message>
</context>
<context>
    <name>ImgS3Uploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">S&apos;està pujant la imatge</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="obsolete">Error</translation>
    </message>
</context>
<context>
    <name>ImgUploadDialog</name>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="18"/>
        <source>Upload Confirmation</source>
        <translation>Confirmació de Càrrega</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="22"/>
        <source>Do you want to upload this capture?</source>
        <translation>Vols pujar aquesta captura?</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="35"/>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="36"/>
        <source>Upload without confirmation</source>
        <translation>Carrega sense confirmació</translation>
    </message>
</context>
<context>
    <name>ImgUploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">S&apos;està pujant la imatge</translation>
    </message>
    <message>
        <source>Delete image</source>
        <translation type="obsolete">Esborra la imatge</translation>
    </message>
    <message>
        <source>Unable to open the URL.</source>
        <translation type="obsolete">No es pot obrir l&apos;URL.</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="obsolete">La captura s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="obsolete">Copia l&apos;URL</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="obsolete">Obri l&apos;URL</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="obsolete">Imatge al porta-retalls.</translation>
    </message>
</context>
<context>
    <name>ImgUploaderBase</name>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="37"/>
        <source>Upload image</source>
        <translation>Puja una Imatge</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="49"/>
        <source>Uploading Image</source>
        <translation>S&apos;està pujant la imatge</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="128"/>
        <source>Copy URL</source>
        <translation>Copia l&apos;URL</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="129"/>
        <source>Open URL</source>
        <translation>Obre l&apos;URL</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="130"/>
        <source>Delete image</source>
        <translation>Esborra la imatge</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="131"/>
        <source>Image to Clipboard.</source>
        <translation>Imatge al Porta-retalls.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="132"/>
        <source>Save image</source>
        <translation>Desa la imatge</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="162"/>
        <source>Unable to open the URL.</source>
        <translation>No s&apos;ha pogut obrir l&apos;URL.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="169"/>
        <source>URL copied to clipboard.</source>
        <translation>L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="175"/>
        <source>Screenshot copied to clipboard.</source>
        <translation>La captura s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="189"/>
        <source>Unable to save the screenshot to disk.</source>
        <translation>No s&apos;ha pogut desar la captura de pantalla al disc.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="192"/>
        <source>Screenshot saved.</source>
        <translation>Captura de pantalla desada.</translation>
    </message>
</context>
<context>
    <name>ImgUploaderTool</name>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="23"/>
        <source>Image Uploader</source>
        <translation>Carregador d&apos;Imatges</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="33"/>
        <source>Upload the selection</source>
        <translation>Puja la selecció</translation>
    </message>
</context>
<context>
    <name>ImgurUploader</name>
    <message>
        <source>Upload to Imgur</source>
        <translation type="vanished">Puja a Imgur</translation>
    </message>
    <message>
        <source>Uploading Image</source>
        <translation type="vanished">S&apos;està pujant la imatge</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="vanished">Copia l&apos;URL</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="vanished">Obre l&apos;URL</translation>
    </message>
    <message>
        <source>Delete image</source>
        <translation type="vanished">Esborra la imatge</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="vanished">Imatge al porta-retalls.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imgur/imguruploader.cpp" line="107"/>
        <source>Unable to open the URL.</source>
        <translation>No s&apos;ha pogut obrir l&apos;URL.</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="vanished">La captura s&apos;ha copiat al porta-retalls.</translation>
    </message>
</context>
<context>
    <name>ImgurUploaderTool</name>
    <message>
        <source>Image Uploader</source>
        <translation type="vanished">Puja la imatge</translation>
    </message>
    <message>
        <source>Upload the selection to Imgur</source>
        <translation type="vanished">Puja la selecció a Imgur</translation>
    </message>
</context>
<context>
    <name>InfoWindow</name>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="116"/>
        <source>About</source>
        <translation>Quant a</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="26"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="117"/>
        <source>Icon</source>
        <translation>Icona</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="43"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="118"/>
        <source>License</source>
        <translation>Llicència</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="56"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="119"/>
        <source>GPLv3+</source>
        <translation>GPLv3+</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="89"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="120"/>
        <source>Version</source>
        <translation>Versió</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="102"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="121"/>
        <source>Flameshot v</source>
        <translation>Flameshot v</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="115"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="122"/>
        <source>OS Info</source>
        <translation>Informació del Sistema Operatiu</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="128"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="123"/>
        <source>Copy Info</source>
        <translation>Copia la informació</translation>
    </message>
    <message>
        <source>Right Click</source>
        <translation type="vanished">Clic dret</translation>
    </message>
    <message>
        <source>Mouse Wheel</source>
        <translation type="vanished">Roda del ratolí</translation>
    </message>
    <message>
        <source>Move selection 1px</source>
        <translation type="vanished">Mou la selecció 1 px</translation>
    </message>
    <message>
        <source>Resize selection 1px</source>
        <translation type="vanished">Redimensiona la selecció 1 px</translation>
    </message>
    <message>
        <source>Quit capture</source>
        <translation type="vanished">Ix de la captura</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation type="vanished">Copia al porta-retalls</translation>
    </message>
    <message>
        <source>Save selection as a file</source>
        <translation type="vanished">Guarda la selecció com a fitxer</translation>
    </message>
    <message>
        <source>Undo the last modification</source>
        <translation type="vanished">Desfés l&apos;última modificació</translation>
    </message>
    <message>
        <source>Show color picker</source>
        <translation type="vanished">Mostra el selector de color</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="vanished">Canvia el gruix de l&apos;eina</translation>
    </message>
    <message>
        <source>Key</source>
        <translation type="vanished">Tecla</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="vanished">Descripció</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;License&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Llicència&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Version&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Versió&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Shortcuts&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Dreceres&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation type="vanished">Dreceres disponibles en el mode de captura de pantalla.</translation>
    </message>
</context>
<context>
    <name>InvertTool</name>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="25"/>
        <source>Invert</source>
        <translation>Inverteix</translation>
    </message>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="35"/>
        <source>Set Inverter as the paint tool</source>
        <translation>Estableix l&apos;Inversor com a eina de pintura</translation>
    </message>
</context>
<context>
    <name>LineTool</name>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="22"/>
        <source>Line</source>
        <translation>Línia</translation>
    </message>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="32"/>
        <source>Set the Line as the paint tool</source>
        <translation>Estableix la Línia com a eina de dibuix</translation>
    </message>
</context>
<context>
    <name>MarkerTool</name>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="23"/>
        <source>Marker</source>
        <translation>Marcador</translation>
    </message>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="33"/>
        <source>Set the Marker as the paint tool</source>
        <translation>Estableix el marcador com a eina de dibuix</translation>
    </message>
</context>
<context>
    <name>MoveTool</name>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="23"/>
        <source>Move</source>
        <translation>Mou</translation>
    </message>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="33"/>
        <source>Move the selection area</source>
        <translation>Mou la selecció</translation>
    </message>
</context>
<context>
    <name>PencilTool</name>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="18"/>
        <source>Pencil</source>
        <translation>Llapis</translation>
    </message>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="28"/>
        <source>Set the Pencil as the paint tool</source>
        <translation>Estableix el Llapis com a eina de dibuix</translation>
    </message>
</context>
<context>
    <name>PinTool</name>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="25"/>
        <source>Pin Tool</source>
        <translation>Ancora l&apos;eina</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="35"/>
        <source>Pin image on the desktop</source>
        <translation>Ancora l&apos;imatge a l&apos;escriptori</translation>
    </message>
</context>
<context>
    <name>PinWidget</name>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="282"/>
        <source>Context menu</source>
        <translation>Menú contextual</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="284"/>
        <source>Copy to clipboard</source>
        <translation>Copia al porta-retalls</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="291"/>
        <source>Save to file</source>
        <translation>Desa a un fitxer</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="298"/>
        <source>Rotate Right</source>
        <translation>Gira cap a la Dreta</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="303"/>
        <source>Rotate Left</source>
        <translation>Gira cap a l&apos;Esquerra</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="308"/>
        <source>Increase Opacity</source>
        <translation>Augmenta l&apos;Opacitat</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="315"/>
        <source>Decrease Opacity</source>
        <translation>Disminueix l&apos;Opacitat</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="322"/>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
</context>
<context>
    <name>PixelateTool</name>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="27"/>
        <source>Pixelate</source>
        <translation>Pixel·la</translation>
    </message>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="37"/>
        <source>Set Pixelate as the paint tool.</source>
        <translation>Estableix el Pixelat com a eina de pintura.</translation>
    </message>
    <message>
        <source>Set Pixelate as the paint tool</source>
        <translation type="vanished">Estableix l&apos;eina de pixel·lament com a eina de dibuix</translation>
    </message>
</context>
<context>
    <name>PrimaryInstanceWidget</name>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/primaryinstancewidget.cpp" line="21"/>
        <source>Primary instance</source>
        <translation>Instància primària</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/primaryinstancewidget.cpp" line="22"/>
        <source>&lt;b&gt;Primary instance.&lt;/b&gt; Messages received from secondaries:</source>
        <translation>&lt;b&gt;Instància primària.&lt;/b&gt; Missatges rebuts de les secundàries:</translation>
    </message>
</context>
<context>
    <name>QHotkey</name>
    <message>
        <source>Failed to register %1. Error: %2</source>
        <translation type="vanished">No s&apos;ha pogut registrar %1. Error: %2</translation>
    </message>
    <message>
        <source>Failed to unregister %1. Error: %2</source>
        <translation type="vanished">No s&apos;ha pogut desregistrar %1. Error: %2</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="196"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="198"/>
        <source>Capture saved to clipboard.</source>
        <translation>Captura copiada al porta-retalls.</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="182"/>
        <source>Error while saving to clipboard</source>
        <translation>S&apos;ha produït un error mentre es copiava al porta-retalls</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="244"/>
        <source>Save screenshot</source>
        <translation>Desa la captura</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="275"/>
        <source>Path copied to clipboard as </source>
        <translation>Ruta copiada al porta-retalls com a </translation>
    </message>
    <message>
        <source>Saving canceled</source>
        <translation type="vanished">Saving canceled</translation>
    </message>
    <message>
        <source>Save canceled</source>
        <translation type="vanished">Save canceled</translation>
    </message>
    <message>
        <source>Capture is saved and copied to the clipboard as </source>
        <translation type="vanished">La captura serà desada i copiada al porta-retalls com a </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="286"/>
        <source>Save Error</source>
        <translation>S&apos;ha produït un error en guardar</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="62"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="267"/>
        <source>Capture saved as </source>
        <translation>Anomena i guarda la captura </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="66"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="279"/>
        <source>Error trying to save as </source>
        <translation>S&apos;ha produït un error en anomenar i guardar </translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="220"/>
        <source>Unable to connect via DBus</source>
        <translation>No es pot connectar mitjançant DBus</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="237"/>
        <source>Powerful yet simple to use screenshot software.</source>
        <translation>Un programa de captures complert i versàtil.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="238"/>
        <source>See</source>
        <translation>Vegeu</translation>
    </message>
    <message>
        <source>Capture the entire desktop.</source>
        <translation type="vanished">Captureu l&apos;escriptori sencer.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="244"/>
        <source>Open the capture launcher.</source>
        <translation>Obriu el llançador de captures.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="247"/>
        <source>Start a manual capture in GUI mode.</source>
        <translation>Comença una captura manual en mode d&apos;interfície.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="249"/>
        <source>Configure</source>
        <translation>Configura</translation>
    </message>
    <message>
        <source>Capture a single screen.</source>
        <translation type="vanished">Captura una sola pantalla.</translation>
    </message>
    <message>
        <source>Path where the capture will be saved</source>
        <translation type="vanished">Camí on es desarà la captura</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="242"/>
        <source>Capture screenshot of all monitors at the same time.</source>
        <translation>Captura la pantalla de tots els monitors al mateix temps.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="252"/>
        <source>Capture a screenshot of the specified monitor.</source>
        <translation>Captura la pantalla del monitor especificat.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="257"/>
        <source>Existing directory or new file to save to</source>
        <translation>Directori existent o nou fitxer per desar</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="260"/>
        <source>Save the capture to the clipboard</source>
        <translation>Desa la captura al porta-retalls</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="262"/>
        <source>Pin the capture to the screen</source>
        <translation>Fixa la captura a la pantalla</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="264"/>
        <source>Upload screenshot</source>
        <translation>Puja la captura de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="266"/>
        <source>Delay time in milliseconds</source>
        <translation>Temps de demora en mil·lisegons</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="271"/>
        <source>Repeat screenshot with previously selected region</source>
        <translation>Repeteix la captura de pantalla amb la regió seleccionada prèviament</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="274"/>
        <source>Screenshot region to select</source>
        <translation>Regió de captura de pantalla a seleccionar</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="277"/>
        <source>Set the filename pattern</source>
        <translation>Estableix el patró del nom de fitxer</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="281"/>
        <source>Accept capture as soon as a selection is made</source>
        <translation>Accepta la captura tan aviat com es faci una selecció</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="283"/>
        <source>Enable or disable the trayicon</source>
        <translation>Activa o desactiva l&apos;icona a la safata</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="287"/>
        <source>Enable or disable run at startup</source>
        <translation>Activa o desactiva l&apos;execució a l&apos;inici</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="291"/>
        <source>Enable or disable the notifications</source>
        <translation>Activa o desactiva les notificacions</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="294"/>
        <source>Check the configuration for errors</source>
        <translation>Comprova si hi ha errors a la configuració</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="297"/>
        <source>Show the help message in the capture mode</source>
        <translation>Mostra el missatge d&apos;ajuda en el mode de captura</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="300"/>
        <source>Define the main UI color</source>
        <translation>Defineix el color principal de la IU</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="304"/>
        <source>Define the contrast UI color</source>
        <translation>Defineix el color de contrast de la interfície d&apos;usuari</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="307"/>
        <source>Print raw PNG capture</source>
        <translation>Imprimeix la captura PNG en brut</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="310"/>
        <source>Print geometry of the selection in the format WxH+X+Y. Does nothing if raw is specified</source>
        <translation>Imprimeix la geometria de la selecció en el format WxH+X+Y. No fa res si s&apos;especifica &apos;raw&apos;</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="314"/>
        <source>Define the screen to capture (starting from 0)</source>
        <translation>Defineix la pantalla a capturar (començant des de 0)</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="334"/>
        <source>Invalid delay, it must be a number greater than 0</source>
        <translation>Retard no vàlid, ha de ser un nombre més gran que 0</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="337"/>
        <source>Invalid region, use &apos;WxH+X+Y&apos; or &apos;all&apos; or &apos;screen0/screen1/...&apos;.</source>
        <translation>Regió no vàlida, utilitzeu &apos;WxH+X+Y&apos; o &apos;all&apos; o &apos;screen0/screen1/...&apos;.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="350"/>
        <source>Invalid path, must be an existing directory or a new file in an existing directory</source>
        <translation>Ruta no vàlida, ha de ser un directori existent o un fitxer nou en un directori existent</translation>
    </message>
    <message>
        <source>Define the screen to capture</source>
        <translation type="vanished">Define the screen to capture</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="315"/>
        <source>default: screen containing the cursor</source>
        <translation>per defecte: pantalla que conté el cursor</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="316"/>
        <source>Screen number</source>
        <translation>Screen number</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="325"/>
        <source>Invalid color, this flag supports the following formats:
- #RGB (each of R, G, and B is a single hex digit)
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- Named colors like &apos;blue&apos; or &apos;red&apos;
You may need to escape the &apos;#&apos; sign as in &apos;\#FFF&apos;</source>
        <translation>Color no vàlid, aquest indicador admet els següents formats:
- #RGB (cadascun de R, G, i B és un sol dígit hexadecimal)
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- Colors amb nom com &apos;blue&apos; o &apos;red&apos;
És possible que hàgiu d&apos;escapar del signe &apos;#&apos; com a &apos;\#FFF&apos;</translation>
    </message>
    <message>
        <source>Invalid delay, it must be higher than 0</source>
        <translation type="vanished">Invalid delay, it must be higher than 0</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="336"/>
        <source>Invalid screen number, it must be non negative</source>
        <translation>Número de pantalla no vàlid, ha de ser no negatiu</translation>
    </message>
    <message>
        <source>Invalid path, it must be a real path in the system</source>
        <translation type="vanished">Invalid path, it must be a real path in the system</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="363"/>
        <source>Invalid value, it must be defined as &apos;true&apos; or &apos;false&apos;</source>
        <translation>Valor no vàlid, s&apos;ha de definir com a &apos;true&apos; o &apos;false&apos;</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="30"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="31"/>
        <source>Unable to write in</source>
        <translation>No es pot escriure a</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="156"/>
        <source>Requested screen exceeds screen count</source>
        <translation>La pantalla sol·licitada supera el nombre de pantalles</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="408"/>
        <source>Full screen screenshot pinned to screen</source>
        <translation>Captura de pantalla de la pantalla completa fixada a la pantalla</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="54"/>
        <source>Options</source>
        <translation>Opcions</translation>
    </message>
    <message>
        <source>Arguments</source>
        <translation type="vanished">Arguments</translation>
    </message>
    <message>
        <source>arguments</source>
        <translation type="vanished">arguments</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="68"/>
        <source>Subcommands</source>
        <translation>Subcomandes</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="328"/>
        <source>subcommands</source>
        <translation>subcomandes</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="329"/>
        <source>Usage</source>
        <translation>Ús</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="329"/>
        <source>options</source>
        <translation>opcions</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="334"/>
        <source>Per default runs Flameshot in the background and adds a tray icon for configuration.</source>
        <translation>Per defecte, Flameshot s&apos;executa en segon pla i afegeix una icona a la safata per a la configuració.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="71"/>
        <source>Hello, I&apos;m here! Click icon in the tray to take a screenshot or click with a right button to see more options.</source>
        <translation>Hola, sóc aquí! Fes clic a la icona de la safata per fer una captura de pantalla o fes clic amb el botó dret per veure més opcions.</translation>
    </message>
    <message>
        <source>Toggle side panel</source>
        <translation type="vanished">Toggle side panel</translation>
    </message>
    <message>
        <source>Resize selection left 1px</source>
        <translation type="vanished">Resize selection left 1px</translation>
    </message>
    <message>
        <source>Resize selection right 1px</source>
        <translation type="vanished">Resize selection right 1px</translation>
    </message>
    <message>
        <source>Resize selection up 1px</source>
        <translation type="vanished">Resize selection up 1px</translation>
    </message>
    <message>
        <source>Resize selection down 1px</source>
        <translation type="vanished">Resize selection down 1px</translation>
    </message>
    <message>
        <source>Select entire screen</source>
        <translation type="vanished">Select entire screen</translation>
    </message>
    <message>
        <source>Move selection left 1px</source>
        <translation type="vanished">Move selection left 1px</translation>
    </message>
    <message>
        <source>Move selection right 1px</source>
        <translation type="vanished">Move selection right 1px</translation>
    </message>
    <message>
        <source>Move selection up 1px</source>
        <translation type="vanished">Move selection up 1px</translation>
    </message>
    <message>
        <source>Move selection down 1px</source>
        <translation type="vanished">Move selection down 1px</translation>
    </message>
    <message>
        <source>Commit text in text area</source>
        <translation type="vanished">Commit text in text area</translation>
    </message>
    <message>
        <source>Delete current tool</source>
        <translation type="vanished">Delete current tool</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="195"/>
        <source>Quit capture</source>
        <translation>Ix de la captura</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="207"/>
        <source>Screenshot history</source>
        <translation>Historial de captures de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="211"/>
        <source>Capture screen</source>
        <translation>Captura de pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="218"/>
        <source>Show color picker</source>
        <translation>Mostra el selector de color</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="219"/>
        <source>Change the tool&apos;s size</source>
        <translation>Canvia la mida de l&apos;eina</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="obsolete">Canvia el gruix de l&apos;eina</translation>
    </message>
</context>
<context>
    <name>RectangleTool</name>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="22"/>
        <source>Rectangle</source>
        <translation>Rectangle</translation>
    </message>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="32"/>
        <source>Set the Rectangle as the paint tool</source>
        <translation>Estableix el rectangle com a eina de dibuix</translation>
    </message>
</context>
<context>
    <name>RedoTool</name>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="23"/>
        <source>Redo</source>
        <translation>Refés</translation>
    </message>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="33"/>
        <source>Redo the next modification</source>
        <translation>Refés la següent modificació</translation>
    </message>
</context>
<context>
    <name>SaveTool</name>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="24"/>
        <source>Save</source>
        <translation>Guarda</translation>
    </message>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="34"/>
        <source>Save screenshot to a file</source>
        <translation>Desa la captura de pantalla a un fitxer</translation>
    </message>
    <message>
        <source>Save the capture</source>
        <translation type="vanished">Guarda la captura</translation>
    </message>
</context>
<context>
    <name>ScreenGrabber</name>
    <message>
        <source>Unable to detect desktop environment (GNOME? KDE? Sway? ...)</source>
        <translation type="vanished">Unable to detect desktop environment (GNOME? KDE? Sway? ...)</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="53"/>
        <source>The universal wayland screen capture adapter requires Grim as the screen capture component of wayland. If the screen capture component is missing, please install it!</source>
        <translation>L&apos;adaptador universal de captura de pantalla de wayland requereix Grim com a component de captura de pantalla del wayland. Si falta el component de captura de pantalla, instal·leu-lo!</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="171"/>
        <source>If the useGrimAdapter setting is not enabled, the dbus protocol will be used. It should be noted that using the dbus protocol under wayland is not recommended. It is recommended to enable the useGrimAdapter setting in flameshot.ini to activate the grim-based general wayland screenshot adapter</source>
        <translation>Si la configuració useGrimAdapter no està activada, s&apos;utilitzarà el protocol dbus. Cal tenir en compte que no es recomana l&apos;ús del protocol de dbus en el wayland. Es recomana habilitar l&apos;opció useGrimAdapter a flameshot.ini per activar l&apos;adaptador general de captura de pantalla Wayland basat en grim</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="182"/>
        <source>grim&apos;s screenshot component is implemented based on wlroots, it may not be used in GNOME or similar desktop environments</source>
        <translation>El component de captura de pantalla de grim s&apos;implementa en base a wlroots, no es pot utilitzar en el GNOME o en entorns d&apos;escriptori similars</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="194"/>
        <source>Unable to detect desktop environment (GNOME? KDE? Qile? Sway? ...)</source>
        <translation>No s&apos;ha pogut detectar l&apos;entorn d&apos;escriptori (GNOME? KDE? Qile? Sway? ...)</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="197"/>
        <source>Hint: try setting the XDG_CURRENT_DESKTOP environment variable.</source>
        <translation>Pista: prova de configurar la variable d&apos;entorn XDG_CURRENT_DESKTOP.</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="202"/>
        <source>Unable to capture screen</source>
        <translation>Imposible capturar la pantalla</translation>
    </message>
</context>
<context>
    <name>SecondaryInstanceWidget</name>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="26"/>
        <source>Secondary instance</source>
        <translation>Instància secundària</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="27"/>
        <source>&lt;b&gt;Secondary instance.&lt;/b&gt; Send message to primary:</source>
        <translation>&lt;b&gt;Instància secundària.&lt;/b&gt; Envia un missatge al primari:</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="29"/>
        <source>Type something here...</source>
        <translation>Escriviu alguna cosa aquí...</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="31"/>
        <source>&amp;Send</source>
        <translation>&amp;Envia</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="54"/>
        <source>Error sending message</source>
        <translation>S&apos;ha produït un error en enviar el missatge</translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="55"/>
        <source>The message &apos;%1&apos; could not be sent to the primary.</source>
        <translation>No s&apos;ha pogut enviar el missatge &apos;%1&apos; al primari.</translation>
    </message>
</context>
<context>
    <name>SelectionTool</name>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="25"/>
        <source>Rectangular Selection</source>
        <translation>Selecció rectangular</translation>
    </message>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="35"/>
        <source>Set Selection as the paint tool</source>
        <translation>Estableix la selecció com a eina de dibuix</translation>
    </message>
</context>
<context>
    <name>SetShortcutDialog</name>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="18"/>
        <source>Set Shortcut</source>
        <translation>Estableix Drecera</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="24"/>
        <source>Enter new shortcut to change </source>
        <translation>Introdueix una nova drecera per canviar </translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="38"/>
        <source>Press Esc to cancel or ⌘+Backspace to disable the keyboard shortcut.</source>
        <translation>Prem Esc per cancel·lar o ⌘+Backspace per desactivar la drecera de teclat.</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="42"/>
        <source>Press Esc to cancel or Backspace to disable the keyboard shortcut.</source>
        <translation>Prem Esc per cancel·lar o Backspace per desactivar la drecera de teclat.</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="48"/>
        <location filename="../../src/config/setshortcutwidget.cpp" line="53"/>
        <source>Flameshot must be restarted for changes to take effect.</source>
        <translation>Flameshot s&apos;ha de reiniciar perquè els canvis tinguin efecte.</translation>
    </message>
</context>
<context>
    <name>ShortcutsWidget</name>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="27"/>
        <source>Hot Keys</source>
        <translation>Tecles d&apos;Accés Ràpid</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="48"/>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation>Dreceres disponibles en el mode de captura de pantalla.</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="59"/>
        <source>Description</source>
        <translation>Descripció</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="59"/>
        <source>Key</source>
        <translation>Tecla</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="162"/>
        <source>Left Double-click</source>
        <translation>Doble Clic Esquerre</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="169"/>
        <source>Toggle side panel</source>
        <translation>Activa/desactiva el panell lateral</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="170"/>
        <source>Grab a color from the screen</source>
        <translation>Agafa un color de la pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="171"/>
        <source>Resize selection left 1px</source>
        <translation>Redimensiona la selecció cap a l&apos;esquerra 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="172"/>
        <source>Resize selection right 1px</source>
        <translation>Redimensiona la selecció cap a la dreta 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="173"/>
        <source>Resize selection up 1px</source>
        <translation>Redimensiona la selecció cap a dalt 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="174"/>
        <source>Resize selection down 1px</source>
        <translation>Redimensiona la selecció cap avall 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="176"/>
        <source>Symmetrically decrease width by 2px</source>
        <translation>Redueix l&apos;amplada simètricament en 2px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="178"/>
        <source>Symmetrically increase width by 2px</source>
        <translation>Augmenta l&apos;amplada simètricament en 2px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="180"/>
        <source>Symmetrically increase height by 2px</source>
        <translation>Augmenta l&apos;alçada simètricament en 2px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="182"/>
        <source>Symmetrically decrease height by 2px</source>
        <translation>Redueix l&apos;alçada simètricament en 2px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="183"/>
        <source>Select entire screen</source>
        <translation>Selecciona tota la pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="184"/>
        <source>Move selection left 1px</source>
        <translation>Mou la selecció cap a l&apos;esquerra 1 px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="185"/>
        <source>Move selection right 1px</source>
        <translation>Mou la selecció cap a la dreta 1 px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="186"/>
        <source>Move selection up 1px</source>
        <translation>Mou la selecció cap a dalt 1 px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="187"/>
        <source>Move selection down 1px</source>
        <translation>Mou la selecció cap avall 1 px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="188"/>
        <source>Commit text in text area</source>
        <translation>Confirma el text a l&apos;àrea de text</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="190"/>
        <source>Delete selected drawn object</source>
        <translation>Suprimeix l&apos;objecte dibuixat seleccionat</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="191"/>
        <source>Cancel current selection</source>
        <translation>Cancel·la la selecció actual</translation>
    </message>
    <message>
        <source>Delete current tool</source>
        <translation type="obsolete">Delete current tool</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="200"/>
        <source>Capture screen</source>
        <translation>Captura la pantalla</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="202"/>
        <source>Screenshot history</source>
        <translation>Historial de captures de pantalla</translation>
    </message>
</context>
<context>
    <name>SidePanelWidget</name>
    <message>
        <source>Active thickness:</source>
        <translation type="vanished">Active thickness:</translation>
    </message>
    <message>
        <source>Active color:</source>
        <translation type="vanished">Active color:</translation>
    </message>
    <message>
        <source>Press ESC to cancel</source>
        <translation type="vanished">Press ESC to cancel</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="37"/>
        <source>Active tool size: </source>
        <translation>Mida de l&apos;eina activa: </translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="57"/>
        <source>Active Color: </source>
        <translation>Color Actiu: </translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="78"/>
        <source>Grab Color</source>
        <translation>Agafa Color</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="85"/>
        <source>Display grid</source>
        <translation>Mostra la quadrícula</translation>
    </message>
</context>
<context>
    <name>SizeDecreaseTool</name>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="37"/>
        <source>Decrease Tool Size</source>
        <translation>Disminueix la Mida de l&apos;Eina</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="47"/>
        <source>Decrease the size of the other tools</source>
        <translation>Disminueix la mida de les altres eines</translation>
    </message>
</context>
<context>
    <name>SizeIncreaseTool</name>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="37"/>
        <source>Increase Tool Size</source>
        <translation>Augmenta la Mida de l&apos;Eina</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="47"/>
        <source>Increase the size of the other tools</source>
        <translation>Augmenta la mida de les altres eines</translation>
    </message>
</context>
<context>
    <name>SizeIndicatorTool</name>
    <message>
        <source>Selection Size Indicator</source>
        <translation type="vanished">Indicador de mida de selecció</translation>
    </message>
    <message>
        <source>Show X and Y dimensions of the selection</source>
        <translation type="vanished">Show X and Y dimensions of the selection</translation>
    </message>
    <message>
        <source>Show the dimensions of the selection (X Y)</source>
        <translation type="vanished">Mostra les mides de la selecció (X Y)</translation>
    </message>
</context>
<context>
    <name>StrftimeChooserWidget</name>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="43"/>
        <source>Century (00-99)</source>
        <translation>Segle (00-99)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="44"/>
        <source>Year (00-99)</source>
        <translation>Any (00-99)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="45"/>
        <source>Year (2000)</source>
        <translation>Any (2000)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="48"/>
        <source>Month Name (jan)</source>
        <translation>Nom del mes (jul)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="49"/>
        <source>Month Name (january)</source>
        <translation>Nom del mes (juliol)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="51"/>
        <source>Month (01-12)</source>
        <translation>Mes (01-12)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="52"/>
        <source>Week Day (1-7)</source>
        <translation>Dia de la setmana (1-7)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="53"/>
        <source>Week (01-53)</source>
        <translation>Setmana (01-53)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="56"/>
        <source>Day Name (mon)</source>
        <translation>Nom del dia (dg)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="57"/>
        <source>Day Name (monday)</source>
        <translation>Nom del dia (diumenge)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="59"/>
        <source>Day (01-31)</source>
        <translation>Dia (01-31)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="60"/>
        <source>Day of Month (1-31)</source>
        <translation>Dia del mes (1-31)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="61"/>
        <source>Day (001-366)</source>
        <translation>Dia (001-366)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="67"/>
        <source>Hour (00-23)</source>
        <translation>Hora (00-23)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="68"/>
        <source>Hour (01-12)</source>
        <translation>Hora (01-12)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="69"/>
        <source>Minute (00-59)</source>
        <translation>Minut (00-59)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="70"/>
        <source>Second (00-59)</source>
        <translation>Segon (00-59)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="73"/>
        <source>Full Date (%m/%d/%y)</source>
        <translation>Data Completa (%m/%d/%y)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="75"/>
        <source>Full Date (%Y-%m-%d)</source>
        <translation>Data Completa (%Y-%m-%d)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="76"/>
        <source>Full Date (%d-%m-%Y)</source>
        <translation>Data Completa (%d-%m-%Y)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="64"/>
        <source>Time (%H-%M-%S)</source>
        <translation>Hora (%H-%M-%S)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="65"/>
        <source>Time (%H-%M)</source>
        <translation>Hora (%H-%M)</translation>
    </message>
</context>
<context>
    <name>SystemNotification</name>
    <message>
        <location filename="../../src/utils/systemnotification.cpp" line="42"/>
        <source>Flameshot Info</source>
        <translation>Informació de Flameshot</translation>
    </message>
</context>
<context>
    <name>TextConfig</name>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="44"/>
        <source>StrikeOut</source>
        <translation>Ratlla</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="53"/>
        <source>Underline</source>
        <translation>Subratlla</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="62"/>
        <source>Bold</source>
        <translation>Negreta</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="71"/>
        <source>Italic</source>
        <translation>Cursiva</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="81"/>
        <source>Left Align</source>
        <translation>Alinea a l&apos;Esquerra</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="90"/>
        <source>Center Align</source>
        <translation>Alinea al Centre</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="99"/>
        <source>Right Align</source>
        <translation>Alinea a la Dreta</translation>
    </message>
</context>
<context>
    <name>TextTool</name>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="73"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="97"/>
        <source>Add text to your capture</source>
        <translation>Afegeix text a la teva captura</translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="100"/>
        <source>&amp;Take Screenshot</source>
        <translation>&amp;Fes Captura</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="118"/>
        <source>&amp;Open Launcher</source>
        <translation>&amp;Obre el Llançador d&apos;aplicacions</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="123"/>
        <source>&amp;Configuration</source>
        <translation>&amp;Configuració</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="128"/>
        <source>&amp;About</source>
        <translation>&amp;Quant a</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="133"/>
        <source>Check for updates</source>
        <translation>Comprova si hi ha actualitzacions disponibles</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="144"/>
        <source>New version %1 is available</source>
        <translation>Nova versió %1 disponible</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="149"/>
        <source>&amp;Quit</source>
        <translation>&amp;Surt</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="154"/>
        <source>&amp;Latest Uploads</source>
        <translation>&amp;Últimes Càrregues</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="160"/>
        <source>&amp;Open Save Path</source>
        <translation>&amp;Obre la Ruta on Desar</translation>
    </message>
</context>
<context>
    <name>UIcolorEditor</name>
    <message>
        <source>UI Color Editor</source>
        <translation type="vanished">Editor de color de la interfície</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="88"/>
        <source>Change the color moving the selectors and see the changes in the preview buttons.</source>
        <translation>Canvieu el color movent els selectors i observeu els canvis en els botons de previsualització.</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="99"/>
        <source>Select a Button to modify it</source>
        <translation>Seleccioneu un botó per a modificar-lo</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="109"/>
        <source>Main Color</source>
        <translation>Color principal</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="113"/>
        <source>Click on this button to set the edition mode of the main color.</source>
        <translation>Feu clic en aquest botó per a aplicar el mode d&apos;edició per al color principal.</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="124"/>
        <source>Contrast Color</source>
        <translation>Color de contrast</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="129"/>
        <source>Click on this button to set the edition mode of the contrast color.</source>
        <translation>Feu clic en aquest botó per a aplicar el mode d&apos;edició per al color de contrast.</translation>
    </message>
</context>
<context>
    <name>UndoTool</name>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="23"/>
        <source>Undo</source>
        <translation>Desfés</translation>
    </message>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="33"/>
        <source>Undo the last modification</source>
        <translation>Desfés l&apos;última modificació</translation>
    </message>
</context>
<context>
    <name>UpdateNotificationWidget</name>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="70"/>
        <source>New Flameshot version %1 is available</source>
        <translation>Nova versió %1 de Flameshot està disponible</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="123"/>
        <source>Ignore</source>
        <translation>Ignora</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="131"/>
        <source>Later</source>
        <translation>Després</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="139"/>
        <source>Update</source>
        <translation>Actualitza</translation>
    </message>
</context>
<context>
    <name>UploadHistory</name>
    <message>
        <location filename="../../src/widgets/uploadhistory.ui" line="14"/>
        <source>Upload History</source>
        <translation>Historial de Càrregues</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadhistory.cpp" line="60"/>
        <source>Screenshots history is empty</source>
        <translation>L&apos;historial de captures de pantalla és buit</translation>
    </message>
</context>
<context>
    <name>UploadLineItem</name>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="20"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="49"/>
        <source>TextLabel</source>
        <translation>EtiquetaText</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="82"/>
        <source>Copy URL</source>
        <translation>Copia l&apos;URL</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="95"/>
        <source>Open In Browser</source>
        <translation>Obre Al Navegador</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="50"/>
        <source>Confirm to delete</source>
        <translation>Confirmeu per esborrar</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="51"/>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation>Esteu segur de voler esborrar una captura de pantalla de les darreres pujades i del servidor?</translation>
    </message>
</context>
<context>
    <name>UtilityPanel</name>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="196"/>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="206"/>
        <source>&lt;Empty&gt;</source>
        <translation>&lt;Buit&gt;</translation>
    </message>
</context>
<context>
    <name>VisualsEditor</name>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="41"/>
        <source>Opacity of area outside selection:</source>
        <translation>Opacitat de la zona fora de la selecció:</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="68"/>
        <source>UI Color Editor</source>
        <translation>Editor de color de la interfície d&apos;usuari</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="74"/>
        <source>Colorpicker Editor</source>
        <translation>Editor de Selector de colors</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="79"/>
        <source>Button Selection</source>
        <translation>Selecció de botó</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="85"/>
        <source>Select All</source>
        <translation>Selecciona-ho tot</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorDialog</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.cpp" line="63"/>
        <source>Pick</source>
        <translation>Selecciona</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPalette</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette.cpp" line="417"/>
        <source>Unnamed</source>
        <translation>Sense nom</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteModel</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_model.cpp" line="55"/>
        <source>Unnamed</source>
        <translation>Sense nom</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_model.cpp" line="130"/>
        <source>%1 (%2 colors)</source>
        <translation>%1 (%2 colors)</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteWidget</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="64"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="231"/>
        <source>Open a new palette from file</source>
        <translation>Obre una nova paleta des de fitxer</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="75"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="234"/>
        <source>Create a new palette</source>
        <translation>Crea una nova paleta</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="86"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="237"/>
        <source>Duplicate the current palette</source>
        <translation>Duplica la paleta actual</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="170"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="240"/>
        <source>Delete the current palette</source>
        <translation>Elimina la paleta actual</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="181"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="243"/>
        <source>Revert changes to the current palette</source>
        <translation>Reverteix els canvis a la paleta actual</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="192"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="246"/>
        <source>Save changes to the current palette</source>
        <translation>Desa els canvis a la paleta actual</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="216"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="249"/>
        <source>Add a color to the palette</source>
        <translation>Afegeix un color a la paleta</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="227"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="252"/>
        <source>Remove the selected color from the palette</source>
        <translation>Elimina el color seleccionat de la paleta</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="181"/>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="196"/>
        <source>New Palette</source>
        <translation>Nova Paleta</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="182"/>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="197"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="223"/>
        <source>GIMP Palettes (*.gpl)</source>
        <translation>Paletes GIMP (*.gpl)</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="224"/>
        <source>Palette Image (%1)</source>
        <translation>Imatge de la Paleta (%1)</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="225"/>
        <source>All Files (*)</source>
        <translation>Tots els Fitxers (*)</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="226"/>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="239"/>
        <source>Open Palette</source>
        <translation>Obre Paleta</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="240"/>
        <source>Failed to load the palette file
%1</source>
        <translation>No s&apos;ha pogut carregar el fitxer de la paleta
%1</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientEditor</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_editor.cpp" line="321"/>
        <source>Add Color</source>
        <translation>Afegeix Color</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_editor.cpp" line="330"/>
        <source>Remove Color</source>
        <translation>Elimina Color</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_editor.cpp" line="338"/>
        <source>Edit Color...</source>
        <translation>Edita Color...</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientListModel</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_list_model.cpp" line="215"/>
        <source>%1 (%2 colors)</source>
        <translation>%1 (%2 colors)</translation>
    </message>
</context>
<context>
    <name>color_widgets::Swatch</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/swatch.cpp" line="855"/>
        <source>Clear Color</source>
        <translation>Neteja Color</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/swatch.cpp" line="864"/>
        <source>%1 (%2)</source>
        <translation>%1 (%2)</translation>
    </message>
</context>
</TS>
