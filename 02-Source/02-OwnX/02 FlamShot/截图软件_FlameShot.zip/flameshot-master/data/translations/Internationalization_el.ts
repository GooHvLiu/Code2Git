<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="el">
<context>
    <name>AbstractWidgetList</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="52"/>
        <source>Add New</source>
        <translation>Προσθήκη Νέου</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="103"/>
        <source>Move Up</source>
        <translation>Μετακίνηση Επάνω</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="104"/>
        <source>Move Down</source>
        <translation>Μετακίνηση Κάτω</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/abstract_widget_list.cpp" line="105"/>
        <source>Remove</source>
        <translation>Κατάργηση</translation>
    </message>
</context>
<context>
    <name>AcceptTool</name>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="31"/>
        <source>Accept</source>
        <translation>Αποδοχή</translation>
    </message>
    <message>
        <location filename="../../src/tools/accept/accepttool.cpp" line="41"/>
        <source>Accept the capture</source>
        <translation>Αποδοχή της λήψης</translation>
    </message>
</context>
<context>
    <name>AppLauncher</name>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="23"/>
        <source>App Launcher</source>
        <translation>Εκκινητής Εφαρμογής</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applaunchertool.cpp" line="33"/>
        <source>Choose an app to open the capture</source>
        <translation>Επιλέξτε μια εφαρμογή για να ανοίξετε την λήψη</translation>
    </message>
</context>
<context>
    <name>AppLauncherWidget</name>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="50"/>
        <source>Open With</source>
        <translation>Άνοιγμα Με</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="79"/>
        <source>Launch in terminal</source>
        <translation>Άνοιγμα στο τερματικό</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="80"/>
        <source>Keep open after selection</source>
        <translation>Να παραμείνει ανοικτό μετά την επιλογή</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="116"/>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="150"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="150"/>
        <source>Unable to launch in terminal.</source>
        <translation>Δεν είναι δυνατή η εκκίνηση στο τερματικό.</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/applauncherwidget.cpp" line="116"/>
        <source>Unable to write in</source>
        <translation>Δεν είναι δυνατή η εγγραφή στο</translation>
    </message>
</context>
<context>
    <name>ArrowTool</name>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="77"/>
        <source>Arrow</source>
        <translation>Βέλος</translation>
    </message>
    <message>
        <location filename="../../src/tools/arrow/arrowtool.cpp" line="87"/>
        <source>Set the Arrow as the paint tool</source>
        <translation>Ορίστε το Βέλος ως εργαλείο ζωγραφικής</translation>
    </message>
</context>
<context>
    <name>BlurTool</name>
    <message>
        <source>Blur</source>
        <translation type="vanished">Desenfocament</translation>
    </message>
    <message>
        <source>Set Blur as the paint tool</source>
        <translation type="vanished">Estableix el desenfocament com a eina de dibuix</translation>
    </message>
</context>
<context>
    <name>CaptureLauncher</name>
    <message>
        <source>&lt;b&gt;Capture Mode&lt;/b&gt;</source>
        <translation type="vanished">&lt;b&gt;Λειτουργία Λήψης&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="33"/>
        <source>Rectangular Region</source>
        <translation>Ορθογώνια Περιοχή</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="39"/>
        <source>Full Screen (Current Display)</source>
        <translation>Πλήρη Οθόνη (Τρέχουσα Οθόνη)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="42"/>
        <source>Full Screen (All Monitors)</source>
        <translation>Πλήρη Οθόνη (Όλες οι Οθόνες)</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="45"/>
        <source>No Delay</source>
        <translation>Χωρίς Καθυστέρηση</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.cpp" line="53"/>
        <source> second</source>
        <translation> δευτερόλεπτο</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="100"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="184"/>
        <location filename="../../src/widgets/capturelauncher.cpp" line="53"/>
        <source> seconds</source>
        <translation> δευτερόλεπτα</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="165"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="185"/>
        <source>Take new screenshot</source>
        <translation>Λήψη νέου στιγμιότυπου οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="66"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="180"/>
        <source>Area:</source>
        <translation>Περιοχή:</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="177"/>
        <source>Capture Launcher</source>
        <translation>Εκκινητής Λήψης</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="34"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="178"/>
        <source>TextLabel</source>
        <translation>Ετικέτα Κειμένου</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="51"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="179"/>
        <source>Capture Mode</source>
        <translation>Λειτουργία Λήψης</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="80"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="182"/>
        <source>Delay:</source>
        <translation>Καθυστέρηση:</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capturelauncher.ui" line="93"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_capturelauncher.h" line="183"/>
        <source>WxH+x+y</source>
        <translation>WxH+x+y</translation>
    </message>
</context>
<context>
    <name>CaptureWidget</name>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="112"/>
        <source>Unable to capture screen</source>
        <translatorcomment>Impossible capturar la pantalla</translatorcomment>
        <translation>Δεν είναι δυνατή η λήψη της οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="456"/>
        <source>Mouse</source>
        <translation>Ποντίκι</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="456"/>
        <source>Select screenshot area</source>
        <translation>Επιλέξτε περιοχή στιγμιότυπου οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="470"/>
        <source>Mouse Wheel</source>
        <translation>Τροχός Ποντικιού</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="470"/>
        <source>Change tool size</source>
        <translation>Αλλαγή μεγέθους εργαλείου</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="471"/>
        <source>Right Click</source>
        <translation>Δεξί Κλίκ</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="471"/>
        <source>Show color picker</source>
        <translation>Εμφάνιση επιλογέα χρώματος</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="473"/>
        <source>Open side panel</source>
        <translation>Ανοίξτε το πλαϊνό πλαίσιο</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="474"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="474"/>
        <source>Exit</source>
        <translation>Έξοδος</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="515"/>
        <source>Quit Capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="516"/>
        <source>Are you sure you want to quit capture?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="521"/>
        <source>Do not show this again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="727"/>
        <source>Flameshot has lost focus. Keyboard shortcuts won&apos;t work until you click somewhere.</source>
        <translation>Το Flameshot έχει χάσει την εστίαση. Οι συντομεύσεις πληκτρολογίου δεν θα λειτουργήσουν μέχρι να κάνετε κλικ κάπου.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="733"/>
        <source>Configuration error resolved. Launch `flameshot gui` again to apply it.</source>
        <translation>Επιλύθηκε το σφάλμα διαμόρφωσης. Εκκινήστε ξανά το «flameshot gui» για να το εφαρμόσετε.</translation>
    </message>
    <message>
        <source>Select an area with the mouse, or press Esc to exit.
Press Enter to capture the screen.
Press Right Click to show the color picker.
Use the Mouse Wheel to change the thickness of your tool.
Press Space to open the side panel.</source>
        <translation type="vanished">Επιλέξτε μια περιοχή με το ποντίκι, ή πατήστε Esc για έξοδο.
Πατήστε Enter για να κάνετε λήψη της οθόνης.
Πατήστε δεξί κλικ για να εμφανιστεί ο επιλογέας χρωμάτων.
Χρησιμοποιήστε την ροδέλα του ποντικιού για να αλλάξετε το πάχος του επιλεγμένου εργαλείου.
Πατήστε καινό για να ανοίξετε τον πλευρικό πίνακα.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/capture/capturewidget.cpp" line="1167"/>
        <source>Tool Settings</source>
        <translation>Ρυθμίσεις Εργαλείου</translation>
    </message>
</context>
<context>
    <name>CircleCountTool</name>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="68"/>
        <source>Circle Counter</source>
        <translation>Κυκλικός Μετρητής</translation>
    </message>
    <message>
        <location filename="../../src/tools/circlecount/circlecounttool.cpp" line="86"/>
        <source>Add an autoincrementing counter bubble</source>
        <translation>Προσθέτει ένα αυτόματα αυξανόμενο μετρητή φυσαλίδων</translation>
    </message>
</context>
<context>
    <name>CircleTool</name>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="20"/>
        <source>Circle</source>
        <translation>Κύκλος</translation>
    </message>
    <message>
        <location filename="../../src/tools/circle/circletool.cpp" line="30"/>
        <source>Set the Circle as the paint tool</source>
        <translation>Ορίστε τον Κύκλο ως εργαλείο ζωφραφικής</translation>
    </message>
</context>
<context>
    <name>ColorDialog</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="19"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="312"/>
        <source>Select Color</source>
        <translation>Επιλέξτε Χρώμα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="60"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="313"/>
        <source>Saturation</source>
        <translation>Κορεσμός</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="67"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="314"/>
        <source>Hue</source>
        <translation>Απόχρωση</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="84"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="315"/>
        <source>Hex</source>
        <translation>Hex</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="91"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="316"/>
        <source>Blue</source>
        <translation>Μπλε</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="128"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="317"/>
        <source>Value</source>
        <translation>Τιμή</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="135"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="318"/>
        <source>Green</source>
        <translation>Πράσινο</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="142"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="319"/>
        <source>Alpha</source>
        <translation>Alpha</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.ui" line="149"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_dialog.h" line="320"/>
        <source>Red</source>
        <translation>Κόκκινο</translation>
    </message>
</context>
<context>
    <name>ColorGrabWidget</name>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="58"/>
        <source>Accept color</source>
        <translation>Αποδοχή χρώματος</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="58"/>
        <source>Enter or Left Click</source>
        <translation>Enter ή Αριστερό Κλικ</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="59"/>
        <source>Precisely select color</source>
        <translation>Επιλέξτε με ακρίβεια χρώμα</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="59"/>
        <source>Hold Left Click</source>
        <translation>Κρατήστε Πατημένο το Αριστερό Κλικ</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="60"/>
        <source>Toggle magnifier</source>
        <translation>Εναλλαγή μεγεθυντικού φακού</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="60"/>
        <source>Space or Right Click</source>
        <translation>Space ή Δεξί Κλικ</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="61"/>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/colorgrabwidget.cpp" line="61"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
</context>
<context>
    <name>ColorPickerEditor</name>
    <message>
        <source>Select Preset:</source>
        <translation type="vanished">Επιλέξτε Προεπιλογή:</translation>
    </message>
    <message>
        <source>Select preset using the spinbox</source>
        <translation type="vanished">Επιλέξτε προεπιλογή χρησιμοποιώντας το spinbox</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="40"/>
        <source>Edit Preset:</source>
        <translation>Επεξεργασία Προεπιλογής:</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="45"/>
        <source>Enter color to update preset</source>
        <translation>Εισαγάγετε χρώμα για ενημέρωση προεπιλογής</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="65"/>
        <source>Update</source>
        <translation>Ενημέρωση</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="67"/>
        <source>Press button to update the selected preset</source>
        <translation>Πατήστε το κουμπί για να ενημερώσετε την επιλεγμένη προεπιλογή</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="74"/>
        <source>Delete</source>
        <translation>Διαγραφή</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="76"/>
        <source>Press button to delete the selected preset</source>
        <translation>Πατήστε το κουμπί για να διαγράψετε την επιλεγμένη προεπιλογή</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="90"/>
        <source>Add Preset:</source>
        <translation>Προσθήκη Προεπιλογής:</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="96"/>
        <source>Enter color manually or select it using the color-wheel</source>
        <translation>Εισαγάγετε το χρώμα χειροκίνητα ή επιλέξτε το χρησιμοποιώντας τον τροχό χρώματος</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="106"/>
        <source>Add</source>
        <translation>Προσθήκη</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="107"/>
        <source>Press button to add preset</source>
        <translation>Πατήστε το κουμπί για να προσθέσετε προεπιλογή</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="130"/>
        <location filename="../../src/config/colorpickereditor.cpp" line="147"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="131"/>
        <source>Unable to add preset. Maximum limit reached.</source>
        <translation>Δεν είναι δυνατή η προσθήκη προκαθορισμένης ρύθμισης. Συμπληρώθηκε το μέγιστο όριο.</translation>
    </message>
    <message>
        <location filename="../../src/config/colorpickereditor.cpp" line="148"/>
        <source>Unable to remove preset. Minimum limit reached.</source>
        <translation>Δεν είναι δυνατή η κατάργηση της προεπιλογής. Συμπληρώθηκε το ελάχιστο όριο.</translation>
    </message>
</context>
<context>
    <name>ConfigErrorDetails</name>
    <message>
        <location filename="../../src/config/configerrordetails.cpp" line="20"/>
        <source>Configuration errors</source>
        <translation>Σφάλματα διαμόρφωσης</translation>
    </message>
</context>
<context>
    <name>ConfigHandler</name>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="579"/>
        <source>Unrecognized setting: &apos;%1&apos;
</source>
        <translation>Μη αναγνωρισμένη ρύθμιση: &apos;% 1&apos;
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="587"/>
        <source>Unrecognized shortcut name: &apos;%1&apos;.
</source>
        <translation>Μη αναγνωρισμένο όνομα συντόμευσης: &apos;%1&apos;.
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="630"/>
        <source>Shortcut conflict: &apos;%1&apos; and &apos;%2&apos; have the same shortcut: %3
</source>
        <translation>Διένεξη συντομεύσεων: &quot;% 1&quot; και &quot;% 2&quot; έχουν την ίδια συντόμευση: %3
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="668"/>
        <source>Bad value in &apos;%1&apos;. Expected: %2
</source>
        <translation>Λάθος τιμή στο &apos;% 1&apos;. Αναμενόμενο: %2
</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="717"/>
        <source>You have successfully resolved the configuration error.</source>
        <translation>Επιλύσατε με επιτυχία το σφάλμα διαμόρφωσης.</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="740"/>
        <source>The configuration contains an error. Open configuration to resolve.</source>
        <translation>Η διαμόρφωση περιέχει ένα σφάλμα. Ανοίξτε τη διαμόρφωση για επίλυση.</translation>
    </message>
    <message>
        <location filename="../../src/utils/confighandler.cpp" line="794"/>
        <source>Bad config key &apos;%1&apos; in ConfigHandler. Please report this as a bug.</source>
        <translation>Εσφαλμένο κλειδί διαμόρφωσης &apos;%1&apos; στο ConfigHandler. Αναφέρετε αυτό ως σφάλμα.</translation>
    </message>
</context>
<context>
    <name>ConfigResolver</name>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="14"/>
        <source>Resolve configuration errors</source>
        <translation>Επίλυση σφαλμάτων διαμόρφωσης</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="50"/>
        <source>&lt;b&gt;You must resolve all errors before continuing:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Πρέπει να επιλύσετε όλα τα σφάλματα πριν συνεχίσετε:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="61"/>
        <source>Reset</source>
        <translation>Επαναφορά</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="63"/>
        <source>Reset to the default value.</source>
        <translation>Επαναφορά στην προεπιλεγμένη τιμή.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="77"/>
        <source>Remove</source>
        <translation>Κατάργηση</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="79"/>
        <source>Remove this setting.</source>
        <translation>Καταργήστε αυτήν τη ρύθμιση.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="90"/>
        <source>Some keyboard shortcuts have conflicts.
This will NOT prevent flameshot from starting.
Please solve them manually in the configuration file.</source>
        <translation>Ορισμένες συντομεύσεις πληκτρολογίου έχουν διενέξεις.
Αυτό ΔΕΝ θα εμποδίσει την εκκίνηση του flameshot.
Επιλύστε τα με μη αυτόματο τρόπο στο αρχείο ρυθμίσεων.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="112"/>
        <source>Resolve all</source>
        <translation>Επίλυση όλων</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="113"/>
        <source>Resolve all listed errors.</source>
        <translation>Επιλύστε όλα τα σφάλματα που αναφέρονται.</translation>
    </message>
    <message>
        <location filename="../../src/config/configresolver.cpp" line="125"/>
        <source>Details</source>
        <translation>Λεπτομέριες</translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="40"/>
        <source>Configuration</source>
        <translation>Διαμόρφωση</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="68"/>
        <source>Interface</source>
        <translation>Διεπαφή</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="78"/>
        <source>Filename Editor</source>
        <translation>Επεξεργαστής Ονόματος αρχείου</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="59"/>
        <source>General</source>
        <translation>Γενικά</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="87"/>
        <source>Shortcuts</source>
        <translation>Συντομεύσεις</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="120"/>
        <source>Resolve</source>
        <translation>Επίλυση</translation>
    </message>
    <message>
        <location filename="../../src/config/configwindow.cpp" line="124"/>
        <source>&lt;b&gt;Configuration file has errors. Resolve them before continuing.&lt;/b&gt;</source>
        <translation>&lt;b&gt;Το αρχείο διαμόρφωσης έχει σφάλματα. Επιλύστε τα πριν συνεχίσετε.&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>Controller</name>
    <message>
        <source>New version %1 is available</source>
        <translation type="vanished">Η νέα έκδοση % 1 είναι διαθέσιμη</translation>
    </message>
    <message>
        <source>You have the latest version</source>
        <translation type="vanished">Έχετε την πιο πρόσφατη έκδοση</translation>
    </message>
    <message>
        <source>Failed to get information about the latest version.</source>
        <translation type="vanished">Αποτυχία λήψης πληροφοριών για την πιο πρόσφατη έκδοση.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">Σφάλμα</translation>
    </message>
    <message>
        <source>Unable to close active modal widgets</source>
        <translation type="vanished">Δεν είναι δυνατό το κλείσιμο των ενεργών γραφικών στοιχείων</translation>
    </message>
    <message>
        <source>&amp;Open Launcher</source>
        <translation type="vanished">&amp;Άνοιγμα Εκκινητή</translation>
    </message>
    <message>
        <source>&amp;Configuration</source>
        <translation type="vanished">&amp;Διαμόρφωση</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation type="vanished">&amp;Σχετικά με</translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation type="vanished">Έλεγχος για ενημερώσεις</translation>
    </message>
    <message>
        <source>&amp;Latest Uploads</source>
        <translation type="vanished">&amp;Τελευταίες Μεταφορτώσεις</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">Η διεύθυνση URL αντιγράφηκε στο πρόχειρο.</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation type="vanished">&amp;Informació</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="vanished">%Κλείσιμο</translation>
    </message>
    <message>
        <source>&amp;Take Screenshot</source>
        <translation type="vanished">&amp;Λήψη Στιγμιότυπου οθόνης</translation>
    </message>
</context>
<context>
    <name>CopyTool</name>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="24"/>
        <source>Copy</source>
        <translation>Αντιγραφή</translation>
    </message>
    <message>
        <location filename="../../src/tools/copy/copytool.cpp" line="34"/>
        <source>Copy selection to clipboard</source>
        <translation>Αντιγραφή επιλογής στο πρόχειρο</translation>
    </message>
    <message>
        <source>Copy the selection into the clipboard</source>
        <translation type="vanished">Copy the selection into the clipboard</translation>
    </message>
</context>
<context>
    <name>DBusUtils</name>
    <message>
        <source>Unable to connect via DBus</source>
        <translation type="vanished">Unable to connect via DBus</translation>
    </message>
</context>
<context>
    <name>ExitTool</name>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="23"/>
        <source>Exit</source>
        <translation>Έξοδος</translation>
    </message>
    <message>
        <location filename="../../src/tools/exit/exittool.cpp" line="33"/>
        <source>Leave the capture screen</source>
        <translation>Αφήστε την οθόνη λήψης</translation>
    </message>
</context>
<context>
    <name>FileNameEditor</name>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="24"/>
        <source>Edit the name of your captures:</source>
        <translation>Επεξεργαστείτε το όνομα των λήψεών σας:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="28"/>
        <source>Edit:</source>
        <translation>Επεξεργασία:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="30"/>
        <source>Preview:</source>
        <translation>Προεπισκόπηση:</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="73"/>
        <source>Save</source>
        <translation>Αποθήκευση</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="76"/>
        <source>Saves the pattern</source>
        <translation>Αποθηκεύει το μοτίβο</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="78"/>
        <source>Restore</source>
        <translation>Επαναφορά</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="81"/>
        <source>Restores the saved pattern</source>
        <translation>Επαναφέρει το αποθηκευμένο μοτίβο</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="83"/>
        <source>Clear</source>
        <translation>Καθαρισμός</translation>
    </message>
    <message>
        <location filename="../../src/config/filenameeditor.cpp" line="89"/>
        <source>Deletes the name</source>
        <translation>Διαγράφει το όνομα</translation>
    </message>
</context>
<context>
    <name>Flameshot</name>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="119"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="119"/>
        <source>Unable to close active modal widgets</source>
        <translation>Δεν είναι δυνατό το κλείσιμο των ενεργών γραφικών στοιχείων</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="431"/>
        <source>URL copied to clipboard.</source>
        <translation>Η διεύθυνση URL αντιγράφηκε στο πρόχειρο.</translation>
    </message>
</context>
<context>
    <name>FlameshotDaemon</name>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="407"/>
        <source>New version %1 is available</source>
        <translation>Η νέα έκδοση % 1 είναι διαθέσιμη</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="413"/>
        <source>You have the latest version</source>
        <translation>Έχετε την πιο πρόσφατη έκδοση</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="422"/>
        <source>Failed to get information about the latest version.</source>
        <translation>Αποτυχία λήψης πληροφοριών για την πιο πρόσφατη έκδοση.</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshotdaemon.cpp" line="445"/>
        <source>Unable to connect via DBus</source>
        <translation>Δεν είναι δυνατή η σύνδεση μέσω DBus</translation>
    </message>
</context>
<context>
    <name>GeneneralConf</name>
    <message>
        <source>Show help message</source>
        <translation type="vanished">Mostra el missatge d&apos;ajuda</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="vanished">Mostra el missatge d&apos;ajuda en iniciar el mode de captura.</translation>
    </message>
    <message>
        <source>Show desktop notifications</source>
        <translation type="vanished">Mostra les notificacions d&apos;escriptori</translation>
    </message>
    <message>
        <source>Show tray icon</source>
        <translation type="vanished">Mostra la icona en la barra de tasques</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="vanished">Mostra la icona en la barra de tasques</translation>
    </message>
    <message>
        <source>Import</source>
        <translation type="vanished">Importar</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">Error</translation>
    </message>
    <message>
        <source>Unable to read file.</source>
        <translation type="vanished">Impossible llegir el fitxer.</translation>
    </message>
    <message>
        <source>Unable to write file.</source>
        <translation type="vanished">Impossible escriure al fitxer.</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation type="vanished">Guardar Arxiu</translation>
    </message>
    <message>
        <source>Confirm Reset</source>
        <translation type="vanished">Confirmar Reset</translation>
    </message>
    <message>
        <source>Are you sure you want to reset the configuration?</source>
        <translation type="vanished">Esteu segur que voleu reiniciar la configuració?</translation>
    </message>
    <message>
        <source>Configuration File</source>
        <translation type="vanished">Fitxer de Configuració</translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="vanished">Exportar</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="vanished">Reset</translation>
    </message>
    <message>
        <source>Launch at startup</source>
        <translation type="vanished">Llançament a l&apos;inici</translation>
    </message>
</context>
<context>
    <name>GeneralConf</name>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="192"/>
        <location filename="../../src/config/generalconf.cpp" line="394"/>
        <source>Import</source>
        <translation>Εισαγωγή</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="198"/>
        <location filename="../../src/config/generalconf.cpp" line="207"/>
        <location filename="../../src/config/generalconf.cpp" line="232"/>
        <location filename="../../src/config/generalconf.cpp" line="763"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="198"/>
        <source>Unable to read file.</source>
        <translation>Δεν είναι δυνατή η ανάγνωση του αρχείου.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="207"/>
        <location filename="../../src/config/generalconf.cpp" line="232"/>
        <source>Unable to write file.</source>
        <translation>Δεν είναι δυνατή η εγγραφή του αρχείου.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="219"/>
        <source>Save File</source>
        <translation>Αποθήκευση Αρχείου</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="241"/>
        <source>Confirm Reset</source>
        <translation>Επιβεβαίωση Επαναφοράς</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="242"/>
        <source>Are you sure you want to reset the configuration?</source>
        <translation>Είστε βέβαιοι ότι θέλετε να επαναφέρετε τη διαμόρφωση;</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="273"/>
        <source>Show help message</source>
        <translation>Εμφάνιση μηνύματος βοήθειας</translation>
    </message>
    <message>
        <source>Show the help message at the beginning in the capture mode.</source>
        <translation type="vanished">Εμφάνιση του μηνύματος βοήθειας στην αρχή της λειτουργίας λήψης.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="298"/>
        <source>Show the side panel button</source>
        <translation>Εμφάνιση του κουμπιού του πλαϊνού πίνακα</translation>
    </message>
    <message>
        <source>Show the side panel toggle button in the capture mode.</source>
        <translation type="vanished">Εμφάνιση του κουμπιού εναλλαγής του πλαϊνού πίνακα στη λειτουργία λήψης.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="311"/>
        <source>Show desktop notifications</source>
        <translation>Εμφάνιση ειδοποιήσεων στην επιφάνειας εργασίας</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="336"/>
        <source>Show tray icon</source>
        <translation>Εμφάνιση εικονιδίου tray</translation>
    </message>
    <message>
        <source>Show the systemtray icon</source>
        <translation type="vanished">Εμφάνιση του εικονιδίου συστήματοςtray</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="367"/>
        <source>Confirmation required to delete screenshot from the latest uploads</source>
        <translation>Απαιτείται επιβεβαίωση για τη διαγραφή στιγμιότυπου οθόνης από τις πιο πρόσφατες μεταφορτώσεις</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="382"/>
        <source>Configuration File</source>
        <translation>Αρχείο Διαμόρφωσης</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="387"/>
        <source>Export</source>
        <translation>Εξαγωγή</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="401"/>
        <source>Reset</source>
        <translation>Επαναφορά</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="412"/>
        <source>Automatic check for updates</source>
        <translation>Αυτόματος έλεγχος για ενημερώσεις</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="426"/>
        <source>Allow multiple flameshot GUI instances simultaneously</source>
        <translation>Επιτρέψτε πολλαπλές παρουσίες GUI flameshot ταυτόχρονα</translation>
    </message>
    <message>
        <source>This allows you to take screenshots of flameshot itself for example.</source>
        <translation type="vanished">Αυτό σας επιτρέπει να τραβάτε στιγμιότυπα οθόνης του ίδιου του flameshot, για παράδειγμα.</translation>
    </message>
    <message>
        <source>Automatically close daemon when it is not needed</source>
        <translation type="vanished">Κλείστε αυτόματα το daemon όταν δεν χρειάζεται</translation>
    </message>
    <message>
        <source>Launch at startup</source>
        <translation type="vanished">Έναρξη κατά την εκκίνηση</translation>
    </message>
    <message>
        <source>Launch Flameshot</source>
        <translation type="vanished">Εκκίνηση Flameshot</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="463"/>
        <source>Show welcome message on launch</source>
        <translation>Εμφάνιση μηνύματος καλωσορίσματος κατά την εκκίνηση</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="491"/>
        <source>Use large predefined color palette</source>
        <translation>Χρησιμοποιήστε μεγάλη προκαθορισμένη παλέτα χρωμάτων</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="515"/>
        <source>Copy URL after upload</source>
        <translation>Αντιγράψτε τη διεύθυνση URL μετά τη μεταφόρτωση</translation>
    </message>
    <message>
        <source>Copy URL and close window after upload</source>
        <translation type="vanished">Αντιγράψτε τη διεύθυνση URL και κλείστε το παράθυρο μετά τη μεταφόρτωση</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="527"/>
        <source>Save image after copy</source>
        <translation>Αποθήκευση εικόνας μετά την αντιγραφή</translation>
    </message>
    <message>
        <source>Save image file after copying it</source>
        <translation type="vanished">Αποθηκεύστε το αρχείο εικόνας αφού το αντιγράψετε</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="274"/>
        <source>Show the help message at the beginning in the capture mode</source>
        <translation>Εμφανίστε το μήνυμα βοήθειας στην αρχή στη λειτουργία λήψης</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="284"/>
        <source>Use last region for GUI mode</source>
        <translation type="unfinished">Χρησιμοποιήστε την τελευταία περιοχή</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="286"/>
        <source>Use the last region as the default selection for the next screenshot in GUI mode</source>
        <translation type="unfinished">Χρησιμοποιεί την τελευταία περιοχή ως προεπιλεγμένη επιλογή για το επόμενο στιγμιότυπο οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="300"/>
        <source>Show the side panel toggle button in the capture mode</source>
        <translation>Εμφάνιση του κουμπιού εναλλαγής του πλαϊνού πίνακα στη λειτουργία λήψης</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="312"/>
        <source>Enable desktop notifications</source>
        <translation>Ενεργοποίηση ειδοποιήσεων επιφάνειας εργασίας</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="323"/>
        <source>Show abort notifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="324"/>
        <source>Enable abort notifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="337"/>
        <source>Show icon in the system tray</source>
        <translation>Εμφάνιση εικονιδίου στο tray συστήματος</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="350"/>
        <source>Use grim to capture screenshots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="352"/>
        <source>Grim is a wayland only utility to capture screens based on the screencopy protocol. Generally only enable on minimal wayland window managers like sway, hyprland, etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="370"/>
        <source>Ask for confirmation to delete screenshot from the latest uploads</source>
        <translation>Ζητήστε επιβεβαίωση για τη διαγραφή στιγμιότυπου οθόνης από τις πιο πρόσφατες μεταφορτώσεις</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="413"/>
        <source>Check for updates automatically</source>
        <translation>Έλεγχος ενημερώσεων αυτόματα</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="427"/>
        <source>This allows you to take screenshots of Flameshot itself for example</source>
        <translation>Αυτό σας επιτρέπει να τραβάτε στιγμιότυπα οθόνης του ίδιου του Flameshot, για παράδειγμα</translation>
    </message>
    <message>
        <source>Launch Flameshot daemon when computer is booted</source>
        <translation type="vanished">Εκκίνηση του Flameshot daemon κατά την έναρξη του υπολογιστή</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="466"/>
        <source>Show the welcome message box in the middle of the screen while taking a screenshot</source>
        <translation>Εμφάνιση του πλαισίου μηνύματος καλωσορίσματος στη μέση της οθόνης κατά τη λήψη ενός στιγμιότυπου οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="493"/>
        <source>Use a large predefined color palette</source>
        <translation>Χρήση μιας μεγάλης προκαθορισμένης παλέτα χρωμάτων</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="503"/>
        <source>Copy on double click</source>
        <translation>Αντιγραφή με διπλό κλικ</translation>
    </message>
    <message>
        <source>Enable Copy on Double Click</source>
        <translation type="vanished">Ενεργοποιήστε την Αντιγραφή με Διπλό Κλικ</translation>
    </message>
    <message>
        <source>Copy URL and close window after uploading was successful</source>
        <translation type="vanished">Αντιγραφή της διεύθυνσης URL και κλείσιμο του παραθύρου μετά την επιτυχή μεταφόρτωση</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="439"/>
        <source>Automatically unload from memory when it is not needed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="440"/>
        <source>Automatically close daemon (background process) when it is not needed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="451"/>
        <source>Launch in background at startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="452"/>
        <source>Launch Flameshot daemon (background process) when computer is booted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="477"/>
        <source>Ask before quit capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="480"/>
        <source>Show the confirmation prompt before ESC quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="505"/>
        <source>Enable Copy to clipboard on Double Click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="517"/>
        <source>Copy URL after uploading was successful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="529"/>
        <source>After copying the screenshot, save it to a file as well</source>
        <translation>Αφού αντιγράψετε το στιγμιότυπο οθόνης, αποθηκεύστε το και σε αρχείο</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="536"/>
        <source>Save Path</source>
        <translation>Αποθήκευση Διαδρομής</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="552"/>
        <source>Change...</source>
        <translation>Αλλαγή...</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="560"/>
        <source>Use fixed path for screenshots to save</source>
        <translation>Χρησιμοποιήστε σταθερή διαδρομή για στιγμιότυπα οθόνης για αποθήκευση</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="572"/>
        <source>Preferred save file extension:</source>
        <translation>Προτιμώμενη επέκταση αρχείου αποθήκευσης:</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="601"/>
        <source>Latest Uploads Max Size</source>
        <translation>Τελευταίες Μεταφορτώσεις Μέγιστο Μέγεθος</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="623"/>
        <source>Imgur Application Client ID</source>
        <translation>Κλειδί API Imgur</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="654"/>
        <source>Undo limit</source>
        <translation>Αναίρεση Ορίου</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="683"/>
        <source>Use JPG format for clipboard (PNG default)</source>
        <translation>Χρήση μορφής JPG για το πρόχειρο (προεπιλογή PNG)</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="685"/>
        <source>Use lossy JPG format for clipboard (lossless PNG default)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="711"/>
        <source>Copy file path after save</source>
        <translation>Αντιγραφή διαδρομής αρχείου μετά την αποθήκευση</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="712"/>
        <source>Copy the file path to clipboard after the file is saved</source>
        <translation>Αντιγραφή της διαδρομής του αρχείου στο πρόχειρο μετά την αποθήκευση του αρχείου</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="723"/>
        <source>Anti-aliasing image when zoom the pinned image</source>
        <translation>Anti-aliasing της εικόνας κατά τη μεγέθυνση της καρφιτσωμένης εικόνας</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="725"/>
        <source>After zooming the pinned image, should the image get smoothened or stay pixelated</source>
        <translation>Μετά τη μεγέθυνση της καρφιτσωμένης εικόνας, θέλετε η εικόνα να εξομαλυνθεί ή να παραμείνει pixelated</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="736"/>
        <location filename="../../src/config/generalconf.cpp" line="738"/>
        <source>Upload image without confirmation</source>
        <translation>Μεταφόρτωση εικόνας χωρίς επιβεβαίωση</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="754"/>
        <source>Choose a Folder</source>
        <translation>Επιλέξτε ένα Φάκελο</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="763"/>
        <source>Unable to write to directory.</source>
        <translation>Δεν είναι δυνατή η εγγραφή στον κατάλογο.</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="772"/>
        <source>Show magnifier</source>
        <translation>Εμφάνιση μεγεθυντικού φακού</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="773"/>
        <source>Enable a magnifier while selecting the screenshot area</source>
        <translation>Ενεργοποιήστε έναν μεγεθυντικό φακό ενώ επιλέγετε την περιοχή στιγμιότυπου οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="784"/>
        <source>Square shaped magnifier</source>
        <translation>Μεγεθυντικός φακός τετράγωνου σχήματος</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="785"/>
        <source>Make the magnifier to be square-shaped</source>
        <translation>Κάντε τον μεγεθυντικό φακό να έχει τετράγωνο σχήμα</translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="801"/>
        <source>Milliseconds before geometry display hides; 0 means do not hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="804"/>
        <source>Set geometry display timeout (ms)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="812"/>
        <source>Selection Geometry Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="819"/>
        <source>Display Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="822"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="823"/>
        <source>Top Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="825"/>
        <source>Top Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="827"/>
        <source>Bottom Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="829"/>
        <source>Bottom Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="831"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="856"/>
        <source>Quality range of 0-100; Higher number is better quality and larger file size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="860"/>
        <source>JPEG Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="871"/>
        <source>Reverse arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="872"/>
        <source>Draw the arrow head first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="881"/>
        <source>Insecure Pixelate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/generalconf.cpp" line="883"/>
        <source>Draw the pixelation effect in an insecure but more asethetic way.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoryWidget</name>
    <message>
        <source>Latest Uploads</source>
        <translation type="vanished">Τελευταίες Μεταφορτώσεις</translation>
    </message>
    <message>
        <source>Screenshots history is empty</source>
        <translation type="vanished">Το ιστορικό στιγμιότυπων οθόνης είναι κενό</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="vanished">Αντιγραφή διεύθυνσης URL</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">Η διεύθυνση URL αντιγράφηκε στο πρόχειρο.</translation>
    </message>
    <message>
        <source>Open in browser</source>
        <translation type="vanished">Ανοιγμα σε πρόγραμμα περιήγησης</translation>
    </message>
    <message>
        <source>Confirm to delete</source>
        <translation type="vanished">Επιβεβαίωση για διαγραφή</translation>
    </message>
    <message>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation type="vanished">Είστε βέβαιοι ότι θέλετε να διαγράψετε ένα στιγμιότυπο οθόνης από τις πιο πρόσφατες μεταφορτώσεις και διακομιστή;</translation>
    </message>
</context>
<context>
    <name>ImgS3Uploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">S&apos;està pujant la imatge</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="obsolete">Error</translation>
    </message>
</context>
<context>
    <name>ImgUploadDialog</name>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="18"/>
        <source>Upload Confirmation</source>
        <translation>Επιβεβαίωση Μεταφόρτωσης</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="22"/>
        <source>Do you want to upload this capture?</source>
        <translation>Θέλετε να ανεβάσετε αυτήν τη λήψη;</translation>
    </message>
    <message>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="35"/>
        <location filename="../../src/widgets/imguploaddialog.cpp" line="36"/>
        <source>Upload without confirmation</source>
        <translation>Μεταφόρτωση χωρίς επιβεβαίωση</translation>
    </message>
</context>
<context>
    <name>ImgUploader</name>
    <message>
        <source>Uploading Image</source>
        <translation type="obsolete">S&apos;està pujant la imatge</translation>
    </message>
    <message>
        <source>Unable to open the URL.</source>
        <translation type="obsolete">No es pot obrir l&apos;URL.</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="obsolete">L&apos;URL s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="obsolete">La captura s&apos;ha copiat al porta-retalls.</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="obsolete">Copia l&apos;URL</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="obsolete">Obri l&apos;URL</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="obsolete">Imatge al porta-retalls.</translation>
    </message>
</context>
<context>
    <name>ImgUploaderBase</name>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="37"/>
        <source>Upload image</source>
        <translation>Μεταφόρτωση εικόνας</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="49"/>
        <source>Uploading Image</source>
        <translation>Μεταφόρτωση Εικόνας</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="128"/>
        <source>Copy URL</source>
        <translation>Αντιγραφή διεύθυνσης URL</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="129"/>
        <source>Open URL</source>
        <translation>Άνοιγμα διεύθυνσης URL</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="130"/>
        <source>Delete image</source>
        <translation>Διαγραφή εικόνας</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="131"/>
        <source>Image to Clipboard.</source>
        <translation>Εικόνα στο Πρόχειρο.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="132"/>
        <source>Save image</source>
        <translation>Αποθήκευση εικόνας</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="162"/>
        <source>Unable to open the URL.</source>
        <translation>Δεν είναι δυνατό το άνοιγμα της διεύθυνσης URL.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="169"/>
        <source>URL copied to clipboard.</source>
        <translation>Η διεύθυνση URL αντιγράφηκε στο πρόχειρο.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="175"/>
        <source>Screenshot copied to clipboard.</source>
        <translation>Το στιγμιότυπο οθόνης αντιγράφηκε στο πρόχειρο.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="189"/>
        <source>Unable to save the screenshot to disk.</source>
        <translation>Δεν είναι δυνατή η αποθήκευση του στιγμιότυπου οθόνης στο δίσκο.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imguploaderbase.cpp" line="192"/>
        <source>Screenshot saved.</source>
        <translation>Το στιγμιότυπο οθόνης αποθηκεύτηκε.</translation>
    </message>
</context>
<context>
    <name>ImgUploaderTool</name>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="23"/>
        <source>Image Uploader</source>
        <translation>Πρόγραμμα Μεταφόρτωσης Εικόνων</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/imguploadertool.cpp" line="33"/>
        <source>Upload the selection</source>
        <translation>Ανεβάστε την επιλογή</translation>
    </message>
</context>
<context>
    <name>ImgurUploader</name>
    <message>
        <source>Upload to Imgur</source>
        <translation type="vanished">Upload to Imgur</translation>
    </message>
    <message>
        <source>Uploading Image</source>
        <translation type="vanished">Μεταφόρτωση εικόνας</translation>
    </message>
    <message>
        <source>Copy URL</source>
        <translation type="vanished">Αντιγραφή διεύθυνσης URL</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation type="vanished">Άνοιγμα URL</translation>
    </message>
    <message>
        <source>Delete image</source>
        <translation type="vanished">Delete image</translation>
    </message>
    <message>
        <source>Image to Clipboard.</source>
        <translation type="vanished">Εικόνα στο Πρόχειρο.</translation>
    </message>
    <message>
        <location filename="../../src/tools/imgupload/storages/imgur/imguruploader.cpp" line="107"/>
        <source>Unable to open the URL.</source>
        <translation>Δεν είναι δυνατό το άνοιγμα της διεύθυνσης URL.</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">Η διεύθυνση URL αντιγράφηκε στο πρόχειρο.</translation>
    </message>
    <message>
        <source>Screenshot copied to clipboard.</source>
        <translation type="vanished">Το στιγμιότυπο οθόνης αντιγράφηκε στο πρόχειρο.</translation>
    </message>
</context>
<context>
    <name>ImgurUploaderTool</name>
    <message>
        <source>Image Uploader</source>
        <translation type="vanished">Image Uploader</translation>
    </message>
    <message>
        <source>Upload the selection to Imgur</source>
        <translation type="vanished">Upload the selection to Imgur</translation>
    </message>
</context>
<context>
    <name>InfoWindow</name>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="14"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="116"/>
        <source>About</source>
        <translation>Σχετικά με</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="26"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="117"/>
        <source>Icon</source>
        <translation>Εικονίδιο</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="43"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="118"/>
        <source>License</source>
        <translation>Άδεια</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="56"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="119"/>
        <source>GPLv3+</source>
        <translation>GPLv3+</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="89"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="120"/>
        <source>Version</source>
        <translation>Έκδοση</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="102"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="121"/>
        <source>Flameshot v</source>
        <translation>Flameshot v</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="115"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="122"/>
        <source>OS Info</source>
        <translation>Πληροφορίες Λειτουργικού Συστήματος</translation>
    </message>
    <message>
        <location filename="../../src/widgets/infowindow.ui" line="128"/>
        <location filename="../../build/src/flameshot_autogen/include/ui_infowindow.h" line="123"/>
        <source>Copy Info</source>
        <translation>Αντιγραφή πληροφοριών</translation>
    </message>
    <message>
        <source>Right Click</source>
        <translation type="vanished">Clic dret</translation>
    </message>
    <message>
        <source>Mouse Wheel</source>
        <translation type="vanished">Roda del ratolí</translation>
    </message>
    <message>
        <source>Move selection 1px</source>
        <translation type="vanished">Mou la selecció 1 px</translation>
    </message>
    <message>
        <source>Resize selection 1px</source>
        <translation type="vanished">Redimensiona la selecció 1 px</translation>
    </message>
    <message>
        <source>Quit capture</source>
        <translation type="vanished">Ix de la captura</translation>
    </message>
    <message>
        <source>Copy to clipboard</source>
        <translation type="vanished">Copia al porta-retalls</translation>
    </message>
    <message>
        <source>Save selection as a file</source>
        <translation type="vanished">Guarda la selecció com a fitxer</translation>
    </message>
    <message>
        <source>Undo the last modification</source>
        <translation type="vanished">Desfés l&apos;última modificació</translation>
    </message>
    <message>
        <source>Show color picker</source>
        <translation type="vanished">Mostra el selector de color</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="vanished">Canvia el gruix de l&apos;eina</translation>
    </message>
    <message>
        <source>Key</source>
        <translation type="vanished">Tecla</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="vanished">Descripció</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;License&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Άδεια&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Version&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Έκδοση&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>&lt;u&gt;&lt;b&gt;Shortcuts&lt;/b&gt;&lt;/u&gt;</source>
        <translation type="vanished">&lt;u&gt;&lt;b&gt;Dreceres&lt;/b&gt;&lt;/u&gt;</translation>
    </message>
    <message>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation type="vanished">Dreceres disponibles en el mode de captura de pantalla.</translation>
    </message>
</context>
<context>
    <name>InvertTool</name>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="25"/>
        <source>Invert</source>
        <translation>Αντιστροφή</translation>
    </message>
    <message>
        <location filename="../../src/tools/invert/inverttool.cpp" line="35"/>
        <source>Set Inverter as the paint tool</source>
        <translation>Ρυθμίστε την Αντιστροφή ως εργαλείο ζωγραφικής</translation>
    </message>
</context>
<context>
    <name>LineTool</name>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="22"/>
        <source>Line</source>
        <translation>Γραμμή</translation>
    </message>
    <message>
        <location filename="../../src/tools/line/linetool.cpp" line="32"/>
        <source>Set the Line as the paint tool</source>
        <translation>Ορίστε τη Γραμμή ως εργαλείο ζωγραφικής</translation>
    </message>
</context>
<context>
    <name>MarkerTool</name>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="23"/>
        <source>Marker</source>
        <translation>Marker</translation>
    </message>
    <message>
        <location filename="../../src/tools/marker/markertool.cpp" line="33"/>
        <source>Set the Marker as the paint tool</source>
        <translation>Ορίστε το Marker ως εργαλείο ζωγραφικής</translation>
    </message>
</context>
<context>
    <name>MoveTool</name>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="23"/>
        <source>Move</source>
        <translation>Μετακίνηση</translation>
    </message>
    <message>
        <location filename="../../src/tools/move/movetool.cpp" line="33"/>
        <source>Move the selection area</source>
        <translation>Μετακίνηση της επιλεγμένης περιοχής</translation>
    </message>
</context>
<context>
    <name>PencilTool</name>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="18"/>
        <source>Pencil</source>
        <translation>Μολύβι</translation>
    </message>
    <message>
        <location filename="../../src/tools/pencil/penciltool.cpp" line="28"/>
        <source>Set the Pencil as the paint tool</source>
        <translation>Ορίστε το Μολύβι ως εργαλείο ζωγραφικής</translation>
    </message>
</context>
<context>
    <name>PinTool</name>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="25"/>
        <source>Pin Tool</source>
        <translation>Εργαλείο Καρφίτσας</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pintool.cpp" line="35"/>
        <source>Pin image on the desktop</source>
        <translation>Καρφιτσώστε την εικόνα στην επιφάνεια εργασίας</translation>
    </message>
</context>
<context>
    <name>PinWidget</name>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="282"/>
        <source>Context menu</source>
        <translation>Γενικό πλαίσιο μενού</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="284"/>
        <source>Copy to clipboard</source>
        <translation>Αντιγραφή στο πρόχειρο</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="291"/>
        <source>Save to file</source>
        <translation>Αποθήκευση στο αρχείο</translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="298"/>
        <source>Rotate Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="303"/>
        <source>Rotate Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="308"/>
        <source>Increase Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="315"/>
        <source>Decrease Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tools/pin/pinwidget.cpp" line="322"/>
        <source>Close</source>
        <translation type="unfinished">Κλείσιμο</translation>
    </message>
</context>
<context>
    <name>PixelateTool</name>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="27"/>
        <source>Pixelate</source>
        <translation>Pixelate</translation>
    </message>
    <message>
        <location filename="../../src/tools/pixelate/pixelatetool.cpp" line="37"/>
        <source>Set Pixelate as the paint tool.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Pixelate as the paint tool</source>
        <translation type="vanished">Ορίστε το Pixelate ως εργαλείο ζωγραφικής</translation>
    </message>
</context>
<context>
    <name>PrimaryInstanceWidget</name>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/primaryinstancewidget.cpp" line="21"/>
        <source>Primary instance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/primaryinstancewidget.cpp" line="22"/>
        <source>&lt;b&gt;Primary instance.&lt;/b&gt; Messages received from secondaries:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QHotkey</name>
    <message>
        <source>Failed to register %1. Error: %2</source>
        <translation type="vanished">Απέτυχε η εγγραφή του %1. Σφάλμα: %2</translation>
    </message>
    <message>
        <source>Failed to unregister %1. Error: %2</source>
        <translation type="vanished">Απέτυχε η κατάργηση της εγγραφής του %1. Σφάλμα: %2</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="196"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="198"/>
        <source>Capture saved to clipboard.</source>
        <translation>Η λήψη αποθηκεύτηκε στο πρόχειρο.</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="182"/>
        <source>Error while saving to clipboard</source>
        <translation>Σφάλμα κατά την αποθήκευση στο πρόχειρο</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="244"/>
        <source>Save screenshot</source>
        <translation>Αποθήκευση στιγμιότυπου οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="275"/>
        <source>Path copied to clipboard as </source>
        <translation>Η διαδρομή αντιγράφηκε στο πρόχειρο ως </translation>
    </message>
    <message>
        <source>Saving canceled</source>
        <translation type="vanished">Saving canceled</translation>
    </message>
    <message>
        <source>Save canceled</source>
        <translation type="vanished">Save canceled</translation>
    </message>
    <message>
        <source>Capture is saved and copied to the clipboard as </source>
        <translation type="vanished">Capture is saved and copied to the clipboard as </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="286"/>
        <source>Save Error</source>
        <translation>Αποθήκευση Σφάλματος</translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="62"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="267"/>
        <source>Capture saved as </source>
        <translation>Η λήψη αποθηκεύτηκε ως </translation>
    </message>
    <message>
        <location filename="../../src/utils/screenshotsaver.cpp" line="66"/>
        <location filename="../../src/utils/screenshotsaver.cpp" line="279"/>
        <source>Error trying to save as </source>
        <translation>Σφάλμα κατά την προσπάθεια αποθήκευσης ως </translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="220"/>
        <source>Unable to connect via DBus</source>
        <translation>Δεν είναι δυνατή η σύνδεση μέσω DBus</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="237"/>
        <source>Powerful yet simple to use screenshot software.</source>
        <translation>Ισχυρό αλλά απλό στη χρήση λογισμικό στιγμιότυπων οθόνης.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="238"/>
        <source>See</source>
        <translation>Δες</translation>
    </message>
    <message>
        <source>Capture the entire desktop.</source>
        <translation type="vanished">Καταγράψτε ολόκληρη την επιφάνεια εργασίας.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="244"/>
        <source>Open the capture launcher.</source>
        <translation>Ανοίξτε τον εκκινητή καταγραφής.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="247"/>
        <source>Start a manual capture in GUI mode.</source>
        <translation>Ξεκινήστε μια χειροκίνητη λήψη σε λειτουργία GUI.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="249"/>
        <source>Configure</source>
        <translation>Διαμορφώστε</translation>
    </message>
    <message>
        <source>Capture a single screen.</source>
        <translation type="vanished">Λήψη μίας οθόνης.</translation>
    </message>
    <message>
        <source>Path where the capture will be saved</source>
        <translation type="vanished">Path where the capture will be saved</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="242"/>
        <source>Capture screenshot of all monitors at the same time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="252"/>
        <source>Capture a screenshot of the specified monitor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="257"/>
        <source>Existing directory or new file to save to</source>
        <translation>Υπάρχων κατάλογος ή νέο αρχείο για αποθήκευση</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="260"/>
        <source>Save the capture to the clipboard</source>
        <translation>Αποθηκεύστε τη λήψη στο πρόχειρο</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="262"/>
        <source>Pin the capture to the screen</source>
        <translation>Καρφιτσώστε τη λήψη στην οθόνη</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="264"/>
        <source>Upload screenshot</source>
        <translation>Μεταφόρτωση στιγμιότυπου οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="266"/>
        <source>Delay time in milliseconds</source>
        <translation>Χρόνος καθυστέρησης σε χιλιοστά του δευτερολέπτου</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="271"/>
        <source>Repeat screenshot with previously selected region</source>
        <translation>Επαναλάβετε το στιγμιότυπο οθόνης με την προηγουμένως επιλεγμένη περιοχή</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="274"/>
        <source>Screenshot region to select</source>
        <translation>Περιοχή στιγμιότυπου οθόνης για επιλογή</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="277"/>
        <source>Set the filename pattern</source>
        <translation>Ορίστε το μοτίβο ονόματος αρχείου</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="281"/>
        <source>Accept capture as soon as a selection is made</source>
        <translation>Αποδεχτείτε τη λήψη μόλις γίνει μια επιλογή</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="283"/>
        <source>Enable or disable the trayicon</source>
        <translation>Ενεργοποιήστε ή απενεργοποιήστε το εικονίδιο tray</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="287"/>
        <source>Enable or disable run at startup</source>
        <translation>Ενεργοποίηση ή απενεργοποίηση της εκτέλεσης κατά την εκκίνηση</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="291"/>
        <source>Enable or disable the notifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="294"/>
        <source>Check the configuration for errors</source>
        <translation>Ελέγξτε τη διαμόρφωση για σφάλματα</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="297"/>
        <source>Show the help message in the capture mode</source>
        <translation>Εμφάνιση του μηνύματος βοήθειας στη λειτουργία λήψης</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="300"/>
        <source>Define the main UI color</source>
        <translation>Καθορίστε το κύριο χρώμα διεπαφής χρήστη</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="304"/>
        <source>Define the contrast UI color</source>
        <translation>Καθορίστε το χρώμα του αντίθεσης διεπαφής χρήστη</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="307"/>
        <source>Print raw PNG capture</source>
        <translation>Εκτυπώστε λήψη raw PNG</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="310"/>
        <source>Print geometry of the selection in the format WxH+X+Y. Does nothing if raw is specified</source>
        <translation>Εκτύπωση γεωμετρίας της επιλογής στη μορφή WxH+X+Y. Δεν κάνει τίποτα εάν έχει καθοριστεί raw</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="314"/>
        <source>Define the screen to capture (starting from 0)</source>
        <translation>Καθορίστε την οθόνη για λήψη (ξεκινώντας από το 0)</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="334"/>
        <source>Invalid delay, it must be a number greater than 0</source>
        <translation>Μη έγκυρη καθυστέρηση, πρέπει να είναι αριθμός μεγαλύτερος από 0</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="337"/>
        <source>Invalid region, use &apos;WxH+X+Y&apos; or &apos;all&apos; or &apos;screen0/screen1/...&apos;.</source>
        <translation>Μη έγκυρη περιοχή, χρησιμοποιήστε &apos;WxH+X+Y&apos; ή &apos;όλες&apos; ή &apos;οθόνη0/οθόνη1/...&apos;.</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="350"/>
        <source>Invalid path, must be an existing directory or a new file in an existing directory</source>
        <translation>Μη έγκυρη διαδρομή, πρέπει να είναι ένας υπάρχων κατάλογος ή ένα νέο αρχείο σε έναν υπάρχοντα κατάλογο</translation>
    </message>
    <message>
        <source>Define the screen to capture</source>
        <translation type="vanished">Define the screen to capture</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="315"/>
        <source>default: screen containing the cursor</source>
        <translation>προεπιλογή: οθόνη που περιέχει τον κέρσορα</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="316"/>
        <source>Screen number</source>
        <translation>Αριθμός οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="325"/>
        <source>Invalid color, this flag supports the following formats:
- #RGB (each of R, G, and B is a single hex digit)
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- Named colors like &apos;blue&apos; or &apos;red&apos;
You may need to escape the &apos;#&apos; sign as in &apos;\#FFF&apos;</source>
        <translation>Μη έγκυρο χρώμα, αυτή η σημαία υποστηρίζει τις ακόλουθες μορφές:
- #RGB (καθένα από τα R, G και B είναι ένα μόνο εξαψήφιο)
- #RRGGBB
- #RRRGGGBBB
- #RRRRGGGGBBBB
- Ονομασμένα χρώματα όπως &quot;μπλε&quot; ή &quot;κόκκινο&quot;
Ίσως χρειαστεί να ξεφύγετε από το σύμβολο &quot;#&quot; όπως στο &quot;\#FFF&quot;</translation>
    </message>
    <message>
        <source>Invalid delay, it must be higher than 0</source>
        <translation type="vanished">Invalid delay, it must be higher than 0</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="336"/>
        <source>Invalid screen number, it must be non negative</source>
        <translation>Μη έγκυρος αριθμός οθόνης, δεν πρέπει να είναι αρνητικός</translation>
    </message>
    <message>
        <source>Invalid path, it must be a real path in the system</source>
        <translation type="vanished">Invalid path, it must be a real path in the system</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="363"/>
        <source>Invalid value, it must be defined as &apos;true&apos; or &apos;false&apos;</source>
        <translation>Μη έγκυρη τιμή, πρέπει να οριστεί ως &quot;true&quot; ή &quot;false&quot;</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="30"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../../src/tools/launcher/openwithprogram.cpp" line="31"/>
        <source>Unable to write in</source>
        <translation>Δεν είναι δυνατή η εγγραφή στο</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="156"/>
        <source>Requested screen exceeds screen count</source>
        <translation>Η ζητούμενη οθόνη υπερβαίνει τον αριθμό οθονών</translation>
    </message>
    <message>
        <location filename="../../src/core/flameshot.cpp" line="408"/>
        <source>Full screen screenshot pinned to screen</source>
        <translation>Στιγμιότυπο πλήρης οθόνης καρφιτσώθηκε στην οθόνη</translation>
    </message>
    <message>
        <source>URL copied to clipboard.</source>
        <translation type="vanished">Η διεύθυνση URL αντιγράφηκε στο πρόχειρο.</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="54"/>
        <source>Options</source>
        <translation>Επιλογές</translation>
    </message>
    <message>
        <source>Arguments</source>
        <translation type="vanished">Ορίσματα</translation>
    </message>
    <message>
        <source>arguments</source>
        <translation type="vanished">ορίσματα</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="68"/>
        <source>Subcommands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="328"/>
        <source>subcommands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="329"/>
        <source>Usage</source>
        <translation>Χρήση</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="329"/>
        <source>options</source>
        <translation>επιλογές</translation>
    </message>
    <message>
        <location filename="../../src/cli/commandlineparser.cpp" line="334"/>
        <source>Per default runs Flameshot in the background and adds a tray icon for configuration.</source>
        <translation>Από προεπιλογή εκτελείται το Flameshot στο παρασκήνιο και προσθέτει ένα εικονίδιο tray για διαμόρφωση.</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="71"/>
        <source>Hello, I&apos;m here! Click icon in the tray to take a screenshot or click with a right button to see more options.</source>
        <translation>Γεια σας, είμαι εδώ! Κάντε κλικ στο εικονίδιο tray για να τραβήξετε ένα στιγμιότυπο οθόνης ή κάντε κλικ με το δεξί κουμπί για να δείτε περισσότερες επιλογές.</translation>
    </message>
    <message>
        <source>Toggle side panel</source>
        <translation type="vanished">Toggle side panel</translation>
    </message>
    <message>
        <source>Resize selection left 1px</source>
        <translation type="vanished">Resize selection left 1px</translation>
    </message>
    <message>
        <source>Resize selection right 1px</source>
        <translation type="vanished">Resize selection right 1px</translation>
    </message>
    <message>
        <source>Resize selection up 1px</source>
        <translation type="vanished">Resize selection up 1px</translation>
    </message>
    <message>
        <source>Resize selection down 1px</source>
        <translation type="vanished">Resize selection down 1px</translation>
    </message>
    <message>
        <source>Select entire screen</source>
        <translation type="vanished">Select entire screen</translation>
    </message>
    <message>
        <source>Move selection left 1px</source>
        <translation type="vanished">Move selection left 1px</translation>
    </message>
    <message>
        <source>Move selection right 1px</source>
        <translation type="vanished">Move selection right 1px</translation>
    </message>
    <message>
        <source>Move selection up 1px</source>
        <translation type="vanished">Move selection up 1px</translation>
    </message>
    <message>
        <source>Move selection down 1px</source>
        <translation type="vanished">Move selection down 1px</translation>
    </message>
    <message>
        <source>Commit text in text area</source>
        <translation type="vanished">Commit text in text area</translation>
    </message>
    <message>
        <source>Delete current tool</source>
        <translation type="vanished">Delete current tool</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="195"/>
        <source>Quit capture</source>
        <translation>Κλείστε την λήψη</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="207"/>
        <source>Screenshot history</source>
        <translation>Ιστορικό στιγμιότυπων οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="211"/>
        <source>Capture screen</source>
        <translation>Καταγραφή οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="218"/>
        <source>Show color picker</source>
        <translation>Εμφάνιση επιλογέα χρώματος</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="219"/>
        <source>Change the tool&apos;s size</source>
        <translation>Αλλάξτε το μέγεθος των εργαλείων</translation>
    </message>
    <message>
        <source>Change the tool&apos;s thickness</source>
        <translation type="vanished">Αλλάξτε το πάχος του εργαλείου</translation>
    </message>
</context>
<context>
    <name>RectangleTool</name>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="22"/>
        <source>Rectangle</source>
        <translation>Ορθογώνιο παραλληλόγραμμο</translation>
    </message>
    <message>
        <location filename="../../src/tools/rectangle/rectangletool.cpp" line="32"/>
        <source>Set the Rectangle as the paint tool</source>
        <translation>Ορίστε το Ορθογώνιο ως εργαλείο ζωγραφικής</translation>
    </message>
</context>
<context>
    <name>RedoTool</name>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="23"/>
        <source>Redo</source>
        <translation>Επανάληψη</translation>
    </message>
    <message>
        <location filename="../../src/tools/redo/redotool.cpp" line="33"/>
        <source>Redo the next modification</source>
        <translation>Επαναλάβετε την επόμενη τροποποίηση</translation>
    </message>
</context>
<context>
    <name>SaveTool</name>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="24"/>
        <source>Save</source>
        <translation>Αποθήκευση</translation>
    </message>
    <message>
        <location filename="../../src/tools/save/savetool.cpp" line="34"/>
        <source>Save screenshot to a file</source>
        <translation>Αποθήκευση στιγμιότυπου οθόνης σε αρχείο</translation>
    </message>
    <message>
        <source>Save the capture</source>
        <translation type="vanished">Save the capture</translation>
    </message>
</context>
<context>
    <name>ScreenGrabber</name>
    <message>
        <source>Unable to detect desktop environment (GNOME? KDE? Sway? ...)</source>
        <translation type="vanished">Δεν είναι δυνατός ο εντοπισμός του περιβάλλοντος επιφάνειας εργασίας (GNOME; KDE; Sway; ...)</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="53"/>
        <source>The universal wayland screen capture adapter requires Grim as the screen capture component of wayland. If the screen capture component is missing, please install it!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="171"/>
        <source>If the useGrimAdapter setting is not enabled, the dbus protocol will be used. It should be noted that using the dbus protocol under wayland is not recommended. It is recommended to enable the useGrimAdapter setting in flameshot.ini to activate the grim-based general wayland screenshot adapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="182"/>
        <source>grim&apos;s screenshot component is implemented based on wlroots, it may not be used in GNOME or similar desktop environments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="194"/>
        <source>Unable to detect desktop environment (GNOME? KDE? Qile? Sway? ...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="197"/>
        <source>Hint: try setting the XDG_CURRENT_DESKTOP environment variable.</source>
        <translation>Συμβουλή: δοκιμάστε να ρυθμίσετε τη μεταβλητή περιβάλλοντος XDG_CURRENT_DESKTOP.</translation>
    </message>
    <message>
        <location filename="../../src/utils/screengrabber.cpp" line="202"/>
        <source>Unable to capture screen</source>
        <translation>Δεν είναι δυνατή η λήψη της οθόνης</translation>
    </message>
</context>
<context>
    <name>SecondaryInstanceWidget</name>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="26"/>
        <source>Secondary instance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="27"/>
        <source>&lt;b&gt;Secondary instance.&lt;/b&gt; Send message to primary:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="29"/>
        <source>Type something here...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="31"/>
        <source>&amp;Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="54"/>
        <source>Error sending message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../build/_deps/kdsingleapplication-src/examples/widgetsingleapplication/secondaryinstancewidget.cpp" line="55"/>
        <source>The message &apos;%1&apos; could not be sent to the primary.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SelectionTool</name>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="25"/>
        <source>Rectangular Selection</source>
        <translation>Ορθογώνια Επιλογή</translation>
    </message>
    <message>
        <location filename="../../src/tools/selection/selectiontool.cpp" line="35"/>
        <source>Set Selection as the paint tool</source>
        <translation>Ορίστε την Επιλογή ως το εργαλείο ζωγραφικής</translation>
    </message>
</context>
<context>
    <name>SetShortcutDialog</name>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="18"/>
        <source>Set Shortcut</source>
        <translation>Ορισμός Συντόμευσης</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="24"/>
        <source>Enter new shortcut to change </source>
        <translation>Εισαγάγετε νέα συντόμευση για αλλαγή </translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="38"/>
        <source>Press Esc to cancel or ⌘+Backspace to disable the keyboard shortcut.</source>
        <translation>Πατήστε Esc για ακύρωση ή ⌘+Backspace για να απενεργοποιήσετε τη συντόμευση πληκτρολογίου.</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="42"/>
        <source>Press Esc to cancel or Backspace to disable the keyboard shortcut.</source>
        <translation>Πατήστε Esc για ακύρωση ή Backspace για να απενεργοποιήσετε τη συντόμευση πληκτρολογίου.</translation>
    </message>
    <message>
        <location filename="../../src/config/setshortcutwidget.cpp" line="48"/>
        <location filename="../../src/config/setshortcutwidget.cpp" line="53"/>
        <source>Flameshot must be restarted for changes to take effect.</source>
        <translation>Πρέπει να γίνει επανεκκίνηση του Flameshot για να τεθούν σε ισχύ οι αλλαγές.</translation>
    </message>
</context>
<context>
    <name>ShortcutsWidget</name>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="27"/>
        <source>Hot Keys</source>
        <translation>Hot Keys</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="48"/>
        <source>Available shortcuts in the screen capture mode.</source>
        <translation>Διαθέσιμες συντομεύσεις στη λειτουργία λήψης οθόνης.</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="59"/>
        <source>Description</source>
        <translation>Περιγραφή</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="59"/>
        <source>Key</source>
        <translation>Πλήκτρο</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="162"/>
        <source>Left Double-click</source>
        <translation>Αριστερό Διπλό Κλικ</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="169"/>
        <source>Toggle side panel</source>
        <translation>Εναλλαγή πλαϊνού πάνελ</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="170"/>
        <source>Grab a color from the screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="171"/>
        <source>Resize selection left 1px</source>
        <translation>Αλλαγή μεγέθους επιλογής αριστερά 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="172"/>
        <source>Resize selection right 1px</source>
        <translation>Αλλαγή μεγέθους επιλογής δεξιά 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="173"/>
        <source>Resize selection up 1px</source>
        <translation>Αλλαγή μεγέθους επιλογής έως 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="174"/>
        <source>Resize selection down 1px</source>
        <translation>Αλλαγή μεγέθους επιλογής κατά 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="176"/>
        <source>Symmetrically decrease width by 2px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="178"/>
        <source>Symmetrically increase width by 2px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="180"/>
        <source>Symmetrically increase height by 2px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="182"/>
        <source>Symmetrically decrease height by 2px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="183"/>
        <source>Select entire screen</source>
        <translation>Επιλέξτε ολόκληρη την οθόνη</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="184"/>
        <source>Move selection left 1px</source>
        <translation>Μετακίνηση επιλογής αριστερά 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="185"/>
        <source>Move selection right 1px</source>
        <translation>Μετακίνηση επιλογής δεξιά 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="186"/>
        <source>Move selection up 1px</source>
        <translation>Μετακίνηση επιλογής επάνω 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="187"/>
        <source>Move selection down 1px</source>
        <translation>Μετακίνηση επιλογής κάτω 1px</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="188"/>
        <source>Commit text in text area</source>
        <translation>Δέσμευση κειμένου στην περιοχή κειμένου</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="190"/>
        <source>Delete selected drawn object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="191"/>
        <source>Cancel current selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete current tool</source>
        <translation type="vanished">Διαγραφή τρέχοντος εργαλείου</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="200"/>
        <source>Capture screen</source>
        <translation>Καταγραφή οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/config/shortcutswidget.cpp" line="202"/>
        <source>Screenshot history</source>
        <translation>Ιστορικό στιγμιότυπων οθόνης</translation>
    </message>
</context>
<context>
    <name>SidePanelWidget</name>
    <message>
        <source>Active thickness:</source>
        <translation type="vanished">Active thickness:</translation>
    </message>
    <message>
        <source>Active color:</source>
        <translation type="vanished">Active color:</translation>
    </message>
    <message>
        <source>Press ESC to cancel</source>
        <translation type="vanished">Press ESC to cancel</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="37"/>
        <source>Active tool size: </source>
        <translation>Ενεργό μέγεθος εργαλείου: </translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="57"/>
        <source>Active Color: </source>
        <translation>Ενεργό Χρώμα: </translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="78"/>
        <source>Grab Color</source>
        <translation>Πιάσε το Χρώμα</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/sidepanelwidget.cpp" line="85"/>
        <source>Display grid</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SizeDecreaseTool</name>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="37"/>
        <source>Decrease Tool Size</source>
        <translation>Μείωση Μεγέθους Εργαλείου</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizedecrease/sizedecreasetool.cpp" line="47"/>
        <source>Decrease the size of the other tools</source>
        <translation>Μειώστε το μέγεθος των άλλων εργαλείων</translation>
    </message>
</context>
<context>
    <name>SizeIncreaseTool</name>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="37"/>
        <source>Increase Tool Size</source>
        <translation>Αύξηση Μεγέθους Εργαλείου</translation>
    </message>
    <message>
        <location filename="../../src/tools/sizeincrease/sizeincreasetool.cpp" line="47"/>
        <source>Increase the size of the other tools</source>
        <translation>Αυξήστε το μέγεθος των άλλων εργαλείων</translation>
    </message>
</context>
<context>
    <name>SizeIndicatorTool</name>
    <message>
        <source>Selection Size Indicator</source>
        <translation type="vanished">Δείκτης Μεγέθους Επιλογής</translation>
    </message>
    <message>
        <source>Show X and Y dimensions of the selection</source>
        <translation type="vanished">Εμφάνιση των διαστάσεων X και Y της επιλογής</translation>
    </message>
    <message>
        <source>Show the dimensions of the selection (X Y)</source>
        <translation type="vanished">Show the dimensions of the selection (X Y)</translation>
    </message>
</context>
<context>
    <name>StrftimeChooserWidget</name>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="43"/>
        <source>Century (00-99)</source>
        <translation>Αιώνας (00-99)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="44"/>
        <source>Year (00-99)</source>
        <translation>Έτος (00-99)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="45"/>
        <source>Year (2000)</source>
        <translation>Έτος (2000)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="48"/>
        <source>Month Name (jan)</source>
        <translation>Όνομα Μήνα (Ιαν)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="49"/>
        <source>Month Name (january)</source>
        <translation>Όνομα Μήνα (Ιανουάριος)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="51"/>
        <source>Month (01-12)</source>
        <translation>Μήνας (01-12)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="52"/>
        <source>Week Day (1-7)</source>
        <translation>Ημέρα Eβδομάδας (1-7)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="53"/>
        <source>Week (01-53)</source>
        <translation>Εβδομάδα (01-53)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="56"/>
        <source>Day Name (mon)</source>
        <translation>Όνομα Hμέρας (Δευτ)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="57"/>
        <source>Day Name (monday)</source>
        <translation>Όνομα Ημέρας (Δευτέρα)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="59"/>
        <source>Day (01-31)</source>
        <translation>Ημέρα (01-31)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="60"/>
        <source>Day of Month (1-31)</source>
        <translation>Ημέρα του Μήνα (1-31)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="61"/>
        <source>Day (001-366)</source>
        <translation>Ημέρα (001-366)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="67"/>
        <source>Hour (00-23)</source>
        <translation>Ώρα (00-23)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="68"/>
        <source>Hour (01-12)</source>
        <translation>Ώρα (01-12)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="69"/>
        <source>Minute (00-59)</source>
        <translation>Λεπτό (00-59)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="70"/>
        <source>Second (00-59)</source>
        <translation>Δευτερόλεπτο (00-59)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="73"/>
        <source>Full Date (%m/%d/%y)</source>
        <translation>Πλήρης Ημερομηνία (%μήνας/%μέρα/%έτος)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="75"/>
        <source>Full Date (%Y-%m-%d)</source>
        <translation>Πλήρης Ημερομηνία (%έτος-%μήνας-%μέρα)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="76"/>
        <source>Full Date (%d-%m-%Y)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="64"/>
        <source>Time (%H-%M-%S)</source>
        <translation>Ώρα (%Ω-%Λ-%Δ)</translation>
    </message>
    <message>
        <location filename="../../src/config/strftimechooserwidget.cpp" line="65"/>
        <source>Time (%H-%M)</source>
        <translation>Ώρα (%Ω-%Λ)</translation>
    </message>
</context>
<context>
    <name>SystemNotification</name>
    <message>
        <location filename="../../src/utils/systemnotification.cpp" line="42"/>
        <source>Flameshot Info</source>
        <translation>Πληροφορίες Flameshot</translation>
    </message>
</context>
<context>
    <name>TextConfig</name>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="44"/>
        <source>StrikeOut</source>
        <translation>StrikeOut</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="53"/>
        <source>Underline</source>
        <translation>Υπογραμμίζω</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="62"/>
        <source>Bold</source>
        <translation>Έντονο</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="71"/>
        <source>Italic</source>
        <translation>Italic</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="81"/>
        <source>Left Align</source>
        <translation>Αριστερή Στοίχιση</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="90"/>
        <source>Center Align</source>
        <translation>Στοίχιση στο Κέντρο</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/textconfig.cpp" line="99"/>
        <source>Right Align</source>
        <translation>Δεξιά Στοίχιση</translation>
    </message>
</context>
<context>
    <name>TextTool</name>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="73"/>
        <source>Text</source>
        <translation>Κείμενο</translation>
    </message>
    <message>
        <location filename="../../src/tools/text/texttool.cpp" line="97"/>
        <source>Add text to your capture</source>
        <translation>Προσθέστε κείμενο στη λήψη σας</translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="100"/>
        <source>&amp;Take Screenshot</source>
        <translation>&amp;Λήψη Στιγμιότυπου οθόνης</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="118"/>
        <source>&amp;Open Launcher</source>
        <translation>&amp;Άνοιγμα Εκκινητή</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="123"/>
        <source>&amp;Configuration</source>
        <translation>&amp;Διαμόρφωση</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="128"/>
        <source>&amp;About</source>
        <translation>&amp;Σχετικά με</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="133"/>
        <source>Check for updates</source>
        <translation>Έλεγχος για ενημερώσεις</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="144"/>
        <source>New version %1 is available</source>
        <translation>Η νέα έκδοση % 1 είναι διαθέσιμη</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="149"/>
        <source>&amp;Quit</source>
        <translation>%Κλείσιμο</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="154"/>
        <source>&amp;Latest Uploads</source>
        <translation>&amp;Τελευταίες Μεταφορτώσεις</translation>
    </message>
    <message>
        <location filename="../../src/widgets/trayicon.cpp" line="160"/>
        <source>&amp;Open Save Path</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIcolorEditor</name>
    <message>
        <source>UI Color Editor</source>
        <translation type="vanished">Επεξεργαστής Χρωμάτων Διεπαφής χρήστη</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="88"/>
        <source>Change the color moving the selectors and see the changes in the preview buttons.</source>
        <translation>Αλλάξτε το χρώμα μετακινώντας τους επιλογείς και δείτε τις αλλαγές στα κουμπιά προεπισκόπησης.</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="99"/>
        <source>Select a Button to modify it</source>
        <translation>Επιλέξτε ένα κουμπί για να το τροποποιήσετε</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="109"/>
        <source>Main Color</source>
        <translation>Κύριο Χρώμα</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="113"/>
        <source>Click on this button to set the edition mode of the main color.</source>
        <translation>Κάντε κλικ σε αυτό το κουμπί για να ορίσετε τη λειτουργία έκδοσης του κύριου χρώματος.</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="124"/>
        <source>Contrast Color</source>
        <translation>Χρώμα Αντίθεσης</translation>
    </message>
    <message>
        <location filename="../../src/config/uicoloreditor.cpp" line="129"/>
        <source>Click on this button to set the edition mode of the contrast color.</source>
        <translation>Κάντε κλικ σε αυτό το κουμπί για να ορίσετε τη λειτουργία έκδοσης του χρώματος αντίθεσης.</translation>
    </message>
</context>
<context>
    <name>UndoTool</name>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="23"/>
        <source>Undo</source>
        <translation>Αναίρεση</translation>
    </message>
    <message>
        <location filename="../../src/tools/undo/undotool.cpp" line="33"/>
        <source>Undo the last modification</source>
        <translation>Αναίρεση της τελευταίας τροποποίησης</translation>
    </message>
</context>
<context>
    <name>UpdateNotificationWidget</name>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="70"/>
        <source>New Flameshot version %1 is available</source>
        <translation>Η νέα έκδοση Flameshot % 1 είναι διαθέσιμη</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="123"/>
        <source>Ignore</source>
        <translation>Αγνόησή</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="131"/>
        <source>Later</source>
        <translation>Αργότερα</translation>
    </message>
    <message>
        <location filename="../../src/widgets/updatenotificationwidget.cpp" line="139"/>
        <source>Update</source>
        <translation>Ενημέρωση</translation>
    </message>
</context>
<context>
    <name>UploadHistory</name>
    <message>
        <location filename="../../src/widgets/uploadhistory.ui" line="14"/>
        <source>Upload History</source>
        <translation>Ιστορικό Mεταφόρτωσης</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadhistory.cpp" line="60"/>
        <source>Screenshots history is empty</source>
        <translation>Το ιστορικό στιγμιότυπων οθόνης είναι κενό</translation>
    </message>
</context>
<context>
    <name>UploadLineItem</name>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="20"/>
        <source>Form</source>
        <translation>Φόρμα</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="49"/>
        <source>TextLabel</source>
        <translation>Ετικέτα Κειμένου</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="82"/>
        <source>Copy URL</source>
        <translation>Αντιγραφή διεύθυνσης URL</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.ui" line="95"/>
        <source>Open In Browser</source>
        <translation>Άνοιγμα σε Πρόγραμμα περιήγησης</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="50"/>
        <source>Confirm to delete</source>
        <translation>Επιβεβαίωση για διαγραφή</translation>
    </message>
    <message>
        <location filename="../../src/widgets/uploadlineitem.cpp" line="51"/>
        <source>Are you sure you want to delete a screenshot from the latest uploads and server?</source>
        <translation>Είστε βέβαιοι ότι θέλετε να διαγράψετε ένα στιγμιότυπο οθόνης από τις πιο πρόσφατες μεταφορτώσεις και διακομιστή;</translation>
    </message>
</context>
<context>
    <name>UtilityPanel</name>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="196"/>
        <source>Close</source>
        <translation>Κλείσιμο</translation>
    </message>
    <message>
        <location filename="../../src/widgets/panel/utilitypanel.cpp" line="206"/>
        <source>&lt;Empty&gt;</source>
        <translation>&lt;Άδειο&gt;</translation>
    </message>
</context>
<context>
    <name>VisualsEditor</name>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="41"/>
        <source>Opacity of area outside selection:</source>
        <translation>Αδιαφάνεια περιοχής εκτός επιλογής:</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="68"/>
        <source>UI Color Editor</source>
        <translation>Επεξεργαστής Χρωμάτων Διεπαφής χρήστη</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="74"/>
        <source>Colorpicker Editor</source>
        <translation>Επεξεργαστής Επιλογέα Χρώματος</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="79"/>
        <source>Button Selection</source>
        <translation>Επιλογή Κουμπιού</translation>
    </message>
    <message>
        <location filename="../../src/config/visualseditor.cpp" line="85"/>
        <source>Select All</source>
        <translation>Επιλογή Όλων</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorDialog</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_dialog.cpp" line="63"/>
        <source>Pick</source>
        <translation>Επιλογή</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPalette</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette.cpp" line="417"/>
        <source>Unnamed</source>
        <translation>Ανώνυμο</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteModel</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_model.cpp" line="55"/>
        <source>Unnamed</source>
        <translation>Ανώνυμο</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_model.cpp" line="130"/>
        <source>%1 (%2 colors)</source>
        <translation>% 1 (% 2 χρώματα)</translation>
    </message>
</context>
<context>
    <name>color_widgets::ColorPaletteWidget</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="64"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="231"/>
        <source>Open a new palette from file</source>
        <translation>Ανοίξτε μια νέα παλέτα από το αρχείο</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="75"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="234"/>
        <source>Create a new palette</source>
        <translation>Δημιουργήστε μια νέα παλέτα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="86"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="237"/>
        <source>Duplicate the current palette</source>
        <translation>Αντιγράψτε την τρέχουσα παλέτα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="170"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="240"/>
        <source>Delete the current palette</source>
        <translation>Διαγράψτε την τρέχουσα παλέτα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="181"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="243"/>
        <source>Revert changes to the current palette</source>
        <translation>Επαναφέρετε τις αλλαγές στην τρέχουσα παλέτα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="192"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="246"/>
        <source>Save changes to the current palette</source>
        <translation>Αποθηκεύστε τις αλλαγές στην τρέχουσα παλέτα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="216"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="249"/>
        <source>Add a color to the palette</source>
        <translation>Προσθέστε ένα χρώμα στην παλέτα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.ui" line="227"/>
        <location filename="../../build/_deps/qtcolorwidgets-build/QtColorWidgets_autogen/include/ui_color_palette_widget.h" line="252"/>
        <source>Remove the selected color from the palette</source>
        <translation>Αφαιρέστε το επιλεγμένο χρώμα από την παλέτα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="181"/>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="196"/>
        <source>New Palette</source>
        <translation>Νέα Παλέτα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="182"/>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="197"/>
        <source>Name</source>
        <translation>Όνομα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="223"/>
        <source>GIMP Palettes (*.gpl)</source>
        <translation>Παλέτες GIMP (* .gpl)</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="224"/>
        <source>Palette Image (%1)</source>
        <translation>Παλέτα Εικόνας (% 1)</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="225"/>
        <source>All Files (*)</source>
        <translation>Όλα τα Αρχεία (*)</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="226"/>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="239"/>
        <source>Open Palette</source>
        <translation>Ανοίξτε την Παλέτα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/color_palette_widget.cpp" line="240"/>
        <source>Failed to load the palette file
%1</source>
        <translation>Αποτυχία φόρτωσης του αρχείου παλέτας
%1</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientEditor</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_editor.cpp" line="321"/>
        <source>Add Color</source>
        <translation>Προσθήκη Χρώματος</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_editor.cpp" line="330"/>
        <source>Remove Color</source>
        <translation>Αφαιρέστε το Χρώμα</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_editor.cpp" line="338"/>
        <source>Edit Color...</source>
        <translation>Επεξεργασία Χρώματος...</translation>
    </message>
</context>
<context>
    <name>color_widgets::GradientListModel</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/gradient_list_model.cpp" line="215"/>
        <source>%1 (%2 colors)</source>
        <translation>% 1 (% 2 χρώματα)</translation>
    </message>
</context>
<context>
    <name>color_widgets::Swatch</name>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/swatch.cpp" line="855"/>
        <source>Clear Color</source>
        <translation>Καθαρισμός Χρώματος</translation>
    </message>
    <message>
        <location filename="../../build/_deps/qtcolorwidgets-src/src/QtColorWidgets/swatch.cpp" line="864"/>
        <source>%1 (%2)</source>
        <translation>%1 (%2)</translation>
    </message>
</context>
</TS>
