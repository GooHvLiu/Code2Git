#ifndef STUDENT_H
#define STUDENT_H

//类的声明放在头文件中
class Student
{
private:
	char name[32];
	int age;
public:
	void setInfo(const char *n, int a);    //存放成员函数的声明，不要实现
	void show();
};

#endif
