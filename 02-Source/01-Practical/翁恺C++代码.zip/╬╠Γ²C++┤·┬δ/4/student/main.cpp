#include "student.h"

int main()
{
	Student s1;

	s1.setInfo("aaa", 22);
	s1.show();

	return 0;
}
