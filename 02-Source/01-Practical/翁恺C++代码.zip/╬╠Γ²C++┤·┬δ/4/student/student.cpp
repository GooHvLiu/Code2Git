#include "student.h"
#include <string.h>
#include <iostream>

using namespace std;

void Student::setInfo(const char *n, int a)  //实现成员函数，加上作用域，否则变成了全局函数 返回值+作用域+函数名
{
	strcpy(name, n);
	age = a;
}

void Student::show()
{
	cout << "name : " << name << "    age : " << age << endl;
}
