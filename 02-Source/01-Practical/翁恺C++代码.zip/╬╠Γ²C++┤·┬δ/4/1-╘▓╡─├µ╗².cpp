#include <iostream>

using namespace std;

/*struct Circle  //结构体
{
	int r;
	double s;
};*/

class Circle    //类
{
private:      
	int r;         //成员变量   属性
	double s;
public:
	void setR(int _r)    //成员函数   方法
	{
		r = _r;
	}
	double getS()
	{
		s = 3.14 * r * r;
		return s;
	}
};

int main()
{
	//Circle c1;    //定义结构体变量（定义圆）
	//c1.r = 1;

	Circle c2;    //创建对象
	//setR();
	//c2.r = 2;
	c2.setR(2);    //通过方法操作属性
	cout << c2.getS() << endl;

	return 0;
}
