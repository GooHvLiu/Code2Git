#include <iostream>

using namespace std;

class Test
{
private:
	int a;
	char b;    
public:
	Test(int _a)
	{	
		this->a = _a;
	}
	void show()    //等价于void show(Test *this)   所有的成员函数隐藏了一个参数 this指针
	{
		cout << this->a << endl;
	}
};

int main()
{
	Test t1(0);
	cout << sizeof(t1) << endl;  //不包含静态成员变量

	Test t2(1);

	t1.show();   //等价于 t1.show(&t1);
	t2.show();   //等价于 t2.show(&t2);

	return 0;
}
