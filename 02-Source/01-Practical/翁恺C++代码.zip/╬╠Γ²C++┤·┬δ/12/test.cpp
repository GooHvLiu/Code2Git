#include <iostream>

using namespace std;

int g = 100;

int f1()
{
	return g;
}

int &f2()
{
	return g;
}

int main()
{
	//f1() = 1;    //100 = 1;  不能作为左值
	f2() = 1;      //g = 1;    可以作为左值

	int a = 1;
	//a++ = 100;   //后置++不能作为左值使用   重载后置++运算符不能返回引用
	++a = 100;     //前置++可以作为左值使用   重载前置++运算符需要返回引用

	return 0;
}
