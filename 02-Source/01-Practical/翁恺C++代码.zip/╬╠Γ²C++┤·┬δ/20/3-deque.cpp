#include <deque>
#include <iostream>

using namespace std;

int main()
{
	int data[5] = {1, 2, 3, 4, 5};
	deque<int> d1;
	deque<int> d2(data, data + 5);
	deque<int> d3(10, 1);

	for (deque<int>::iterator it = d2.begin(); it != d2.end(); it++)
	{
		cout << *it << " ";
	}
	cout << endl;

	d2.push_back(6);    //结尾添加元素
	d2.push_front(0);   //开头添加元素
	for (deque<int>::iterator it = d2.begin(); it != d2.end(); it++)
	{
		cout << *it << " ";
	}
	cout << endl;

	d2.pop_back();
	d2.pop_front();
	for (deque<int>::iterator it = d2.begin(); it != d2.end(); it++)
	{
		cout << *it << " ";
	}
	cout << endl;

	d2.front() = 1000;
	d2.back() = 1000;
	for (deque<int>::iterator it = d2.begin(); it != d2.end(); it++)
	{
		cout << *it << " ";
	}
	cout << endl;

	deque<int>::iterator it = d2.erase(d2.begin());   //返回下一个元素的位置
	cout << *it << endl;

	return 0;
}
