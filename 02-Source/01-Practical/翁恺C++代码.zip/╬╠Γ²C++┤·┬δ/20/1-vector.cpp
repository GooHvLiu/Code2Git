#include <iostream>
#include <vector>

using namespace std;

int main()
{
	int data[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	vector<int> v1;     //创建数组对象（模板类）   无参构造函数
	vector<int> v2(data, data + 10);     //左闭右开  有参构造函数
	vector<int> v3(10, 1);

	v1.resize(10);        //扩充容量
	for (int i = 0; i < v1.size(); i++)
	{
		v1[i] = i;           //重载了下标运算符
	}

	for (int i = 0; i < v2.size(); i++)
	{
		cout << v2.at(i) << " ";
	}
	cout << endl;

	//正向迭代器
	//for (vector<int>::iterator it = v3.begin(); it != v3.end(); it++)
	for (vector<int>::iterator it = v3.begin(); it != v3.end(); it = it + 2)
	{
		cout << *it << " ";
	}
	cout << endl;

	//反向迭代器
	for (vector<int>::reverse_iterator rit = v2.rbegin(); rit != v2.rend(); rit++)
	{
		cout << *rit << " ";
	}
	cout << endl;

	//只读迭代器
	for (vector<int>::const_iterator cit = v2.begin(); cit != v2.end(); cit++)
	{
		//(*cit)++;   //只能访问不能修改
		cout << *cit << " ";
	}
	cout << endl;

	return 0;
}
