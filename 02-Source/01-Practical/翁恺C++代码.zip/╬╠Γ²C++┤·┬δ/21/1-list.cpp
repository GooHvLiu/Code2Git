#include <iostream>
#include <list>
#include <string.h>

using namespace std;

class Student
{
private:
	int id;
	char name[32];
public:
	Student(){}
	Student(int i, const char *n);
	void show();
	bool operator==(const Student &s);
};

Student::Student(int i, const char *n)
{
	id = i;
	strcpy(name, n);
}

void Student::show()
{
	cout << "id : " << id << "     name : " << name << endl;
}

bool Student::operator==(const Student &s)
{
	if (this->id == s.id && strcmp(this->name, s.name) == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

int main()
{
	Student s1(1, "aaa");
	Student s2(2, "bbb");
	Student s3(3, "ccc");
	Student s4(4, "ddd");
	Student s5(5, "eee");
	Student s6(6, "fff");

	list<Student> l;      //创建链表对象

	l.push_back(s1);      //尾插法
	l.push_back(s2);      //尾插法
	l.push_back(s3);      //尾插法
	l.push_back(s4);      //尾插法
	l.push_front(s5);     //头插法

	for (list<Student>::iterator it = l.begin(); it != l.end(); it++)
	{
		it->show();	
	}

	l.pop_front();        //删除第一个结点
	l.pop_back();         //删除最后一个结点

	cout << "****" << endl;
	for (list<Student>::iterator it = l.begin(); it != l.end(); it++)
	//for (list<Student>::iterator it = l.begin(); it != l.end(); it = it + 1)
	{
		it->show();	
	}

	cout << "第一个元素是：" << endl;
	l.front().show();

	cout << "最后一个元素是：" << endl;
	l.back().show();

	cout << "链表长度：" << endl;
	cout << l.size() << endl;

	cout << "链表扩充..." << endl;
	l.resize(5, s6);
	for (list<Student>::iterator it = l.begin(); it != l.end(); it++)
	{
		it->show();	
	}

	//对象数组
	cout << "********" << endl;
	Student s[5] = {Student(10, "a"), Student(11, "b"), Student(12, "c"), Student(13, "d"), Student(14, "e")};
	l.insert(l.begin(), s[0]);     //往链表开始位置插入对象s[0]
	for (list<Student>::iterator it = l.begin(); it != l.end(); it++)
	{
		it->show();	
	}

	cout << "*****" << endl;
	l.insert(l.end(), 5, s[4]);
	for (list<Student>::iterator it = l.begin(); it != l.end(); it++)
	{
		it->show();	
	}

	cout << "******" << endl;
	l.insert(l.end(), s, s + 3);   //往链表结尾插入一个区间
	for (list<Student>::iterator it = l.begin(); it != l.end(); it++)
	{
		it->show();	
	}

	cout << "删除一个区间" << endl;
	list<Student>::iterator it = l.begin();
	for (int i = 0; i < 5; i++)
	{	
		it++;
	}
	l.erase(it, l.end());
	for (list<Student>::iterator it = l.begin(); it != l.end(); it++)
	{
		it->show();	
	}

	cout << "删除一个位置" << endl;
	l.erase(l.begin());
	for (list<Student>::iterator it = l.begin(); it != l.end(); it++)
	{
		it->show();	
	}

	cout << "删除具体的元素" << endl;
	l.remove(s1);    //s1 == s2       重载==运算符
	for (list<Student>::iterator it = l.begin(); it != l.end(); it++)
	{
		it->show();	
	}

	cout << "链表翻转" << endl;
	l.reverse();
	for (list<Student>::iterator it = l.begin(); it != l.end(); it++)
	{
		it->show();	
	}

	return 0;
}
