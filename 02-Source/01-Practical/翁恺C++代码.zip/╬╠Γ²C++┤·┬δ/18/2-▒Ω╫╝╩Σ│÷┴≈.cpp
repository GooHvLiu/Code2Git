#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
#if 0
	//使用控制符的方法
	int num = 1000;
	cout << oct << num << endl;         //八进制输出
	cout << dec << num << endl;         //十进制输出
	cout << hex << num << endl;         //十六进制输出
	cout << setbase(8) << num << endl;

	double PI = 222.0000 / 7.00000;
	cout << PI << endl;
	cout << setprecision(15) << PI << endl;
	cout << setprecision(5) << setiosflags(ios::scientific) << PI << endl;

	const char *s = "helloworld";
	cout << setw(15) << setfill('*') << s << endl;
#endif

	//使用成员函数的方式
	int num = 1000;
	cout.unsetf(ios::dec);    //结束十进制格式输出
	cout.setf(ios::oct);      //设置八进制格式输出
	cout << num << endl;
	cout.unsetf(ios::oct);
	cout.setf(ios::hex);
	cout << num << endl;

	double PI = 222.000 / 7.000;
	cout.precision(5);
	cout << PI << endl;
	cout.setf(ios::scientific);
	cout << PI << endl;

	const char *s = "helloworld";
	cout.width(15);
	cout.fill('^');
	cout << s << endl;

	return 0;
}
