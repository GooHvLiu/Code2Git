#include <iostream>

using namespace std;

void f(int x, int y)
{
	
}

void f(int x, int y, int z = 0)      //歧义
{
	
}

int main()
{
	//f(1, 2);

	return 0;
}
