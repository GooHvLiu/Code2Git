#include <iostream>

using namespace std;

void print(int x, int y, int = 0)   //占位参数   和默认参数一起使用
{
	cout << x << y << endl;
}

int main()
{
	int a = 1, b = 2;
	print(a, b);

	return 0;
}
