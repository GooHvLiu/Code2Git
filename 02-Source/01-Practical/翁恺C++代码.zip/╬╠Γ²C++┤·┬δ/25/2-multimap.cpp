#include <iostream>
#include <map>

using namespace std;

class Employee
{
private:
	int id;
	string name;
public:
	Employee(int i, string n)
	{
		id = i;
		name = n;
	}
	void show()
	{
		cout << "工号：" << id << "    姓名：" << name << endl; 
	}
};

int main()
{
	Employee e1(1, "aa");
	Employee e2(2, "aa");
	Employee e3(3, "aa");
	Employee e4(4, "aa");
	Employee e5(5, "aa");
	Employee e6(6, "aa");
	Employee e7(7, "aa");
	Employee e8(8, "aa");

	multimap<string, Employee> m;

	//销售部门有三个员工
	m.insert(make_pair("sale", e1));
	m.insert(make_pair("sale", e2));
	m.insert(make_pair("sale", e3));

	//研发部门一个员工
	m.insert(make_pair("development", e4));

	//财务部门4个员工
	m.insert(make_pair("financial", e5));
	m.insert(make_pair("financial", e6));
	m.insert(make_pair("financial", e7));
	m.insert(make_pair("financial", e8));

	cout << m.count("financial") << endl;

	for (multimap<string, Employee>::iterator it = m.begin(); it != m.end(); it++)
	{
		cout << "部门：" << it->first << endl;
		it->second.show();
	}

	return 0;
}
