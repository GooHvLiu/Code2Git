#include <iostream>

using namespace std;

class Test
{
public:
	Test()
	{	
		cout << "无参构造函数" << endl;
	}
	Test(int a, int b)
	{
		cout << "有参构造函数" << endl;
	}
	~Test()
	{
		cout << "析构函数" << endl;
	}
};

int main()
{
	int *p1 = new int;     //给一个整数申请空间
	cout << *p1 << endl;
	delete p1;

	char *p2 = new char;   //给一个字符申请空间
	delete p2;

	int *p3 = new int(100);  //给一个整数申请空间同时初始化为100
	cout << *p3 << endl;
	delete p3;

	char *p4 = new char[10];   //给十个字符申请空间
	delete[] p4;

	Test *t1 = new Test;
	delete t1;

	Test *t2 = new Test(1, 2);
	delete t2;

	return 0;
}
