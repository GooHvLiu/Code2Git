#include "array.hpp"

int main()
{
	Array<int> a(10);   //模板需要经过两次编译
	a[1] = 100;

	return 0;
}
