#include <iostream>

using namespace std;

template <typename T>
class Test
{
private:
	T a;
public:
	static int count;
public:
	Test(T a)
	{
		this->a = a;
		count++;
	}
};

template <typename T>
int Test<T>::count = 0;

int main()
{
	Test<int> t1(1);
	Test<int> t2(1);
	Test<int> t3(1);
	Test<int> t4(1);
	Test<int> t5(1);

	Test<char> t6('a');
	Test<char> t7('a');
	Test<char> t8('a');

	cout << Test<int>::count << endl;
	cout << Test<char>::count << endl;

	return 0;
}
