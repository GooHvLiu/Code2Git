#include <iostream>

using namespace std;

template <typename T, typename U>
class Test
{
private:
	T a;
	U b;
public:
	Test(T a, U b)
	{
		this->a = a;
		this->b = b;
	}
	void show()
	{
		cout << a << " " << b << endl;
	}
};

int main()
{
	Test<int, char> t(1, 'a');   //类模板创建对象一定要显式调用
	t.show();

	return 0;
}
