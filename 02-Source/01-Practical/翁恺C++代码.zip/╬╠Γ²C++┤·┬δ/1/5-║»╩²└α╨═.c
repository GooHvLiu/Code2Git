#include <stdio.h>

int f1()    //C++中所有的函数都要有返回值
{
	return 1;
}

void f2()   //C语言表示可以接受任意类型的参数  C++表示不能接受任意个参数
{
	
}

int main()
{
	f1();
	f2(1, 2);

	return 0;
}
