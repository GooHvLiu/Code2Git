#include <stdio.h>

int main()
{
	int a = 1, b = 2;

	int num = (a > b) ? a : b;
	printf("%d\n", num);

	(a > b) ? a : b = 100;  //C语言中，返回的是具体的数值(2=100)  C++中，返回的是变量名(b=100)

	return 0;
}

