#include <stdio.h>

int main()
{
	register int i = 0;    //声明寄存器变量 不能取地址

	for (i = 0; i < 1000; i++);

	&i;     //C++  对寄存器变量取地址 register 关键字变得无效

	return 0;
}
