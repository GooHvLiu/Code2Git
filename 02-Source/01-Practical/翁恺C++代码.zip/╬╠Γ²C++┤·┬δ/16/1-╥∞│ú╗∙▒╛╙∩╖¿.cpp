#include <iostream>

using namespace std;

int Div(int x, int y)
{
	if (0 == y)
	{
		//return -1;
		//throw 0;        //抛出异常
		throw 'a';
	}

	return x / y;
}

int main()
{
	int a, b;

	cin >> a >> b;

	try{ 								//把可能抛出异常的代码放在try语句中
		cout << Div(a, b) << endl;
	}
	catch(int)
	{
		cout << "zero exception" << endl;
	}
	catch (char)
	{
		cout << "char exception" << endl;
	}

	return 0;
}
