#include <iostream>
#include <exception>

using namespace std;

int main()
{
	try{
		int *p = new int[-1];
	}
	catch (exception &e)
	{
		cout << e.what() << endl;
	}

	return 0;
}
