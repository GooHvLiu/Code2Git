#include <iostream>
#include <stdlib.h>

using namespace std;

class Array
{
private:
	int *data;
	int size;
public:
	Array(int s)
	{
		cout << "有参构造函数" << endl;
		size = s;
		data = (int *)malloc(sizeof(int) * size);
	}
	Array(const Array &a)    //深拷贝
	{
		cout << "Array拷贝构造函数" << endl;
		size = a.size;
		data = (int *)malloc(sizeof(int) * size);
		for (int i = 0; i < size; i++)
		{
			data[i] = a.data[i];
		}
	}
	~Array()
	{
		cout << "析构函数" << endl;
		if (data != NULL)
		{
			free(data);
		}
	}
};

int main()
{
	Array a1(10);
	Array a2(a1);  //编译器为每个类提供默认的拷贝构造函数 只做简单的赋值（浅拷贝）

	return 0;
}
