#include <iostream>
#include <cstring>

using namespace std;

class Person    //父类或者基类
{
//private:
protected:   //保护权限：类的内部可以访问，派生类内部可以访问，类的外部不能访问
	char name[32];
	int age;
public:
	/*Person()
	{
		cout << "Person构造函数" << endl;
		strcpy(name, "aaa");
		age = 20;
	}*/
	Person(const char *n, int a)
	{
		cout << "Person有参构造函数" << endl;
		strcpy(name, n);
		age = a;
	}
	~Person()
	{
		cout << "Person析构函数" << endl;
	}
};

class Date
{
protected:
	int year;
	int mouth;
	int day;
public:
	Date(int y, int m, int d)
	{
		cout << "Date有参构造函数" << endl;
		year = y;
		mouth = m;
		day = d;
	}
	~Date()
	{
		cout << "Date析构函数" << endl;
	}
};

class Student : public Person   //子类或者派生类   public继承的权限
{
private:
	Date birth;   //先构造父类，再构造成员，最后构造自己
	int id;
public:
	//当基类没有提供无参构造函数的时候，派生类需要通过对象初始化列表来传参
	Student(int i) : Person("aaa", 23), birth(1, 1, 1)
	{
		cout << "Student构造函数" << endl;
		this->id = i;
	}

	void show()
	{
		cout << name << " " << age << " " << id << endl;
		//cout << id << endl;
	}
	~Student()
	{
		cout << "Student析构函数" << endl;
	}
};

int main()
{
	Student s1(1);   //创建派生类对象，会先调用基类构造函数，来初始化继承来的成员
	s1.show();

	return 0;       //析构的顺序跟构造相反
}
