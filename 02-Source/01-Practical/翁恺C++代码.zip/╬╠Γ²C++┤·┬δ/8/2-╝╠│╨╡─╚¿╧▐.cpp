#include <iostream>

using namespace std;

class TestA
{
private:
	int a;    //只能在类的内部访问
protected:
	int b;
public:
	int c;
};

//私有继承
class TestB : private TestA 
{
/*
	int a;
private:
	int b;
private:
	int c;*/
public:
	void test()
	{
		//a++;   //在TestA中，a是私有成员变量，不能访问
		b++;
		c++;
	}
};

//保护继承
class TestC : protected TestA
{
/*
	int a;
protected:
	int b;
protected:
	int c;*/
public:
	void test()
	{
		//a++;
		b++;
		c++;
	}
};

//公有继承
class TestD : public TestA
{
/*
	int a;
protected:
	int b;
public:
	int c;*/
public:
	void test()
	{
		//a++;
		b++;
		c++;
	}
};

//继承权限：限制了成员在派生类中的最高权限
int main()
{
	TestB tb;
	//tb.b;
	//tb.c;

	TestD td;
	//td.b;
	td.c;

	return 0;
}
