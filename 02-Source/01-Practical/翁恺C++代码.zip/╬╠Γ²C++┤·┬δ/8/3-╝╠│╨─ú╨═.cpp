#include <iostream>

using namespace std;

class Person
{
public:
	int age;
};

class Student : public Person
{
public:
	int id;
};

int main()
{
	Student s;
	cout << sizeof(s) << endl;

	cout << &s << endl;  //派生类的内存布局：先存放基类成员，再存放派生类成员
	cout << &s.age << endl;
	cout << &s.id << endl;

	return 0;
}
