#include <iostream>
#include <typeinfo>

using namespace std;

class Parent
{
private:
	int a;
public:
	virtual void show()
	{
	}
};

class Child : public Parent
{
public:
	int array[102400];
public:
	void show()
	{
	}
};

void f(Parent *p)
{
	if (typeid(*p) == typeid(Child))
	{
		cout << "可以转换" << endl;
		Child *c = (Child *)p;    //派生类指针指向基类对象
		c->array[102400 - 1] = 100;
	}
	else if (typeid(*p) == typeid(Parent))
	{
		cout << "不能转换" << endl;
	}
}

int main()
{
	int a;
	char ch;
	Parent p1;
	Child c1;

	const type_info &pa = typeid(a);	
	const type_info &pch = typeid(ch);	
	const type_info &pp1 = typeid(p1);	
	const type_info &pc1 = typeid(c1);	

	cout << pa.name() << endl;
	cout << pch.name() << endl;
	cout << pp1.name() << endl;
	cout << pc1.name() << endl;

	//if (pa.name() == i)

	Parent *p = new Parent;
	//Parent *p = new Child;
	f(p);

	return 0;
}
