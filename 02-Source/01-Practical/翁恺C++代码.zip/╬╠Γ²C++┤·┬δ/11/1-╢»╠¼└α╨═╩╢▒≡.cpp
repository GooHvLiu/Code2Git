#include <iostream>

using namespace std;

class Parent
{
private:
	int a;
};

class Child : public Parent
{
public:
	int array[102400];
};

void f(Parent *p)
{
	Child *c = (Child *)p;    //派生类指针指向基类对象
	c->array[102400 - 1] = 100;
}

int main()
{
	//Parent *p = new Child;
	Parent *p = new Parent;
	f(p);

	return 0;
}
