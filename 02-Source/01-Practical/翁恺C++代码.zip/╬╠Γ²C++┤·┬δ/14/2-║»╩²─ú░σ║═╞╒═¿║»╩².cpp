#include <iostream>

using namespace std;

int add(int x, int y)
{
	cout << "普通函数" << endl;
	return x + y;
}

template <typename T>
T add(T x, T y)
{
	cout << "模板函数" << endl;
	return x + y;
}

template <typename T>
void show(T x, T y)
{
	cout << x << y << endl;
}

int main()
{
	cout << add(1, 'a') << endl;   //普通函数可以进行默认类型转换
	show<int>(1, 'a');             //模板函数没有默认的类型转换

	add(1, 2);                     //普通函数和模板函数同时存在，优先调用普通函数

	return 0;
}
