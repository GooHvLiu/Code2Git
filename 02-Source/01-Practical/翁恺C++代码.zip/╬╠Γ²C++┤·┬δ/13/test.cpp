#include <iostream>

using namespace std;

int main()
{
	int a, b;

	//(a + b) = 1;  //+不能作为左值使用 重载+运算符不能返回引用

	(a = b) = 1;

	return 0;
}
