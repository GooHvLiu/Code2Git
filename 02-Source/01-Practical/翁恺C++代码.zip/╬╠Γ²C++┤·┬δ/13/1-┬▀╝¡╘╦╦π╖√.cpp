#include <iostream>

using namespace std;

int f1()
{
	cout << "this is f1" << endl;
	return 0;
}

int f2()
{
	cout << "this is f2" << endl;
	return 1;
}

class Complex
{
private:
	int a;
	int b;
public:
	Complex(int a, int b)
	{
		this->a = a;
		this->b = b;
	}
	Complex operator+(const Complex &c)
	{
		cout << "operator+" << endl;
		Complex t(0, 0);
		t.a = this->a + c.a;
		t.b = this->b + c.b;

		return t;
	}
	bool operator&&(const Complex &c)
	{
		return (this->a && c.a) && (this->b && c.b);
	}
};

int main()
{
	if (f1() && f2())   //短路原则：如果f1()不成立，则不会执行f2()
	{
		cout << "helloworld" << endl;
	}

	Complex c1(1, 1);
	Complex c2(2, 2);
	Complex c3(0, 0);

	if (c1 && c2)
	{
		cout << "成立" << endl;
	}

	if (c1 && c3)
	{
		cout << "成立" << endl;
	}

	//c3.operator&&(c1 + c2)   c3.operator&&(c1.operator+(c2))
	if (c3 && (c1 + c2))    //重载逻辑&&违背了短路原则  所以不要重载逻辑&& ||
	{
		
	}

	return 0;
}
