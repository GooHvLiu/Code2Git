#include <iostream>
#include <memory>

using namespace std;

class Test
{
public:
	Test()
	{
		cout << "Test构造函数" << endl;
	}
	void print()
	{	
		cout << "xxx" << endl;
	}
	~Test()
	{
		cout << "Test析构函数" << endl;
	}
};

void f1()
{
	Test *pt = new Test;    //内存泄漏
}

void f2()
{
	auto_ptr<Test> my_memory(new Test);

	my_memory->print();   //my_mempry.operator->(print())
}

int main()
{
	//f1();
	f2();

	return 0;
}
