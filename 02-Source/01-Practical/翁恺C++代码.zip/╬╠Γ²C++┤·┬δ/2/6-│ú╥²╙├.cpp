#include <iostream>

using namespace std;

int main()
{
	int a = 1;
	int &pa = a;   //可以用变量初始化普通引用

	//int &pb = 1;   //不可以用常量初始化普通引用

	const int &pc = a;   //常引用   变量可以初始化常引用
	//pc++;      //不能通过pc来修改对应内存的值
	a++;         //可以通过其他方式修改
	cout << pc << endl;

	const int &pd = 1;    //可以使用常量初始化常引用
	int *p = (int *)&pd;
	(*p)++;
	cout << pd << endl;

	return 0;
}
