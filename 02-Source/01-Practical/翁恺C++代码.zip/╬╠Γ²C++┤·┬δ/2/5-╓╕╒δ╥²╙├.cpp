#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

void Init(char *&s)  //引用指针
{
	s = (char *)malloc(sizeof(char) * 100);
}

int main()
{
	char *s = NULL;

	Init(s);

	strcpy(s, "hello");

	return 0;
}
