#include <iostream>

using namespace std;

int g = 100;

int &f1()
{
	int a = 1;
	//return a;    //不要返回局部变量的引用
	return g;
}

int f2()
{
	return g;
}

int main()
{
	int &b = f1();

	f1() = 1;
	//f2() = 1;   //等价于100 = 1;

	return 0;
}

