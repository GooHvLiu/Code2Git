#include <iostream>

using namespace std;

class Airplane 
{
protected:
	int high;
public:
	Airplane()
	{
		cout << "飞机的构造函数" << endl;
		high = 100;
	}
	void show()
	{
		cout << "飞行高度 " << high << endl;
	}
};

class Ship
{
protected:
	int speed;
public:
	Ship()
	{
		cout << "轮船的构造函数" << endl;
		speed = 50;
	}
	void show()
	{
		cout << "航行的速度 " << speed << endl;
	}
};

class WaterPlane : public Ship, public Airplane   //多继承
{
public:
	WaterPlane()
	{
		cout << "水上飞机的构造函数" << endl;
	}
};

int main()
{
	WaterPlane w;   //先构造基类，再构造派生类，基类的构造顺序和继承顺序有关
	cout << sizeof(w) << endl;
	w.Airplane::show();
	w.Ship::show();

	return 0;
}
