#include <iostream>
#include <mysql/mysql.h>
#include <stdio.h>
#include <iomanip>

using namespace std;

MYSQL *Init()
{
	MYSQL *m;

	m = mysql_init(NULL);   //创建mysql对象并且初始化，返回对象的地址
	if (NULL == m)
	{
		cout << mysql_error(m) << endl;    //打印错误信息
		return NULL;
	}

	m = mysql_real_connect(m, "localhost", "root", "root", "mydatabase", 0, NULL, 0);
	if (NULL == m)
	{
		cout << mysql_error(m) << endl;    //打印错误信息
		return NULL;
	}
}

void InsertDataBase(MYSQL *m)
{
	if (NULL == m)
	{
		return;
	}

	int ret = mysql_query(m, "set names utf8;");
	if (ret != 0)
	{
		cout << mysql_error(m) << endl;
		return;
	}

	char sql[128] = {0};
	int id, age;
	char name[32] = {0}, birth[32] = {0}, sex[32] = {0}, tel[32] = {0};

	cout << "请输入编号、姓名、出生日期、年龄、性别、电话" << endl;
	cin >> id >> name >> birth >> age >> sex >> tel;

	sprintf(sql, "insert into student (id, name, birth, age, sex, tel) values (%d, '%s', '%s', %d, '%s', '%s');", id, name, birth, age, sex, tel);

	ret = mysql_query(m, sql);
	if (ret != 0)
	{
		cout << mysql_error(m) << endl;
		return;
	}

	cout << "插入成功" << endl;
}

void FindDataBase(MYSQL *m)
{
	if (m == NULL)
	{
		return;
	}

	mysql_query(m, "set names utf8;");

	int ret = mysql_query(m, "select * from student;");
	if (ret != 0)
	{	
		cout << mysql_error(m) << endl;
		return;
	}

	MYSQL_RES *res = mysql_store_result(m);    //获取查询到的结果
	if (NULL == res)
	{
		cout << mysql_error(m) << endl;
		return;
	}

	//获取字段数
	int field = mysql_num_fields(res);
	//cout << field << endl;

	MYSQL_FIELD *f;                         //结构体
	while (f = mysql_fetch_field(res))
	{
		cout << setw(20) << setiosflags(ios::left) << f->name;            //打印字段名
	}
	cout << endl;

	//获取每一条记录
	MYSQL_ROW r;     //数组
	while (r = mysql_fetch_row(res))
	{
		for (int i = 0; i < field; i++)
		{
			cout << setw(20) << setiosflags(ios::left) << r[i];
		}
		cout << endl;
	}
}

int main()
{
	MYSQL *mysql;       //创建mysql对象

	mysql = Init();
	if (NULL == mysql)
	{
		cout << "初始化mysql失败" << endl;
	}
	else
	{
		cout << "连接数据库成功" << endl;
	}

	//插入数据
	//InsertDataBase(mysql);

	//查询数据
	FindDataBase(mysql);

	return 0;
}
