#include <iostream>
#include <exception>

using namespace std;

int main()
{
	string s("helloworld");

	cout << s[1] << endl;        //重载了下标运算符
	s[1] = 'x';

	cout << s << endl;

	cout << s.at(1) << endl;     //通过成员函数来访问

	//cout << s[20000] << endl;    //越界访问程序异常结束
	try{
		cout << s.at(10) << endl;      //越界访问会抛出异常
	}
	catch (exception &e)
	{
		cout << e.what() << endl;
	}

	return 0;
}
