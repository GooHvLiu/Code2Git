#include <iostream>

using namespace std;

int main()
{
	string s1("helloworld");
	string s2("12345");

	s1.insert(0, "this is ");
	cout << s1 << endl;

	s1.insert(10, s2);
	cout << s1 << endl;

	s1.insert(0, 5, 'x');
	cout << s1 << endl;

	s1.erase(0, 20);
	cout << s1 << endl;

	return 0;
}
