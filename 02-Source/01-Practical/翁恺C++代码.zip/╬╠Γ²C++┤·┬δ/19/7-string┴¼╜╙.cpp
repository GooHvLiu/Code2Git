#include <iostream>

using namespace std;

int main()
{
	string s1("helloworld");

	s1 += "1234";    //重载了+=运算符
	cout << s1 << endl;

	string s2("abcdefg");
	s1 += s2;
	cout << s1 << endl;

	const char *s = "haha";
	s1.append(s);
	cout << s1 << endl;

	s1.append(s, 2);
	cout << s1 << endl;

	s1.append(s2);
	cout << s1 << endl;

	s1.append(s2, 4, 2);
	cout << s1 << endl;

	s1.append(10, 'x');
	cout << s1 << endl;

	return 0;
}
