#include <iostream>
#include <string.h>

using namespace std;

int main()
{
	int p;
	string s1("helloworld");
	string s2("world");

	p = s1.find('o');
	cout << p << endl;

	p = s1.find('x');    //不存在返回-1
	cout << p << endl;

	p = s1.find('o', 5);
	cout << p << endl;

	p = s1.find("ll");
	cout << p << endl;

	p = s1.find(s2);
	cout << p << endl;

	p = s1.rfind('o');    //反向查找
	cout << p << endl;

	s1.replace(5, 5, "xxx");
	cout << s1 << endl;

	s1.replace(5, 3, s2);
	cout << s1 << endl;

	string s3("helloworldhelloworldhelloworldhelloworld");
	p = s3.find("world");
	while (p != -1)
	{
		s3.replace(p, strlen("world"), "x");
		p = s3.find("world", p + strlen("x"));
	}
	cout << s3 << endl;

	return 0;
}
