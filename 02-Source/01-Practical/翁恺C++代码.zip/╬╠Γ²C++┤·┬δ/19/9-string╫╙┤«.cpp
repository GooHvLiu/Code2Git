#include <iostream>

using namespace std;

int main()
{
	string s("helloworld");

	cout << s.substr() << endl;
	cout << s.substr(5, 5) << endl;

	return 0;
}
