#include <iostream>

using namespace std;

int main()
{
	string s1("helloworld");

	s1 = "hello";        //重载了=运算符
	cout << s1 << endl;

	const char *s = "this is test";
	s1.assign(s);
	cout << s1 << endl;

	s1.assign(s, 7);
	cout << s1 << endl;

	s1.assign(5, 'a');     //把5个a赋值给s1
	cout << s1 << endl;

	string s2("hey boy");
	s1.assign(s2);         //把对象s2赋值给s1
	cout << s1 << endl;

	s1.assign(s2, 4, 3);
	cout << s1 << endl;

	return 0;
}
