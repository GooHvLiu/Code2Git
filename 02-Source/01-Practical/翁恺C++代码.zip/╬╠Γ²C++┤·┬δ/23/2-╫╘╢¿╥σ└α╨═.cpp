#include <iostream>
#include <queue>

using namespace std;

class Student
{
	friend class compare;
private:
	int id;
	string name;
public:
	Student(int i, string n);
	void show() const;
	bool operator<(const Student &s) const; 
	bool operator>(const Student &s) const;
};

Student::Student(int i, string n)
{
	id = i;
	name = n;
}

void Student::show() const
{
	cout << "id " << id << "    name " << name << endl;
}

bool Student::operator<(const Student &s) const
{
	return this->id < s.id;
}

bool Student::operator>(const Student &s) const
{
	return this->name > s.name;
}

class compare
{
public:
	bool operator()(const Student &s1, const Student &s2) const
	{
		return s1.id < s2.id;
	}
};

int main()
{
	Student s1(1, "zz");
	Student s2(4, "ff");
	Student s3(3, "bb");
	Student s4(7, "ee");
	Student s5(9, "cc");
	Student s6(5, "dd");

	//priority_queue<Student> p;   //需要Student重载<
	//priority_queue<Student, vector<Student>, less<Student> > p;
	//priority_queue<Student, vector<Student>, greater<Student> > p;   //需要Student重载>
	priority_queue<Student, vector<Student>, compare> p;

	/*
	compare c;       //函数对象   仿函数   
	c.operator()(s1, s2);
	c(s1, s2);
	*/

	p.push(s1);
	p.push(s2);
	p.push(s3);
	p.push(s4);
	p.push(s5);
	p.push(s6);

	while (!p.empty())
	{
		p.top().show();
		p.pop();
	}

	return 0;
}
