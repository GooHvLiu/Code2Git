import { App } from 'vue';
export declare function useProvide(app: App, options?: Options): void;
