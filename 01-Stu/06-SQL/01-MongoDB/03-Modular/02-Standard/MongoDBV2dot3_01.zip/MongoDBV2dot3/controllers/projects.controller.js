const { success, fail } = require("@MongoDB/utils/response.js");
const { projectsService } = require("@MongoDB/services/index.service.js");
const { spawn, execSync } = require("child_process");
const fs = require("fs");
const path = require("path");
const dotenv = require("dotenv");
const dotenvExpand = require("dotenv-expand");

class ProjectsController {
  /**
   * 通过锁文件+PID校验项目进程是否运行
   * @param {Object} project 项目数据库文档
   * @returns {Promise<boolean>} 运行返回true，未运行false
   */
  async #getProjectRunStatus(project) {
    const lockFilePath = path.join(project.workDir, ".running.lock");
    if (!fs.existsSync(lockFilePath)) return false;

    try {
      const pid = fs.readFileSync(lockFilePath, "utf-8").trim();
      const taskOutput = execSync(`tasklist /FI "PID eq ${pid}"`, {
        encoding: "utf-8",
      });
      return taskOutput.includes(pid);
    } catch (err) {
      if (fs.existsSync(lockFilePath)) fs.unlinkSync(lockFilePath);
      return false;
    }
  }

  /**
   * 内部停止项目逻辑
   * @param {string} projectId 项目ID
   * @returns {Promise<boolean>} 停止成功返回true
   */
  async #stopInner(projectId) {
    try {
      const project = await projectsService.findById(projectId);
      if (!project) return false;

      const lockPath = path.join(project.workDir, ".running.lock");
      if (!fs.existsSync(lockPath)) return false;

      const pid = fs.readFileSync(lockPath, "utf-8").trim();
      execSync(`taskkill /F /PID ${pid}`, { encoding: "utf-8" });
      fs.unlinkSync(lockPath);

      project.status = "stopped";
      await project.save();
      return true;
    } catch (err) {
      console.error("内部停止项目异常：", err);
      return false;
    }
  }

  /**
   * 后台异步收集端口并更新数据库（不阻塞HTTP响应）
   * @param {string} projectId 项目ID
   * @param {string} envPort .env原生端口兜底
   * @param {string} title 项目名称
   * @param {ReadableStream} stdout 子进程标准输出流
   */
  #asyncCollectPortAndSave(projectId, envPort, title, stdout) {
    let childPort = null;
    let fullStdoutLog = "";
    const listenRegList = [
      /listening on (0\.0\.0\.0|127\.0\.0\.1|localhost):(\d+)/i,
      /Ports[:：]\s*(\d+)/i,
    ];

    stdout.on("data", (data) => {
      const logChunk = data.toString();
      fullStdoutLog += logChunk;
      for (const reg of listenRegList) {
        const match = logChunk.match(reg);
        if (match && !childPort) {
          childPort = match[match.length - 1];
          break;
        }
      }
    });

    // 后台延时收集日志，不阻塞接口
    setTimeout(async () => {
      try {
        // 兜底二次匹配全部日志
        if (!childPort) {
          for (const reg of listenRegList) {
            const finalMatch = fullStdoutLog.match(reg);
            if (finalMatch) {
              childPort = finalMatch[finalMatch.length - 1];
              break;
            }
          }
        }
        const realPort = childPort || envPort;
        const project = await projectsService.findById(projectId);
        if (!project) return;
        project.bindIp = "127.0.0.1";
        project.bindPort = realPort;
        await project.save();
      } catch (err) {
        console.error(`【后台更新端口失败 项目${title}】`, err);
      }
    }, 2500);
  }

  /**
   * 内部启动项目核心逻辑
   * @param {string} projectId 项目ID
   * @returns {Promise<boolean>} 启动成功true，失败false
   */
  async #startInner(projectId) {
    try {
      const project = await projectsService.findById(projectId);
      if (!project) return false;

      const isRunning = await this.#getProjectRunStatus(project);
      if (isRunning) return false;

      const lockPath = path.join(project.workDir, ".running.lock");

      // 仅保留Windows系统基础环境，隔离主项目业务环境污染
      const safeSystemEnvKeys = [
        "PATH",
        "SystemRoot",
        "windir",
        "TEMP",
        "TMP",
        "USERNAME",
        "COMPUTERNAME",
        "ComSpec",
        "OS",
        "PROCESSOR_ARCHITECTURE",
        "LOCALAPPDATA",
        "APPDATA",
        "HOSTNAME",
        "USERDNSDOMAIN",
      ];
      const baseEnv = {};
      safeSystemEnvKeys.forEach((key) => {
        if (process.env[key]) baseEnv[key] = process.env[key];
      });

      const envFilePath = path.join(project.workDir, ".env");
      let childEnv = { ...baseEnv };
      let envPort = "";

      if (fs.existsSync(envFilePath)) {
        const rawText = fs.readFileSync(envFilePath, "utf-8");
        const parsedRaw = dotenv.parse(rawText);
        envPort = parsedRaw.PORT || "";

        // 隔离全局env，防止dotenv-expand读取主项目变量污染插值
        const originalProcessEnv = { ...process.env };
        process.env = { ...baseEnv };
        const expandResult = dotenvExpand.expand({ parsed: parsedRaw });
        process.env = originalProcessEnv;

        const expandedEnv = expandResult.parsed;
        childEnv = { ...baseEnv, ...expandedEnv };
      }

      // ========== 修复Windows spawn .cmd EINVAL 核心改动 ==========
      const rawCmd = project.startCmd;
      let execBin;
      let execArgs;

      if (process.platform === "win32") {
        // Windows 用 cmd /c 承载整条命令，兼容 npm.cmd / yarn.cmd 批处理
        execBin = "cmd.exe";
        execArgs = ["/c", rawCmd];
      } else {
        // Linux/Mac 正常分割
        const cmdArr = rawCmd.split(" ");
        execBin = cmdArr[0];
        execArgs = cmdArr.slice(1);
      }
      // ==========================================================

      const childProc = spawn(execBin, execArgs, {
        cwd: project.workDir,
        detached: true,
        stdio: ["ignore", "pipe", "pipe"],
        env: childEnv,
      });
      childProc.unref();

      // 后台异步收集端口、更新数据库，不阻塞接口返回
      this.#asyncCollectPortAndSave(
        projectId,
        envPort,
        project.title,
        childProc.stdout,
      );

      // 错误流统一捕获打印
      childProc.stderr.on("data", (errData) => {
        console.error(`【子项目${project.title}错误输出】`, errData.toString());
      });

      // 进程退出清理锁文件
      childProc.on("close", (code) => {
        if (fs.existsSync(lockPath)) fs.unlinkSync(lockPath);
        console.warn(`【子项目${project.title}进程退出，退出码：${code}】`);
      });

      // 立刻写入锁文件，不再等待日志
      fs.writeFileSync(lockPath, String(childProc.pid), "utf-8");

      // 直接返回成功，无任何同步延时，前端瞬间弹窗
      return true;
    } catch (err) {
      console.error("启动项目内部逻辑异常：", err);
      return false;
    }
  }

  /**
   * 前端启动项目接口（无阻塞，点击立刻弹窗）
   * @param {Request} req
   * @param {Response} res
   */
  async start(req, res) {
    try {
      const { id } = req.params;
      const project = await projectsService.findById(id);
      if (!project) return fail(res, "项目不存在");

      const isRunning = await this.#getProjectRunStatus(project);
      if (isRunning) return fail(res, "该项目已在运行中");

      const startResult = await this.#startInner(id);
      if (!startResult)
        return fail(res, "项目启动失败，请查看服务日志排查问题");

      // 立即返回成功，无2.5秒等待
      return success(res, null, "项目启动成功");
    } catch (err) {
      console.error("启动接口异常：", err);
      return fail(res, err.message || "项目启动失败");
    }
  }

  /**
   * 前端停止项目接口
   * @param {Request} req
   * @param {Response} res
   */
  async stop(req, res) {
    try {
      const { id } = req.params;
      const project = await projectsService.findById(id);
      if (!project) return fail(res, "项目不存在");

      const lockPath = path.join(project.workDir, ".running.lock");
      if (!fs.existsSync(lockPath)) return fail(res, "项目当前未运行");

      const stopOk = await this.#stopInner(id);
      if (!stopOk) return fail(res, "停止项目失败");

      return success(res, null, "项目已停止");
    } catch (err) {
      console.error("停止接口异常：", err);
      return fail(res, err.message || "停止项目失败");
    }
  }

  /**
   * 重启项目接口
   * @param {Request} req
   * @param {Response} res
   */
  async restart(req, res) {
    try {
      const { id } = req.params;
      const project = await projectsService.findById(id);
      if (!project) return fail(res, "项目不存在");

      const stopOk = await this.#stopInner(id);
      if (!stopOk) return fail(res, "停止旧进程失败，无法执行重启");

      // 短暂释放端口，仅300ms，体感无延迟
      await new Promise((resolve) => setTimeout(resolve, 300));
      const startOk = await this.#startInner(id);
      if (!startOk)
        return fail(res, "停止成功，但新项目启动失败，请查看控制台日志");

      return success(res, null, "项目重启完成");
    } catch (err) {
      console.error("重启接口异常：", err);
      return fail(res, err.message || "重启项目失败");
    }
  }

  /**
   * 获取全部项目列表，同步运行状态
   * @param {Request} req
   * @param {Response} res
   */
  async getProjectsList(req, res) {
    try {
      const projectsListData = await projectsService.findAll();
      for (const item of projectsListData) {
        const running = await this.#getProjectRunStatus(item);
        item.status = running ? "active" : "stopped";
        await item.save();
      }
      return success(res, projectsListData, "获取项目列表成功");
    } catch (err) {
      console.error("获取项目列表异常：", err);
      return fail(res, err.message);
    }
  }

  /**
   * EJS页面渲染专用：获取项目列表数据
   * @param {Request} req
   * @returns {Promise<Object>}
   */
  async getProjectsListData(req) {
    try {
      const projectsListData = await projectsService.findAll();
      for (const item of projectsListData) {
        const running = await this.#getProjectRunStatus(item);
        item.status = running ? "active" : "stopped";
        await item.save();
      }
      return {
        type: 1,
        msg: "获取项目列表成功",
        data: projectsListData,
      };
    } catch (err) {
      console.error("页面列表查询异常：", err);
      return {
        type: -1,
        msg: err.message || "获取项目列表失败，请检查填写数据",
        error: err,
      };
    }
  }

  /**
   * 创建新项目接口
   * @param {Request} req
   * @param {Response} res
   */
  async createProjects(req, res) {
    try {
      const createProjectsData = await projectsService.createProject(req.body);
      return success(res, createProjectsData, "创建成功");
    } catch (err) {
      console.error("创建项目异常：", err);
      return fail(res, err.message);
    }
  }

  /**
   * 页面渲染专用：创建项目数据处理
   * @param {Object} payload
   * @returns {Promise<Object>}
   */
  async createProjectsData(payload) {
    try {
      const data = await projectsService.createProject(payload);
      return {
        type: 1,
        msg: "创建成功",
        data: data,
      };
    } catch (err) {
      return {
        type: -1,
        msg: err.message || "项目创建失败，请检查填写数据",
        error: err,
      };
    }
  }
}

module.exports = new ProjectsController();
