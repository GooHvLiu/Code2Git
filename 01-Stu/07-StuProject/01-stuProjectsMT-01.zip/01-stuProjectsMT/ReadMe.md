# 07-学习项目

## stuProjects

### 项目需求

* 创建数据库保存登录信息
* 将学习各个平台的封装到同一个项目中
* 通过登录选择进入某一个学习平台界面
* 后台使用MEN（MongoDB+Express+Node.js）创建
* 后端Node.js + Express + MongoDB + JWT认证流程实现
* 前端:
  * 前期使用HTML+CSS+JavaScript创建，通过 **HTTPS**（或局域网内的安全传输）将明文密码发送给后端
  * 后期使用MEVN（MongoDB+Express+Vue+Node.js）创建

### 后端设计

首先创建01-stuProjects主文件夹，用于存放所有项目文件和npm包。

#### 模板搭建

##### 前期安装

###### 前端框架

express 本身是一个 npm 包，所以可以通过 npm 安装 :

```cmd
PS C:\Users\Administrator\Desktop\01-stuProjects> npm init
This utility will walk you through creating a package.json file.
It only covers the most common items, and tries to guess sensible defaults.

See `npm help init` for definitive documentation on these fields
and exactly what they do.

Use `npm install <pkg>` afterwards to install a package and
save it as a dependency in the package.json file.

Press ^C at any time to quit.
package name: (01-stuprojects) stu_projects
version: (1.0.0) 
description: Study's Project Manager Tools.
entry point: (index.js) 
test command: 
git repository: 
keywords: 
author: GooHv
license: (ISC) 
type: (commonjs) 
About to write to C:\Users\Administrator\Desktop\01-stuProjects\package.json:

{
  "name": "stu_projects",
  "version": "1.0.0",
  "description": "Study's Project Manager Tools.",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "GooHv",
  "license": "ISC",
  "type": "commonjs"
}


Is this OK? (yes) 
PS C:\Users\Administrator\Desktop\01-stuProjects> npm i express

added 66 packages in 1s

24 packages are looking for funding
  run `npm fund` for details
PS C:\Users\Administrator\Desktop\01-stuProjects> 
```

###### 模板生成

通过generator应用生成器工具 `express-generator` 可以快速创建一个应用的骨架。

你可以通过 `npx` （包含在 Node.js 8.2.0 及更高版本中）命令来运行 Express 应用程序生成器。

```cmd
PS C:\Users\Administrator\Desktop\01-stuProjects> npx express-generator

  warning: the default view engine will not be jade in future releases
  warning: use `--view=jade' or `--help' for additional options

destination is not empty, continue? [y/N] y

   create : public\
   create : public\javascripts\
   create : public\images\
   create : public\stylesheets\
   create : public\stylesheets\style.css
   create : routes\
   create : routes\index.js
   create : routes\users.js
   create : views\
   create : views\error.jade
   create : views\index.jade
   create : views\layout.jade
   create : app.js
   create : package.json
   create : bin\
   create : bin\www

   install dependencies:
     > npm install

   run the app:
     > SET DEBUG=01-stuprojects:* & npm start

PS C:\Users\Administrator\Desktop\01-stuProjects>
```

###### EJS后缀

在个别操作中，express生成器会生成Jade后缀文件模板，我们需要统一采用EJS后缀文件模板，需要安装EJS包机相应的代码修改：

```bash
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i ejs      

added 1 package in 952ms

9 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm list ejs
stu_projects_manager_tool@0.0.0 F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT
└── ejs@6.0.1

PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> 
```

修改app.js文件试图引擎配置。

```js
// view engine setup
app.set("views", path.join(__dirname, "views"));
// 注释掉 Jade 配置
// app.set("view engine", "jade");
// 添加 EJS 配置
app.set("view engine", "ejs");
```

> 将views内的Jade文件修改为ejs文件，请注意：Jade 和 EJS 的语法差异很大，格式完全不同，请重点关注。

###### 解决跨域

- cors解决浏览器跨域请求问题
- cors允许前端应用从不同域名访问你的 API

```bash
PS C:\Users\Administrator\Desktop\01-stuProjects> npm i cors
npm warn deprecated transformers@2.1.0: Deprecated, use jstransformer
npm warn deprecated constantinople@3.0.2: Please update to at least constantinople 3.1.1
npm warn deprecated jade@1.11.0: Jade has been renamed to pug, please install the latest version of pug instead of jade

added 58 packages, removed 23 packages, and changed 30 packages in 3s

2 packages are looking for funding
  run `npm fund` for details
PS C:\Users\Administrator\Desktop\01-stuProjects> 
```

在app.js中使用cors

```js
...
var express = require("express");
const cors = require("cors");
...
//全域开启跨域
app.use(cors());
...
```

###### 自动构建

nodemon包适用于node.js环境下修改代码自动更新，无需手动再次启动服务

```js
PS C:\Users\Administrator\Desktop\01-stuProjects> npm i nodemon

added 28 packages in 2s

7 packages are looking for funding
  run `npm fund` for details
PS C:\Users\Administrator\Desktop\01-stuProjects> 
```

###### 变量加载

dotenv 是一个 Node.js 的 npm 包，它的唯一作用就是：把 .env 文件里的变量加载到 process.env 对象中，每个后端服务器都有自己的环境配置等信息，可以使用dotenv包进行管理和加载。

安装 dotenv非常简单，按照以下步骤操作即可。

```cmd
PS C:\Users\Administrator\Desktop\01-stuProjects> npm i dotenv

added 1 package in 1s

8 packages are looking for funding
  run `npm fund` for details
PS C:\Users\Administrator\Desktop\01-stuProjects> 
```

> 安装好后，就可以通过创建.env文件，并在www或其他服务文件下导入即可使用，具体参考增强方案中的环境变量章节;
>
> dotenv 默认不支持变量引用，若想使用变量引用，需要安装变量增强工具包
>
> > SERVER_IP=http://${LOCAL_IP}:${PORT}
> >
> > LOCAL_IP=192.168.10.148
> >
> > process.env.SERVER_IP      // "http://${LOCAL_IP}:${PORT}"  (字面量，不会解析)

###### 变量增强

dotenv 默认不支持变量引用，若想使用变量引用，需要安装变量增强工具包dotenv-expand，具体安装方式如下：

```bash
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i dotenv dotenv-expand      

added 1 package in 1s

10 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT>
```

> * 使用方法
>
> >     const dotenv = require("dotenv");
> >     const dotenvExpand = require("dotenv-expand");
> >     const myEnv = dotenv.config();
> >     dotenvExpand.expand(myEnv);
> >
>
> * 实现效果
>
> > SERVER_IP=http://${LOCAL_IP}:${PORT}
> >
> > LOCAL_IP=192.168.10.148
> >
> > process.env.MONGODB_DBHOST // "192.168.10.148:1234"             ✅ 正确解析

###### 数据库包

该项目统一使用MongoDB进行数据管理，需要使用mongoose包进行管理，安装方法如下：

```cmd
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i mongoose

added 18 packages in 3s

9 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> 
```

###### 加密认证

该项目由于存在的登录数据加密需求，统一使用bcrypt包进行加密和验证，当前采用纯 JavaScript，无需编译的js文件方式，相比bcrypt 稍慢（约 30%）,安装方法如下：

```cmd
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i bcryptjs

added 1 package in 1s

9 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm list bcrypt js
stu_projects_manager_tool@0.0.0 F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT
└── (empty)
```

> 实际生产环境，可考虑bcrypt 方式，具体查询相关资料。

###### 优化代码

将路由中的users删除，因不需要，将源文件删除后，修改app.js文件，请注意，目前路由设定是/api。

```js
var createError = require("http-errors");
var express = require("express");
const cors = require("cors");
var path = require("path");
var cookieParser = require("cookie-parser");
var logger = require("morgan");

var indexRouter = require("./routes/index");
// var usersRouter = require("./routes/users");

var app = express();
app.use(cors());

// view engine setup
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "jade");

app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

app.use("/api", indexRouter);
// app.use("/users", usersRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render("error");
});

module.exports = app;

```

##### 项目上线

###### 创建项目

- 通过如下命令创建项目文件夹（需要已安装generator工具）

```cmd
express -e 01-stuTools
```

###### 安装依赖

- 进入项目文件夹，通过如下命令安装依赖

```cmd
npm i
```

###### 自动构建

- 修改package.json,实现修改后自动重新服务

```json
"start": "node ./bin/www"
修改为：
"start": "nodemon ./bin/www"
```

> npm start
> 客户端打开http://服务器IP地址:开放端口号

###### 上线服务

* 重新设计端口号，与其他服务不同即可，修改www文件如下所示。

```js
//电脑设置参考Coding Note.md
...
/**
   * Get port from environment and store in Express.
   * 原来是：var port = normalizePort(process.env.PORT || "3000");
   * 现在是：var port = normalizePort(process.env.PORT || "1234");
   */

  var port = normalizePort(process.env.PORT || "1234");

  app.set("port", port);

  /**
   * Create HTTP server.
   */

  var server = http.createServer(app);

  /**
   * Listen on provided port, on all network interfaces.
   */

  /**
   * 原来为server.listen(port)，现更改为server.listen(port,'0.0.0.0').
   */
  server.listen(port, "0.0.0.0");
  server.on("error", onError);
  server.on("listening", onListening);
...
```

> 查询服务器IP地址方法：
>
> > - 按 Win + R，输入 cmd 打开命令提示符
> > - 输入命令：ipconfig
> > - 找到 IPv4 地址，通常是 192.168.x.x 格式，例如192.168.10.148
>
> > 防火墙设置端口方法：
>
> - 打开"控制面板" → "Windows Defender 防火墙"
> - 点击"高级设置"
> - 点击"入站规则" → "新建规则"
> - 选择"端口" → 下一步
> - 选择"TCP"，特定本地端口输入 1234 → 下一步
> - 选择"允许连接" → 下一步
> - 勾选"域"、"专用"、"公用" → 下一步
> - 输入规则名称（如"Node.js 1234"）→ 完成

截止到目前，通过npm start命令，项目可以通过IP+Port方式访问，整体架构已经搭建成功

##### 增强方案

增强方案均是针对bin/www文件执行的。

###### 优雅关闭

在服务关闭的时候，提示是何种关闭事件及对应的处理

```js
function onListening() {
  var addr = server.address();
  var bind = typeof addr === "string" ? "pipe " + addr : "port " + addr.port;
  debug("Listening on " + bind);
  // 新增：优雅关闭处理
  setupGracefulShutdown(server);
}
/**
 * 优雅关闭服务器
 */
function setupGracefulShutdown(server) {
  const signals = {
    SIGINT: "Terminal Interruption (Ctrl+C)",
    SIGTERM: "Termination Signal",
    SIGQUIT: "Exit Signal",
  };

  Object.keys(signals).forEach((signal) => {
    process.on(signal, () => {
      console.log(
        `\n ⚠️ ShutdownMsg:Get ${signals[signal]}, Shutting Down the Server...`,
      );

      // 停止接收新请求
      server.close(() => {
        console.log("\n ⚠️ ShutdownMsg:The HTTP Server Has Been Shut Down.");

        // 关闭数据库连接
        /* if (typeof db.close === "function") {
          db.close(() => {
            console.log("\n ⚠️ ShutdownMsg:The Database Connection Has Been Closed.");
            process.exit(0);
          });
        } else {
          process.exit(0);
        } */
      });

      // 设置超时，强制退出
      setTimeout(() => {
        console.error("\n ⚠️ ShutdownMsg:Close timeout, Force Exit");
        process.exit(1);
      }, 10000);

      // 拒绝新连接
      server.on("close", () => {
        console.log("\n ⚠️ ShutdownMsg:All Connections Have Been Closed.");
      });
    });
  });
}
```

###### 调试信息

创建调试及提示信息打印到窗口，此时api/health还没有创建，会在健康检查中创建

```js
function onListening() {
  var addr = server.address();
  var bind = typeof addr === "string" ? "pipe " + addr : "port " + addr.port;
  debug("Listening on " + bind);
  // 新增：优雅关闭处理
  setupGracefulShutdown(server);
  //新增：调试及提示窗口
  debugMsg(addr);
}

//...setupGracefulShutdown(){...}

/**
 * 调试及提示信息
 */
function debugMsg(addr) {
  // 使用彩色日志
  const colors = {
    reset: "\x1b[0m",
    green: "\x1b[32m",
    blue: "\x1b[34m",
    yellow: "\x1b[33m",
    red: "\x1b[31m",
    cyan: "\x1b[36m",
  };

  console.log("\n" + "=".repeat(50));
  console.log(`${colors.green}🚀 Server Startup Successful!${colors.reset}`);
  console.log("=".repeat(50));

  console.log(
    `${colors.blue}📡 Environment: ${colors.reset}${process.env.NODE_ENV || "development"}`,
  );
  console.log(`${colors.blue}📡 Ports: ${colors.reset}${addr.port}`);
  console.log(`${colors.blue}📡 Process ID: ${colors.reset}${process.pid}`);

  console.log(`\n${colors.cyan}📍 Access Address:${colors.reset}`);
  console.log(
    `   • Local Address:    ${colors.yellow}http://localhost:${addr.port}/api${colors.reset}`,
  );
  console.log(
    `   • Local IP:    ${colors.yellow}http://127.0.0.1:${addr.port}/api${colors.reset}`,
  );

  // 获取局域网 IP
  const os = require("os");
  const interfaces = os.networkInterfaces();
  let hasExternalIP = false;

  console.log(`\n${colors.cyan}🌐 LAN Access:${colors.reset}`);
  Object.keys(interfaces).forEach((interface) => {
    interfaces[interface].forEach((info) => {
      if (info.family === "IPv4" && !info.internal) {
        console.log(
          `   • ${colors.green}http://${info.address}:${addr.port}/api${colors.reset}`,
        );
        hasExternalIP = true;
      }
    });
  });

  if (!hasExternalIP) {
    console.log(
      `   ${colors.red}⚠️No External Network Interface Detected${colors.reset}`,
    );
  }

  console.log(`\n${colors.cyan}📚 API Endpoint:${colors.reset}`);
  console.log(
    `   • ${colors.yellow}http://localhost:${addr.port}/api${colors.reset}`,
  );
  console.log(
    `   • ${colors.yellow}http://localhost:${addr.port}/api/health${colors.reset}`,
  );

  console.log("\n" + "=".repeat(50));
  console.log(
    `${colors.blue}⏰ Start Time: ${colors.reset}${new Date().toLocaleString("zh-CN")}`,
  );
  console.log("=".repeat(50) + "\n");
}
```

###### 请求超时

添加请求超时配置，防止请求挂起。

```js
/**
 * Create HTTP server.
 */

var server = http.createServer(app);

// 添加请求超时配置，防止请求挂起
serverSetTimeOut();

/**
 * Listen on provided port, on all network interfaces.
 */

server.listen(port, "0.0.0.0");

...

/**
 * 新增，添加请求超时配置，防止请求挂起
 */
function serverSetTimeOut() {
  server.setTimeout(120000); // 120秒
  server.keepAliveTimeout = 65000; // 65秒
  server.headersTimeout = 66000; // 66秒
}

```

###### 错误日志

添加错误日志增强方案。

```js
/**
 * 新增优化：服务器错误增强.
 */

function onError(error) {
  if (error.syscall !== "listen") {
    console.error("❌ 服务器错误:", error);
    throw error;
  }

  const bind = typeof port === "string" ? "Pipe " + port : "Port " + port;
  const colors = {
    red: "\x1b[31m",
    reset: "\x1b[0m",
  };

  switch (error.code) {
    case "EACCES":
      console.error(`${colors.red}${bind} 需要管理员权限${colors.reset}`);
      console.error("💡 解决方法: 使用 sudo 运行或更换端口");
      process.exit(1);
      break;
    case "EADDRINUSE":
      console.error(`${colors.red}${bind} 端口已被占用${colors.reset}`);
      console.error("💡 解决方法:");
      console.error(
        "   1. 查找占用进程: lsof -i :1234 (macOS/Linux) 或 netstat -ano | findstr :1234 (Windows)",
      );
      console.error("   2. 杀死进程: kill -9 <PID> 或 taskkill /PID <PID> /F");
      console.error("   3. 或者修改端口号");
      process.exit(1);
      break;
    case "EADDRNOTAVAIL":
      console.error(`${colors.red}${bind} 地址不可用${colors.reset}`);
      process.exit(1);
      break;
    default:
      console.error(`${colors.red}未知错误: ${error.message}${colors.reset}`);
      throw error;
  }
}
```

###### 健康检查

在根目录下创建controllers/health.js，用于服务器的健康检查服务,处理http请求和响应。

```js
/**
 * 健康检查
 * 处理 HTTP 请求和响应
 * 其为类组件，通过导出new healthController()确保外部直接使用其内部方法
 */
class healthController {
  async healthCheck(req, res, next) {
    res.json({
      status: "ok",
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || "development",
      version: require("../package.json").version,
      memory: {
        rss: Math.round(process.memoryUsage().rss / 1024 / 1024) + " MB",
        heapTotal:
          Math.round(process.memoryUsage().heapTotal / 1024 / 1024) + " MB",
        heapUsed:
          Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + " MB",
      },
    });
  }
}
module.exports = new healthController();

```

直接在app.js中创建路由。

```js
...
var indexRouter = require("./routes/index");
const healthController = require("./controllers/healthController");
...
app.use("/api", indexRouter);

//新增健康检查端点
app.get("/api/health", healthController.healthCheck);
...
```

###### 环境变量

在已经安装了dotenv包之后，在www中添加环境变量加载，用于服务器配置，数据库配置，JWT 配置和其他配置

* 在项目的根目录下，创建.env文件

  ```env
  # ============================================
  # 服务器配置
  # process.env.LISTEN_AREA: 用于设定是否在本地使用还是局域网内使用
  # ============================================
  PORT=1234
  LISTEN_AREA=0.0.0.0
  NODE_ENV=development
  ```
  
* 在项目的根目录下，创建.env.example文件，用于版本控制

  ```env
  # ============================================
  # 服务器配置
  # ============================================
  PORT=XXXX
  NODE_ENV=development
  
  # ============================================
  # 数据库配置
  # ============================================
  MONGODB_URI=mongodb://localhost:XXXX/mydb
  MONGODB_USER=
  MONGODB_PASSWORD=
  MONGODB_POOL_SIZE=10
  MONGODB_TIMEOUT=5000
  EXIT_ON_DB_ERROR=true
  
  # ============================================
  # JWT 配置
  # ============================================
  JWT_SECRET=change-this-to-a-random-string
  JWT_REFRESH_SECRET=change-this-to-another-random-string
  JWT_EXPIRES_IN=24h
  
  # ============================================
  # API 配置
  # ============================================
  API_PREFIX=/api
  
  # ============================================
  # 文件上传配置
  # ============================================
  UPLOAD_DIR=./uploads
  MAX_FILE_SIZE=10485760
  
  # ============================================
  # CORS 配置
  # ============================================
  CORS_ORIGINS=["http://localhost:3000"]
  ```

  > .env          # ❌ 不应该提交到 Git（包含真实敏感信息）
  >
  > .env.example  # ✅ 应该提交到 Git（只包含示例，不含真实数据）

* 在www中加载.env文件

  ```js
  /**
   * 新增，加载 .env 文件
   * 所有 .env 文件中的变量都会被加载到 process.env 对象中
   */
  require("dotenv").config();
  ...
  /**
   * Get port from environment and store in Express.
   * 直接使用.env内的PORT端口和监听区域
   */
  
  var port = normalizePort(process.env.PORT || "1234");
  const listenArea = process.env.LISTEN_AREA || "0.0.0.0";
  ...
  /**
   * Listen on provided port, on all network interfaces.
   * listenArea：用于设定是否在本地使用还是局域网内使用
   */
  
  server.listen(port, listenArea);
  ```
  
  > 此种方法是采用了普通版dotenv方案，无法加载变量引用，若使用变量引用可采用增强版dotenv-expand，具体参考地址更新-变量增强

#### 架构搭建

##### 静态资源

###### 网站图标

将favicon.png文件存放在public文件夹根目录

```文本
01-stuProjectsMT
|--public
     |----favicon.png    在静态页面内引入该文件，实现网站logo效果
```

###### 登录页面

将静态登录页面的html，js，css文件分别存在如下路径：

```文本
01-stuProjectsMT
|--public
     |----javascripts    存放静态页面的js文件
     |----stylesheets    存放静态页面的css文件
|--views                 存放login.ejs、projectManager.ejs文件
     |----projects       存放单独项目文件夹
```

login.ejs文件：

```ejs
<head>
    <link rel="shortcut icon" href="/favicon.png" type="image/x-icon" />
    <link rel="stylesheet" href="/stylesheets/login.css" />
</head>
<body>
    <script src="/javascripts/login.js"></script>
</body>
```

> * 因在app.js中设定了静态资源库为public，所以，此处的ejs文件虽然在views文件夹下但是仍然是public路径
>
> * 因express和模板引擎的额特殊性，不要使用相对路径，需要使用绝对路径：/stylesheets/login.css

index.js文件：

```js
var express = require("express");
var router = express.Router();

//公开路由（不需要认证） -- 登录页面
router.get("/", function (req, res, next) {
  res.render("login");
});

module.exports = router;
```

截止到目前，可以通过重点提示地址访问到登录界面了。

##### 数据结构

该项目使用MongoDB数据库，在已经安装了mongoose包。

###### 用户数据

在vs code插件MONGODB中执行如下程序，创建数据库：stuTools，集合：Users

```js
const database = 'stuTools';
const collection = 'users';

// Create a new database.
use(database);

// Create a new collection.
db.createCollection(collection);
```

设计数据结构对象，设置集合中文档的属性以及属性值的类型。

```js
username: {
    type: String,
    required: [true, "用户名不能为空"],
    unique: true,
    trim: true,
    minlength: [3, "用户名至少3个字符"],
    maxlength: [30, "用户名最多30个字符"],
  },
  password: {
    type: String,
    required: [true, "密码不能为空"],
    minlength: [6, "密码至少6个字符"],
    select: false, // 默认不返回密码字段
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  createdAt: {
    type: Date,
    default: new Date(),
  },
  rememberMe: {
    type: Boolean,
    require: false,
  },
```

###### 配置文件

该项目统一使用dotenv包对配置文件进行解析操作，弃用MongoDB自身配置包文件，将项目根目录下的.env文件增加：

```env
# ============================================
# 数据库配置
# ============================================
MONGODB_DBHOST=192.168.10.148
MONGODB_DBPORT=27017
MONGODB_DBNAME=stuTools
MONGODB_USER=
MONGODB_PASSWORD=
MONGODB_POOL_SIZE=10
MONGODB_TIMEOUT=5000
EXIT_ON_DB_ERROR=true
```

在MongoDB/db文件夹下修改db.js文件如下：

```js
module.exports = function (success, error) {
    ...
  // 2.引入mongoose
  const mongoose = require("mongoose");

  // 3. 通过dotenv包导入配置文件，.env 文件中的变量都会被加载到 process.env 对象中
  require("dotenv").config();

  // 4.连接mongodb数据库，通体采用dotenv配置方案，所有配置项均放入项目根目录.env文件内
  mongoose.connect(
    `mongodb://${process.env.MONGODB_DBHOST}:${process.env.MONGODB_DBPORT}/${process.env.MONGODB_DBNAME}`,
  );
```

###### 引入数据

在bin/www下引入对应标准数据库模块js文件：

```js
//导入db文件
const db = require("../mongodb/db/db.js");

//将要运行的函数通过参数传递给db(success,err){...}中的success
db(() => {
    .原始的代码.
})
```

##### 加密方案

数据加密是在MongoDB的数据模型中，使用bcrypt加密方式实现，具体加密、验证方式如下所示流程完成。

###### 引入加密

后端需要加密验证的数据需要在数据库内部完成，即MongoDB的model内方法实现，通过引入model并调用实现。

model.js内实现如下：

```js
// 1.1 创建Schema(模式)对象,并非是必须的，只是为了方便，./db是需要根据连接js文件名决定的，引入当前目录下的 db.js 文件
// 1.2 bcrypt是加密模块，目前使用bcryptjs模块
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
```

###### 数据加密

model.js内实现如下：

```js
/*  3. 对发过来的数据进行加密处理
 *  概念：Mongoose 中间件（Middleware）概念
 *  中间件：也叫"钩子"（hooks），是在特定操作之前或之后自动执行的函数
 *    pre：表示"之前"执行（前置钩子）
 *    save：表示在文档保存到数据库之前触发
 *  */
usersSchema.pre("save", async function () {
  /* // 如果有修改密码的业务，执行此代码目的是，如果没有修改密码，跳过加密
  if (!this.isModified("password")) {
    //next()：告诉 Mongoose "中间件执行完毕，继续下一步"
    return next();
  } */
  try {
    // 生成盐（10 是默认的加密强度）
    const salt = await bcrypt.genSalt(10);

    // 加密密码
    this.password = await bcrypt.hash(this.password, salt);
  } catch (error) {
    throw error;
  }
});
```

> 基本使用方法：
>
> ​	数据库在存储前，均通过生产盐实现数据加密，即：数据库内保存的就是加密之后的数据

###### 数据比较

model.js内实现如下：

```js
// 4. 密码比较方法
usersSchema.methods.comparePassword = async function (candidatePassword) {
  try {
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (error) {
    throw new Error("密码比较失败");
  }
};
```

> 基本使用方式如下：
>
> ```js
> const User = require("../MongoDB/models/model.js");
>   // 查找用户
>   const user = await User.findOne({ username }).select("+password");
>   // 验证密码
>   const isPasswordMatch = await user.comparePassword(password);
>   console.log("验证密码结果：", isPasswordMatch);
>   if (!isPasswordMatch) {
>     throw new Error("验证密码错误，用户名或密码错误");
>   }
> ```

###### 身份认证

因为后续身份认证基本是每个页面首次要做的，所以，提前将认证功能做了拆分，核心实现代码就是数据比较模块实现：

```文本
project/
├── controllers/
│   └── authController.js         # 处理 HTTP 层逻辑，处理请求和响应
├── services/
│   └── authService.js            # 业务逻辑层，提供认证结果
├── routes/
│   └── index.js                 # 路由定义
├── MongoDB/models/
│   └── model.js                 # 数据模型
|
└── app.js                      # 应用入口
```

处理 HTTP 层逻辑，处理请求和响应的controllers/authController.js文件如下：

```js
class AuthController {
  /**
   * 登录
   */
  async login(req, res, next) {
    try {
      const { username, password } = req.body;
      // 调用服务层
      const authData = await authService.login({ username, password });
      console.log("密码验证成功，返回的数据为：", authData);
      res.json({
        success: true,
        message: "登录成功",
        data: authData,
      });
    } catch (error) {
      // 统一错误处理
      if (error.message.includes("不能为空")) {
        return res.status(400).json({
          success: false,
          message: error.message,
        });
      }

      if (error.message.includes("错误") || error.message.includes("禁用")) {
        return res.status(401).json({
          success: false,
          message: error.message,
        });
      }

      next(error);
    }
  }
}

module.exports = new AuthController();
```

业务逻辑层，提供认证结果的services/authService.js文件如下：

```js
const User = require("../MongoDB/models/model.js");

/**
 * 认证服务
 * 负责业务逻辑，不关心 HTTP 请求/响应
 */
class AuthService {
  /**
   * 用户登录认证
   * @param {Object} credentials - { username, password }
   * @returns {Object} 认证结果
   */
  async login(credentials) {
    const { username, password } = credentials;

    // 验证输入
    if (!username || !password) {
      throw new Error("用户名和密码不能为空");
    }

    // 查找用户
    const user = await User.findOne({ username }).select("+password");

    if (!user) {
      throw new Error("查找用户错误，用户名或密码错误");
    }

    // 检查激活状态
    if (!user.isActive) {
      throw new Error("账户已被禁用，请联系管理员");
    }

    // 验证密码
    const isPasswordMatch = await user.comparePassword(password);
    console.log("验证密码结果：", isPasswordMatch);

    if (!isPasswordMatch) {
      throw new Error("验证密码错误，用户名或密码错误");
    }

    /* // 生成 Token，暂时不使用，后续使用
    const accessToken = user.generateAuthToken();
    const refreshToken = user.generateRefreshToken(); 
    return {
      user: {
        id: user._id,
        username: user.username,
        isActive: user.isActive,
      },
      accessToken,
      refreshToken,
    };
    */

    return {
      id: user._id,
      username: user.username,
      isActive: user.isActive,
    };
  }
}

module.exports = new AuthService();
```

业务逻辑和请求和相应模块均已完成的情况下，在routes/index.js中引入模块并做路由响应

```js
var express = require("express");
var router = express.Router();
//引入认证请求和响应组件
const authController = require("../controllers/authController");

//公开路由（不需要认证） -- 登录页面
router.get("/", function (req, res, next) {
  res.render("login");
});

//验证路由 --登录数据验证
router.post("/login", authController.login);
module.exports = router;
```

##### 创建数据

本案例暂时不做注册和修改密码等功能模块，但是需要对密码进行加密，所以，数据库中的数据需要在加密模块完成后，单独进行创建。本单元通过dbmain.js文件进行演示实现数据的生成过程。

在MongoDB文件夹下，对dbmain.js对如下修改，实现对数据的创建:

```js
/**
 * JSDoc（JavaScript Documentation） 注释语法
 * 将dbmain.js作为一个函数，在app/main程序使用的时候调用
 */
//导入db文件
const db = require("./db/db.js");
//导入c增d删u改r查文件
const dbCreate = require("./crdu/create.js");
const dbDeleteOne = require("./crdu/deleteOne.js");
const dbReadAll = require("./crdu/readAll.js");
const dbReadOne = require("./crdu/readOne.js");
const dbUpdateOne = require("./crdu/updateOne.js");

//调用db函数,第1个()=>{}表示success回调函数，第2个()=>{}表示error回调函数
db(
  //调用如下函数，说明数据库连接成功
  async () => {
    //create 调用数据库创建api
    {
      try {
        const dataObject = [
          {
            username: "admin",
            password: "admin123",
            isActive: true,
            createdAt: new Date(),
            rememberMe: false,
          },
          {
            username: "engineer",
            password: "engineer123",
            isActive: true,
            createdAt: new Date(),
            rememberMe: false,
          },
          {
            username: "operator",
            password: "operator123",
            isActive: true,
            createdAt: new Date(),
            rememberMe: false,
          },
        ];
        console.log("📝 正在创建测试用户...");
        await dbCreate(dataObject);
        console.log("✅ 用户创建成功！");
      } catch (error) {
        if (error.code === 11000) {
          console.log("⚠️  用户已存在，跳过创建");
        } else {
          console.error("❌ 创建用户失败:", error.message);
        }
      }
    }
  },
);

//第01步：安装依赖
// npm install mongoose

//第02步：运行程序
// node dbmain.js

```

> 已经生成如下数据(MongoDB/sutTools/users/Documents)：
>
> ```json
> {
> _id: ObjectId('6a2b9942a769d34e6a5b97f6'),
> username: 'admin',
> password: '$2b$10$4.z2i2quV24puBvZLPs3lOeBLEPNoQXC/GBxUKAhafxzCOWa9vD2e',
> isActive: true,
> rememberMe: false,
> createdAt: ISODate('2026-06-12T05:29:38.771Z'),
> __v: NumberInt('0')
> }
> {
> _id: ObjectId('6a2b9942a769d34e6a5b97f6'),
> username: 'admin',
> password: '$2b$10$4.z2i2quV24puBvZLPs3lOeBLEPNoQXC/GBxUKAhafxzCOWa9vD2e',
> isActive: true,
> rememberMe: false,
> createdAt: ISODate('2026-06-12T05:29:38.771Z'),
> __v: NumberInt('0')
> }
> {
> _id: ObjectId('6a2b9942a769d34e6a5b97f6'),
> username: 'admin',
> password: '$2b$10$4.z2i2quV24puBvZLPs3lOeBLEPNoQXC/GBxUKAhafxzCOWa9vD2e',
> isActive: true,
> rememberMe: false,
> createdAt: ISODate('2026-06-12T05:29:38.771Z'),
> __v: NumberInt('0')
> }
> ```

#### 地址更新

截止到目前，使用到服务器ip地址的业务流程有：

* 局域网内人员访问系统（因为采用模板引擎方式，所以实际就是访问后端数据库进行前端代码的请求动作）
* 前端向后端请求数据服务器地址
* 后端服务器与数据库连接请求
* 数据库应用程序与数据库之间通讯

当前的方式是采用写死的方式实现，当局域网内IP地址发生变更后，服务器彻底无法使用，需要手动进行更改，现对此问题进行优化修复。

##### 先导执行

将package.json内添加先导执行程序，确保在程序执行前进行IP地址的获取与写入。

```js
  "scripts": {
    "setup": "node ./bin/setup-env.js",
    "start": "npm run setup && nodemon ./bin/www",
    "prod": "npm run setup && NODE_ENV=production node ./bin/www"
  },
```

> "setup"，不可以使用nodemon，因为如果nodemon，就会存在死循环（更新.env，nodemon检查到文件变化，重启...）
>
> "start"，先npm执行setup一次，再nodemon主文件
>
> 实际生产中不建议使用nodemon，所以增加了prod命令

##### 环境变量

优化环境变量格式如下：

````env
# ============================================
# 服务器配置
# process.env.LISTEN_AREA: 用于设定是否在本地使用还是局域网内使用
# ============================================
PORT=1234
LISTEN_AREA=0.0.0.0
NODE_ENV=development
SERVER_IP=http://${LOCAL_IP}:${PORT}

# ============================================
# 局域网IP
# 自动获取的局域网IP（由 setup-env.js 自动更新）
# ============================================
LOCAL_IP=192.168.10.148

# ============================================
# 数据库配置
# ============================================
MONGODB_DBHOST=${LOCAL_IP}
MONGODB_DBPORT=27017
MONGODB_DBNAME=stuTools
MONGODB_USER=
MONGODB_PASSWORD=
MONGODB_POOL_SIZE=10
MONGODB_TIMEOUT=5000
EXIT_ON_DB_ERROR=true

# ============================================
# JWT 配置
# ============================================
JWT_SECRET=your-super-secret-key-change-this-in-production
JWT_REFRESH_SECRET=your-refresh-secret-key-change-this-too
JWT_EXPIRES_IN=24h

# ============================================
# API 配置
# ============================================
API_PREFIX=/api

# ============================================
# 文件上传配置
# ============================================
UPLOAD_DIR=./uploads
MAX_FILE_SIZE=10485760  # 10MB

# ============================================
# CORS 配置
# ============================================
CORS_ORIGINS=["http://localhost:3000","http://localhost:8080"]
````

> .env文件使用了变量引用，所以需要dotenv-expand配合使用

##### 先导文件

创建setup-env.js文件

```js
#!/usr/bin/env node
/**
 * 启动前配置脚本
 * 1. 获取局域网IP
 * 2. 读取现有的 .env 文件
 * 3. 更新或添加 LOCAL_IP 环境变量
 */

const fs = require("fs");
const path = require("path");
const os = require("os");
// 主函数
function setupEnv() {
  console.log("🔧 开始配置环境变量...");

  // 获取局域网IP
  const localIP = getLocalIP();
  console.log(`🌐 检测到局域网IP: ${localIP}`);

  // 读取现有 .env 文件
  const envContent = readEnvFile();

  // 更新 LOCAL_IP 环境变量
  const updatedContent = updateEnvContent(envContent, "LOCAL_IP", localIP);

  // 写入 .env 文件
  writeEnvFile(updatedContent);

  console.log("✅ 环境变量配置完成！");
  console.log(`💡 LOCAL_IP = ${localIP}`);
}

// 获取局域网IP地址
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  let localIP = "127.0.0.1";

  Object.keys(interfaces).forEach((interfaceName) => {
    interfaces[interfaceName].forEach((info) => {
      // 只获取IPv4且非内部（非127.0.0.1）的IP
      if (info.family === "IPv4" && !info.internal) {
        localIP = info.address;
      }
    });
  });

  return localIP;
}

// 读取 .env 文件内容
function readEnvFile() {
  const envPath = path.join(__dirname, "../.env");
  //不使用try/catch方式，如果读取不到.env文件直接报错，不再继续执行下去
  return fs.readFileSync(envPath, "utf8");
}

// 更新或添加环境变量
function updateEnvContent(content, key, value) {
  const lines = content.split("\n");
  const keyPattern = new RegExp(`^${key}=`);
  let found = false;
  let updatedLines = [];

  lines.forEach((line) => {
    if (line.trim().startsWith("#") || line.trim() === "") {
      updatedLines.push(line);
      return;
    }

    if (keyPattern.test(line)) {
      updatedLines.push(`${key}=${value}`);
      found = true;
    } else {
      updatedLines.push(line);
    }
  });

  if (!found) {
    updatedLines.push(`${key}=${value}`);
  }

  return updatedLines.join("\n");
}

// 写入 .env 文件
function writeEnvFile(content) {
  const envPath = path.join(__dirname, "../.env");
  fs.writeFileSync(envPath, content, "utf8");
  console.log(`✅ .env 文件已更新: ${envPath}`);
}

// 执行配置
setupEnv();
```

##### 变量增强

修改www文件内的dotenv的引用方式，增加dotenv-expend的使用，可以解析env内变量引用困扰。

```js
db(() => {
  /**
   * 新增，加载 .env 文件
   * 所有 .env 文件中的变量都会被加载到 process.env 对象中
   * 新增：加载 .env 文件并支持变量引用
   */
  const dotenv = require("dotenv");
  const dotenvExpand = require("dotenv-expand");
  const myEnv = dotenv.config();
  dotenvExpand.expand(myEnv);
  ...
```

修改MongDB/db/db.js文件内的dotenv的引用方式，增加dotenv-expend的使用，可以解析env内变量引用困扰。

```js
  // 2.引入mongoose
  const mongoose = require("mongoose");

  // 3. 通过dotenv包导入配置文件，.env 文件中的变量都会被加载到 process.env 对象中,新增加载 .env 文件并支持变量引用
  const dotenv = require("dotenv");
  const dotenvExpand = require("dotenv-expand");
  const myEnv = dotenv.config();
  dotenvExpand.expand(myEnv);
...
```

修改www文件的调试及提示信息内容

```js
/**
   * 新增，调试及提示信息
   */
  function debugMsg(addr) {
    // 使用彩色日志
    const colors = {
      reset: "\x1b[0m",
      green: "\x1b[32m",
      blue: "\x1b[34m",
      yellow: "\x1b[33m",
      red: "\x1b[31m",
      cyan: "\x1b[36m",
    };
    console.log("\n" + "=".repeat(50));
    console.log(`${colors.green}🚀 Server Startup Successful!${colors.reset}`);
    console.log("=".repeat(50));

    console.log(
      `${colors.blue}📡 Environment: ${colors.reset}${process.env.NODE_ENV || "development"}`,
    );
    console.log(`${colors.blue}📡 Ports: ${colors.reset}${addr.port}`);
    console.log(`${colors.blue}📡 Process ID: ${colors.reset}${process.pid}`);
    console.log(`${colors.blue}📡 SERVER IP: ${process.env.LOCAL_IP}`);

    console.log(`\n${colors.cyan}📍 Access Address:${colors.reset}`);
    console.log(
      `   • Local Address:    ${colors.yellow}http://localhost:${addr.port}/api${colors.reset}`,
    );
    console.log(
      `   • Local IP:    ${colors.yellow}${process.env.SERVER_IP}/api${colors.reset}`,
    );
  }
```

> 以上，后端通过变量增强，可以将后端服务器、数据库都进行了自动获取模式，但是前端若采用js方式，无法自动获取，一般会在后端开设一个端口路由，用于前端获取服务器地址，后端返回的数据就是从env文件中获取的。

##### 前端获取

前端获取后端服务器地址和端口一般采用发送请求，后端响应的模式执行，具体实现如下：

###### 后端路由

```js
/**
 * 新增，加载 .env 文件
 * 所有 .env 文件中的变量都会被加载到 process.env 对象中
 * 新增：加载 .env 文件并支持变量引用
 */
const dotenv = require("dotenv");
const dotenvExpand = require("dotenv-expand");
const myEnv = dotenv.config();
dotenvExpand.expand(myEnv);

//公开路由（不需要认证） -- 后端对应服务器地址的响应
router.get("/server-info", (req, res) => {
  res.json({
    localIP: process.env.LOCAL_IP,
    port: process.env.PORT,
    timestamp: Date.now(),
  });
});
```

###### 前端请求

login.js文件中新建一个请求函数，用于公共请求：

```js
//向后端获取服务器地址的实现
async function getServerInfo() {
  try {
    const response = await fetch("/api/server-info");

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("❌ 获取服务器信息失败:", error.message);
    throw error;
  }
}
```

在新打开网页和请求登录时，调用此公共请求函数。

```js
// 表单提交
loginForm.addEventListener("submit", async function (e) {
  e.preventDefault();
  try {
    // 获取后端返回的服务器地址
    const serverInfo = await getServerInfo();

    const response = await fetch(
      `http://${serverInfo.localIP}:${serverInfo.port}/api/login`,
...
    
// 页面加载时,检查是否已登录
window.addEventListener("load", function () {
    // 检查服务器连接
  checkServerConnection();
...
    
// 检查服务器连接
async function checkServerConnection() {
  //使用heartbeat模块,心跳检查一直执行，不启用关闭功能
  {
    // 获取后端返回的服务器地址
    const serverInfo = await getServerInfo();

    createHttpHeartbeat({
      url: `http://${serverInfo.localIP}:${serverInfo.port}/api/heartbeat`,
...
```





#### 项目管理

在login.ejs完成业务流程后，将对projectManager.ejs进行业务梳理。

##### 添加跳转

在login.ejs中添加对应跳转业务流：

```js
// 表单提交
loginForm.addEventListener("submit", async function (e) {
    ...
    if (response.ok) {
      showAlert("登录成功，正在跳转...", "success");
      ...
      // 延迟跳转，让用户看到成功提示
      setTimeout(() => {
        // 跳转到项目管理页面
        window.location.href = "/api/projectManager";
      }, 500);
      ...
}
```

##### 创建页面

在views下创建projectManager.ejs，对应项目管理的静态页面，其中css和js的引入需要重点关注：

```html
...
//使用绝对路径
<link rel="shortcut icon" href="/favicon.png" type="image/x-icon" />
    <link rel="stylesheet" href="/stylesheets/projectManager.css" />
...
<script type="module" src="/javascripts/projectManager.js"></script>
```





















### 前端设计

#### 模板搭建

该项目使用js实现前端控制，与后端服务器进行交互，显示页面全部通过后端的模板引擎实现，在此不再赘述ejs文件相关内容，具体对js文件实现的核心代码进行讲解与记录。

##### 连接检查

###### 启动检查

在login.js文件下实现：

```js
// 页面加载时,检查是否已登录
window.addEventListener("load", function () {
  // 检查是否已经登录
  if (
    localStorage.getItem("isLoggedIn") === "true" ||
    sessionStorage.getItem("isLoggedIn") === "true"
  ) {
    // 如果已经登录，直接跳转
    //window.location.href = "projects.html";
  }

  // 检查服务器连接
  checkServerConnection();
});

// 检查服务器连接
async function checkServerConnection() {
  try {
    const response = await fetch(`${baseURL}`, {
      method: "GET",
      timeout: 3000,
    });

    if (response.ok) {
      serverStatus.innerHTML =
        '<i class="fas fa-circle" style="color: #28a745; font-size: 0.6rem;"></i> Connection Successful';
    }
  } catch (error) {
    serverStatus.innerHTML =
      '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
  }
}
```

###### 通讯检查

在登录时，即表单提交时的数据检查与实现：

```js
// 表单提交
loginForm.addEventListener("submit", async function (e) {
  e.preventDefault();

  // 验证表单
  if (!validateForm()) {
    return;
  }

  // 显示加载状态
  loginBtn.classList.add("loading");
  loginBtn.disabled = true;

  // 获取表单数据
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();
  const rememberMe = document.getElementById("rememberMe").checked;

  // 准备发送的数据
  const loginData = {
    username: username,
    password: password,
    rememberMe: rememberMe,
  };

  try {
    // 发送登录请求到后端
    // 注意：这里需要根据你的后端API地址修改
    console.log(
      "后端的服务器地址端口为：",
      `${baseURL}/login`,
      "发送的数据为：",
      loginData,
    );

    const response = await fetch(`${baseURL}/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      //js对象转JSON字符串
      body: JSON.stringify(loginData),
    });

    // 解析响应
    const result = await response.json();
    console.log("服务器响应的数据为：", result);

    if (response.ok) {
      showAlert("登录成功，正在跳转...", "success");

      // 保存token（如果后端返回了）
      if (result.token) {
        localStorage.setItem("authToken", result.token);
      }

      // 保存用户信息（可选）
      if (result.user) {
        localStorage.setItem("userInfo", JSON.stringify(result.user));
      }

      // 如果勾选了记住我，保存到localStorage，否则保存到sessionStorage
      if (rememberMe) {
        localStorage.setItem("rememberMe", "true");
      } else {
        sessionStorage.setItem("isLoggedIn", "true");
      }

      // 延迟跳转，让用户看到成功提示
      setTimeout(() => {
        // 跳转到项目管理页面
        window.location.href = "/api/projects";
      }, 500);
    } else {
      // 登录失败
      const errorMessage = result.message || "登录失败，请检查用户名和密码";
      showAlert(errorMessage, "error");

      // 清空密码
      passwordInput.value = "";
    }
  } catch (error) {
    console.error("登录请求失败:", error);
    showAlert("网络错误，请检查服务器是否运行", "error");
    serverStatus.innerHTML =
      '<i class="fas fa-circle" style="color: #dc3545; font-size: 0.6rem;"></i> 服务器连接失败';
  } finally {
    // 恢复按钮状态
    loginBtn.classList.remove("loading");
    loginBtn.disabled = false;
  }
});
```

##### 后端端口

在login.js文件内定义服务器具体地址并使用：

```js
//后端接口地址
const baseURL = "http://192.168.10.148:1234/api";
//检查服务器地址时使用
  try {
    const response = await fetch(`${baseURL}`, {
      method: "GET",
      timeout: 3000,
    });

    if (response.ok) {
      serverStatus.innerHTML =
        '<i class="fas fa-circle" style="color: #28a745; font-size: 0.6rem;"></i> Connection Successful';
    }
  } catch (error) {
    serverStatus.innerHTML =
      '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
  }

//表单提交时使用
try {
    const response = await fetch(`${baseURL}/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      //js对象转JSON字符串
      body: JSON.stringify(loginData),
    });

    // 解析响应
    const result = await response.json();
```

#### 心跳检查

##### 标准模板

创建public/lib/heartbeat文件夹，创建http-heartbeat.js

```js
/**
 * HTTP 心跳检测模块
 * 使用方式：
 *   import { createHttpHeartbeat, updateServerStatus } from './http-heartbeat.js';
 */

/**
 * 创建 HTTP 心跳检测实例
 * @param {Object} options - 配置选项
 * @param {string} options.url - 心跳接口地址（必填）
 * @param {number} [options.interval=30000] - 心跳间隔（毫秒），默认 30 秒
 * @param {number} [options.timeout=10000] - 超时时间（毫秒），默认 10 秒
 * @param {number} [options.maxFailures=3] - 最大失败次数，默认 3 次
 * @param {string} [options.method='GET'] - 请求方法，默认 GET
 * @param {Object} [options.headers={}] - 请求头
 * @param {Object} [options.body=null] - 请求体（仅 POST/PUT 有效）
 * @param {boolean} [options.autoStart=true] - 是否自动启动心跳
 * @param {Function} [options.onSuccess] - 心跳成功回调 (data, response)
 * @param {Function} [options.onFailure] - 心跳失败回调 (error)
 * @param {Function} [options.onError] - 心跳错误回调 (error, failureCount)
 * @param {Function} [options.onReconnect] - 重连成功回调
 * @returns {Object} - HTTP 心跳实例
 */
export function createHttpHeartbeat(options = {}) {
  const {
    url,
    interval = 30000,
    timeout = 10000,
    maxFailures = 3,
    method = "GET",
    headers = {},
    body = null,
    autoStart = true,
    onSuccess = null,
    onFailure = null,
    onError = null,
    onReconnect = null,
  } = options;

  // 验证必填参数
  if (!url) {
    throw new Error("[HTTP Heartbeat] URL is required");
  }

  let timer = null;
  let failureCount = 0;
  let successCount = 0;
  let isRunning = false;
  let lastResponse = null;
  let lastError = null;

  /**
   * 启动心跳检测
   */
  function start() {
    if (isRunning) {
      console.warn("[HTTP Heartbeat] 心跳检测已在运行中");
      return;
    }

    console.log("🚀 [HTTP Heartbeat] 启动心跳检测...");
    isRunning = true;
    failureCount = 0;
    sendHeartbeat();
  }

  /**
   * 停止心跳检测
   */
  function stop() {
    if (!isRunning) {
      console.warn("[HTTP Heartbeat] 心跳检测未运行");
      return;
    }

    console.log("🛑 [HTTP Heartbeat] 停止心跳检测...");
    if (timer) {
      clearTimeout(timer);
      timer = null;
    }
    isRunning = false;
    failureCount = 0;
  }

  /**
   * 发送心跳请求
   */
  async function sendHeartbeat() {
    if (!isRunning) return;

    try {
      console.log("💓 [HTTP Heartbeat] 发送心跳请求...");

      // 创建 AbortController 用于超时控制
      const controller = new AbortController();
      const timeoutId = setTimeout(() => {
        controller.abort();
      }, timeout);

      // 构建请求配置
      const fetchOptions = {
        method: method.toUpperCase(),
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          ...headers,
        },
      };

      // 如果是 POST/PUT/DELETE，添加 body
      if (["POST", "PUT", "DELETE"].includes(method.toUpperCase())) {
        fetchOptions.body = body ? JSON.stringify(body) : null;
      }

      // 发送请求
      const response = await fetch(url, fetchOptions);
      clearTimeout(timeoutId);

      // 检查 HTTP 状态码
      if (!response.ok) {
        throw new Error(`HTTP ${response.status} ${response.statusText}`);
      }

      // 解析响应数据
      const data = await response.json();
      lastResponse = data;
      successCount++;
      failureCount = 0;

      console.log("✅ [HTTP Heartbeat] 心跳成功", data);

      // 触发成功回调
      if (typeof onSuccess === "function") {
        onSuccess(data, response);
      }

      // 如果之前失败过，现在成功了，触发重连回调
      if (failureCount === 0 && successCount > 1) {
        if (typeof onReconnect === "function") {
          onReconnect(data);
        }
      }
    } catch (error) {
      failureCount++;
      lastError = error;

      console.error(
        `❌ [HTTP Heartbeat] 心跳失败 (${failureCount}/${maxFailures}):`,
        error.message,
      );

      // 触发错误回调
      if (typeof onError === "function") {
        onError(error, failureCount);
      }

      // 达到最大失败次数
      if (failureCount >= maxFailures) {
        console.error("🚨 [HTTP Heartbeat] 连接断开，达到最大失败次数");

        // 触发失败回调
        if (typeof onFailure === "function") {
          onFailure(error);
        }

        // 停止心跳
        stop();
        return;
      }
    } finally {
      // 如果还在运行，设置下一次心跳
      if (isRunning) {
        timer = setTimeout(sendHeartbeat, interval);
      }
    }
  }

  /**
   * 手动触发一次心跳
   */
  function trigger() {
    if (!isRunning) {
      console.warn("[HTTP Heartbeat] 心跳检测未运行，无法手动触发");
      return;
    }

    console.log("🔄 [HTTP Heartbeat] 手动触发心跳...");
    if (timer) {
      clearTimeout(timer);
    }
    sendHeartbeat();
  }

  /**
   * 获取当前状态
   */
  function getStatus() {
    return {
      isRunning,
      failureCount,
      successCount,
      lastResponse,
      lastError,
      url,
      interval,
      timeout,
      maxFailures,
    };
  }

  /**
   * 重置失败计数
   */
  function resetFailures() {
    failureCount = 0;
    console.log("[HTTP Heartbeat] 失败计数已重置");
  }

  // 自动启动
  if (autoStart) {
    start();
  }

  // 返回公共 API
  return {
    start,
    stop,
    trigger,
    resetFailures,
    getStatus,
    getFailureCount: () => failureCount,
    getSuccessCount: () => successCount,
    getLastResponse: () => lastResponse,
    getLastError: () => lastError,
    isRunning: () => isRunning,
    isConnected: () => isRunning && failureCount === 0,
  };
}

/**
 * 更新服务器状态显示
 * @param {string|HTMLElement} element - 状态显示元素或选择器
 * @param {boolean} isConnected - 是否连接成功
 * @param {Object} [options] - 配置选项
 * @param {string} [options.successText='Connection Successful'] - 连接成功文本
 * @param {string} [options.failureText='Connection Failed'] - 连接失败文本
 * @param {string} [options.connectingText='Connecting...'] - 连接中文本
 */
export function updateServerStatus(element, isConnected, options = {}) {
  const {
    successText = "Connection Successful",
    failureText = "Connection Failed",
    connectingText = "Connecting...",
  } = options;

  // 获取 DOM 元素
  let statusElement;
  if (typeof element === "string") {
    statusElement = document.querySelector(element);
  } else {
    statusElement = element;
  }

  if (!statusElement) {
    console.warn("[HTTP Heartbeat] 未找到状态显示元素:", element);
    return;
  }

  // 根据连接状态更新显示
  if (isConnected) {
    // 连接成功 - 绿色
    statusElement.innerHTML = `
      <i class="fas fa-circle" style="color: #28a745; font-size: 0.6rem; margin-right: 5px;"></i>
      ${successText}
    `;
    statusElement.style.color = "#28a745";
  } else {
    // 连接失败 - 黄色/红色
    statusElement.innerHTML = `
      <i class="fas fa-circle" style="color: #dc3545; font-size: 0.6rem; margin-right: 5px;"></i>
      ${failureText}
    `;
    statusElement.style.color = "#dc3545";
  }
}

/**
 * 创建带状态显示的 HTTP 心跳实例（快捷方式）
 * @param {Object} options - 配置选项
 * @param {string} options.url - 心跳接口地址
 * @param {string} options.statusElement - 状态显示元素选择器
 * @param {Object} [options.heartbeatOptions] - createHttpHeartbeat 的其他选项
 * @returns {Object} - HTTP 心跳实例
 */
export function createHttpHeartbeatWithStatus(options = {}) {
  const { url, statusElement, heartbeatOptions = {} } = options;

  if (!url) {
    throw new Error("[HTTP Heartbeat] URL is required");
  }

  if (!statusElement) {
    throw new Error("[HTTP Heartbeat] statusElement is required");
  }

  // 创建心跳实例
  const heartbeat = createHttpHeartbeat({
    url,
    ...heartbeatOptions,
    onSuccess: (data, response) => {
      updateServerStatus(statusElement, true);
      // 调用用户自定义的 onSuccess
      if (typeof heartbeatOptions.onSuccess === "function") {
        heartbeatOptions.onSuccess(data, response);
      }
    },
    onFailure: (error) => {
      updateServerStatus(statusElement, false);
      // 调用用户自定义的 onFailure
      if (typeof heartbeatOptions.onFailure === "function") {
        heartbeatOptions.onFailure(error);
      }
    },
    onError: (error, failureCount) => {
      // 如果是第一次失败，显示警告状态
      if (failureCount === 1) {
        const statusEl =
          typeof statusElement === "string"
            ? document.querySelector(statusElement)
            : statusElement;

        if (statusEl) {
          statusEl.innerHTML = `
            <i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem; margin-right: 5px;"></i>
            Connection Unstable
          `;
          statusEl.style.color = "#ffc107";
        }
      }

      // 调用用户自定义的 onError
      if (typeof heartbeatOptions.onError === "function") {
        heartbeatOptions.onError(error, failureCount);
      }
    },
  });

  return heartbeat;
}

// 默认导出
export default {
  createHttpHeartbeat,
  updateServerStatus,
  createHttpHeartbeatWithStatus,
};

```

##### 加载文件

在需要心跳检查的html文件中，引入js文件做如下修改：

```ejs
<script type="module" src="/javascripts/login.js"></script>
```

在对应的js文件index.js文件中做如下引入和修改：

```js
//引入心跳执行模块
import { createHttpHeartbeat } from "../lib/heartbeat/http-heartbeat.js";
...
//使用heartbeat模块
  {
    createHttpHeartbeat({
      url: `${baseURL}/heartbeat`,
      interval: 60000, // 60秒一次
      timeout: 10000, // 10秒超时
      maxFailures: 3,

      onSuccess: (data) => {
        console.log("✅ 心跳成功:", data);
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #28a745; font-size: 0.6rem;"></i> Connection Successful';
      },

      onFailure: (error) => {
        console.error("❌ 连接断开:", error);
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
      },

      onError: (error, count) => {
        console.warn(`⚠️ 心跳错误 (${count}):`, error.message);
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
      },
    });
  }
```

> 后端服务器做专属心跳路由：
>
> ```js
> //在index.js文件中添加心跳路由
> router.get("/heartbeat", (req, res) => {
>   res.json({
>     status: "ok",
>     timestamp: Date.now(),
>     message: "Heartbeat received",
>   });
> });
> ```
