/**
 * JSDoc（JavaScript Documentation） 注释语法
 * 用于数据库的连接，支持两个回调函数：
 * @param {*} success 数据库连接成功的回调函数，本身是函数
 * @param {*} error 非强制默认项，数据库连接失败的回调函数，本身是函数
 */
module.exports = function (success, error) {
  // 1.安装使用:npm i mongoose --save

  //error的话在此提示
  if (typeof error !== "function") {
    error = () => {
      console.log("MongoDB Connect Fail.");
    };
  }
  // 2.引入mongoose
  const mongoose = require("mongoose");

  // 3. 通过dotenv包导入配置文件，.env 文件中的变量都会被加载到 process.env 对象中,新增加载 .env 文件并支持变量引用
  const dotenv = require("dotenv");
  const dotenvExpand = require("dotenv-expand");
  const myEnv = dotenv.config();
  dotenvExpand.expand(myEnv);

  // 4.连接mongodb数据库，通体采用dotenv配置方案，所有配置项均放入项目根目录.env文件内
  mongoose.connect(
    `mongodb://${process.env.MONGODB_DBHOST}:${process.env.MONGODB_DBPORT}/${process.env.MONGODB_DBNAME}`,
  );

  // 5.监听mongodb数据库的连接状态
  // 5.1 绑定数据库连接成功事件
  mongoose.connection.once("open", function () {
    success();
    console.log("\n" + "=".repeat(50));
    console.log("🚀 MongoDB Connection Successful.");
    console.log("=".repeat(50));
  });
  // 5.2 绑定数据库连接失败事件
  mongoose.connection.on("error", function () {
    error();
    console.log("\n" + "=".repeat(50));
    console.log("❌ MongoDB Connection Failed.");
    console.log("=".repeat(50));
  });

  // 5.3 绑定数据库连接断开事件
  mongoose.connection.on("close", function () {
    console.log("\n" + "=".repeat(50));
    console.log("⚠️ MongoDB Connection Closed!");
    console.log("=".repeat(50));
  });

  /* // 6. 导出mongoose，供其他文件使用
  module.exports = mongoose; */

  /* // 7. 断开数据库连接(一般不用，注释掉)
  setTimeout(() => {
    mongoose.disconnect();
  }, 5000); // 示例-5秒后断开连接 */

  /* // 8. 运行js文件
  // 7.1 方法1
  // node connect-db.js;

  // 7.2 使用VS Code的"运行"按钮
  // 步骤：
  // 安装"Code Runner"扩展
  // 点击左侧扩展图标（或按 Ctrl+Shift+X）
  // 搜索 "Code Runner"
  // 点击安装 */
};
