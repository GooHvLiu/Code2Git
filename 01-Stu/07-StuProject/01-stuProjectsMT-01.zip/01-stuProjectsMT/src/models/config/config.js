/**
 * JSDoc（JavaScript Documentation） 注释语法
 * 用于数据库的文件配置，config.js
 *
 * @param {String} DBHOST - 数据库主机IP地址
 * @param {String} DBPORT - 数据库主机port地址
 * @param {String} DBNAME - 数据库集合名称
 *
 */
module.exports = {
  DBHOST: "192.168.10.148",
  DBPORT: 27017,
  DBNAME: "stuTools",
};
