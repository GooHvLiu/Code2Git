/**
 * JSDoc（JavaScript Documentation） 注释语法
 * 将dbmain.js作为一个函数，在app/main程序使用的时候调用
 */
//导入db文件
const db = require("./db/db.js");
//导入c增d删u改r查文件
const dbCreate = require("./crdu/create.js");
const dbDeleteOne = require("./crdu/deleteOne.js");
const dbReadAll = require("./crdu/readAll.js");
const dbReadOne = require("./crdu/readOne.js");
const dbUpdateOne = require("./crdu/updateOne.js");

//调用db函数,第1个()=>{}表示success回调函数，第2个()=>{}表示error回调函数
db(
  //调用如下函数，说明数据库连接成功
  async () => {
    //create 调用数据库创建api
    {
      try {
        const dataObject = [
          {
            username: "admin",
            password: "admin123",
            role: "admin",
            isActive: true,
            lastLogin: Date.now(),
            loginCount: 3,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            rememberMe: false,
          },
          {
            username: "engineer",
            password: "engineer123",
            role: "user",
            isActive: true,
            lastLogin: Date.now(),
            loginCount: 0,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            rememberMe: false,
          },
          {
            username: "operator",
            password: "operator123",
            role: "user",
            isActive: true,
            lastLogin: Date.now(),
            loginCount: 0,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            rememberMe: false,
          },
        ];
        console.log("📝 正在创建测试用户...");
        await dbCreate(dataObject);
        console.log("✅ 用户创建成功！");
      } catch (error) {
        if (error.code === 11000) {
          console.log("⚠️  用户已存在，跳过创建");
        } else {
          console.error("❌ 创建用户失败:", error.message);
        }
      }
    }
    //delet 调用数据库删除api
    {
      // dbDelete();
    }
    //readAll 调用数据库查询api
    {
      //dbReadAll();
    }
    //updateOne 调用数据库修改api
    {
      // dbUpdateOne();
    }
  },
);

//第01步：安装依赖
// npm install mongoose

//第02步：运行程序
// node dbmain.js
