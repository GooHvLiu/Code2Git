/**
 * JSDoc（JavaScript Documentation） 注释语法
 * 用于数据库创建结构对象和模型对象，model.js
 */

// 1.1 创建Schema(模式)对象,并非是必须的，只是为了方便，./db是需要根据连接js文件名决定的，引入当前目录下的 db.js 文件
// 1.2 bcrypt是加密模块，目前使用bcryptjs模块
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

// 2. 创建文档的结构对象，设置集合中文档的属性以及属性值的类型
const usersSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, "用户名不能为空"],
    unique: true,
    trim: true,
    minlength: [3, "用户名至少3个字符"],
    maxlength: [30, "用户名最多30个字符"],
  },
  password: {
    type: String,
    required: [true, "密码不能为空"],
    minlength: [6, "密码至少6个字符"],
    //select: false, // 默认不返回密码字段
  },
  role: {
    type: String,
    enum: ["user", "admin"],
    default: "user",
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  lastLogin: {
    type: Date,
    default: null,
  },
  loginCount: {
    type: Number,
    default: 0,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

/*  3. 对发过来的数据进行加密处理
 *  概念：Mongoose 中间件（Middleware）概念
 *  中间件：也叫"钩子"（hooks），是在特定操作之前或之后自动执行的函数
 *    pre：表示"之前"执行（前置钩子）
 *    save：表示在文档保存到数据库之前触发
 *  */
usersSchema.pre("save", async function () {
  try {
    // 生成盐（10 是默认的加密强度）
    const salt = await bcrypt.genSalt(10);

    // 加密密码
    this.password = await bcrypt.hash(this.password, salt);
  } catch (error) {
    throw error;
  }
});

// 4. 密码比较方法
usersSchema.methods.comparePassword = async function (candidatePassword) {
  try {
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (error) {
    throw new Error("密码比较失败");
  }
};

// 5. 创建Model(模型)对象，对文档操作的封装对象，第一个参数表示创建的集合的名称，mongoose会自动将集合名变为复数，第二个参数表示利用的模式对象
const usersModel = mongoose.model("users", usersSchema);

// 6. 导出DemoModel，供其他文件使用
module.exports = usersModel;
