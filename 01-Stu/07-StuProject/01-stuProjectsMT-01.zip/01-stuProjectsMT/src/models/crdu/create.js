/**
 * JSDoc（JavaScript Documentation） 注释语法
 * @param {Object} dataObject - 传递给数据库操作的数据对象
 * @returns {Number} 返回 Promise，解析为创建成功与否的字符串
 * 用于数据库的新建数据，create.js
 */
module.exports = function (dataObject) {
  const DemoModel = require("../models/model.js");
  return new Promise((resolve, reject) => {
    setTimeout(async () => {
      try {
        const result = await DemoModel.create(dataObject);
        // 通过 reject 返回结果
        resolve(result);
      } catch (error) {
        // 通过 reject 返回结果
        reject(error);
      }
    }, 500);
  });
};
