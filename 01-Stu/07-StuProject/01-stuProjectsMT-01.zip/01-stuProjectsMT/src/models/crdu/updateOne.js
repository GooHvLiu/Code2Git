/**
 * JSDoc（JavaScript Documentation） 注释语法
 * 用于数据库的修改数据，update.js
 *
 * @param {Object} filter - 查询条件对象，例如 { author: "吴承恩" }
 * @param {Object} updateData - 更新内容对象，例如 { price: 19.9 }
 * @param {Object} [options] - 可选的更新选项
 * @returns {Promise<Object>} - 返回更新结果对象
 *
 */
module.exports = function dbUpdate(filter, updateData, options = {}) {
  const DemoModel = require("../models/model.js");

  // 返回 Promise,让调用者可以等待操作完成
  return new Promise(async (resolve, reject) => {
    setTimeout(async () => {
      try {
        const result = await DemoModel.updateOne(filter, updateData, options);
        // 通过 resolve 返回结果
        resolve(result);
      } catch (error) {
        // 通过 reject 返回结果
        reject(error);
      }
    }, 500);
  });
};
