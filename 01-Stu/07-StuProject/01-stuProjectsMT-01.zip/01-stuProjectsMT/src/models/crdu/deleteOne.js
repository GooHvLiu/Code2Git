/**
 * JSDoc（JavaScript Documentation） 注释语法
 * @param {Object} conditions - 删除条件
 * @returns {String} 返回 Promise，解析为删除成功与否的字符串
 * 用于数据库的删除数据，deleteOne.js
 */

module.exports = function (conditions) {
  const DemoModel = require("../models/model.js");

  // 返回 Promise，让调用者可以等待操作完成
  return new Promise((resolve, reject) => {
    setTimeout(async () => {
      try {
        const result4 = await DemoModel.deleteOne(conditions);
        //通过 resolve 返回错误
        resolve(result4);
      } catch (error) {
        //通过 reject 返回错误
        reject(error);
      }
    }, 500); // 等待0.5秒，确保数据库连接成功
  });
};
