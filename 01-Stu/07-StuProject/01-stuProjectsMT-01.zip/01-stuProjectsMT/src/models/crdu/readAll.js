/**
 * JSDoc（JavaScript Documentation） 注释语法
 * @param {Object} dataObject - 传递给数据库操作的查询数据对象
 * @returns {Promise<Object>} 返回 Promise，解析为查询结果
 * 用于数据库的查询数据，readAll.js
 */
module.exports = function (dataObject) {
  const DemoModel = require("../models/model.js");
  return new Promise((resolve, reject) => {
    setTimeout(async () => {
      try {
        let result2 = await DemoModel.find(dataObject);
        // 通过 resolve 返回结果
        resolve(result2);
      } catch (error) {
        // 通过 reject 返回结果
        reject(error);
      }
    }, 500);
  });
};
