const User = require("../models/models/model.js");

/**
 * 认证服务
 * 负责业务逻辑，不关心 HTTP 请求/响应
 */
class AuthService {
  /**
   * 用户登录认证
   * @param {Object} credentials - { username, password }
   * @returns {Object} 认证结果
   */
  async login(credentials) {
    const { username, password } = credentials;

    // 验证输入
    if (!username || !password) {
      throw new Error("用户名和密码不能为空");
    }

    // 查找用户
    const user = await User.findOne({ username }).select("+password");

    if (!user) {
      throw new Error("查找用户错误，用户名或密码错误");
    }

    // 检查激活状态
    if (!user.isActive) {
      throw new Error("账户已被禁用，请联系管理员");
    }

    // 验证密码
    const isPasswordMatch = await user.comparePassword(password);
    console.log("验证密码结果：", isPasswordMatch);

    if (!isPasswordMatch) {
      throw new Error("验证密码错误，用户名或密码错误");
    }

    return {
      id: user._id,
      username: user.username,
      isActive: user.isActive,
    };
  }
}

module.exports = new AuthService();
