//引入资源库
var express = require("express");
var router = express.Router();

//引入认证请求和响应组件
const authController = require("../controllers/authController");
/**
 * 新增，加载 .env 文件，所有 .env 文件中的变量都会被加载到 process.env 对象中
 */
const dotenv = require("dotenv");
const dotenvExpand = require("dotenv-expand");
const myEnv = dotenv.config();
dotenvExpand.expand(myEnv);

//路由：登录界面
router.get("/", function (req, res, next) {
  res.render("login");
});

//路由：登录数据验证
router.post("/login", authController.login);

//路由：跳转其他页面
router.get("/projectManager", function (req, res, next) {
  res.render("projectManager");
});

module.exports = router;
