const authService = require("../services/authService");
/**
 * 认证控制器
 * 处理 HTTP 请求和响应
 * 其为类组件，通过导出new AuthController()确保外部直接使用其内部方法
 */
class AuthController {
  /**
   * 用户登录认证
   */
  async login(req, res, next) {
    try {
      const { username, password } = req.body;
      // 调用服务层
      const authData = await authService.login({ username, password });
      console.log("密码验证成功，返回的数据为：", authData);
      res.json({
        success: true,
        message: "登录成功",
        data: authData,
      });
    } catch (error) {
      // 统一错误处理
      if (error.message.includes("不能为空")) {
        return res.status(400).json({
          success: false,
          message: error.message,
        });
      }

      if (error.message.includes("错误") || error.message.includes("禁用")) {
        return res.status(401).json({
          success: false,
          message: error.message,
        });
      }

      next(error);
    }
  }
}

module.exports = new AuthController();
