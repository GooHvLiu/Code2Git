/**
 * 健康检查
 * 处理 HTTP 请求和响应
 * 其为类组件，通过导出new healthController()确保外部直接使用其内部方法
 */
class healthController {
  async healthCheck(req, res, next) {
    res.json({
      status: "ok",
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || "development",
      version: require("../../package.json").version,
      memory: {
        rss: Math.round(process.memoryUsage().rss / 1024 / 1024) + " MB",
        heapTotal:
          Math.round(process.memoryUsage().heapTotal / 1024 / 1024) + " MB",
        heapUsed:
          Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + " MB",
      },
    });
  }
}
module.exports = new healthController();
