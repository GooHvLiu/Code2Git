// 项目数据（你可以从后端API获取）
const projects = [
  {
    id: 1,
    title: "Node.js API 服务器",
    icon: "fab fa-node-js",
    description: "基于Express的RESTful API，支持JWT认证和数据验证",
    tech: ["Node.js", "Express", "JWT", "MongoDB"],
    status: "active",
    route: "/projects/nodejs-api",
  },
  {
    id: 2,
    title: "Express 中间件系统",
    icon: "fas fa-layer-group",
    description: "自定义中间件集合，包括日志、错误处理、权限控制",
    tech: ["Express", "Middleware", "Morgan"],
    status: "development",
    route: "/projects/express-middleware",
  },
  {
    id: 3,
    title: "MongoDB 数据管理",
    icon: "fas fa-database",
    description: "数据库CRUD操作，聚合查询，索引优化",
    tech: ["MongoDB", "Mongoose", "Aggregation"],
    status: "active",
    route: "/projects/mongodb-manager",
  },
  {
    id: 4,
    title: "Docker 容器化部署",
    icon: "fab fa-docker",
    description: "Docker Compose配置，多容器应用部署方案",
    tech: ["Docker", "Docker Compose", "Nginx"],
    status: "testing",
    route: "/projects/docker-deploy",
  },
  {
    id: 5,
    title: "用户认证系统",
    icon: "fas fa-user-shield",
    description: "完整的用户注册、登录、权限管理功能",
    tech: ["Node.js", "Express", "bcrypt", "JWT"],
    status: "active",
    route: "/projects/auth-system",
  },
  {
    id: 6,
    title: "实时聊天应用",
    icon: "fas fa-comments",
    description: "WebSocket实时通信，支持群聊和私聊",
    tech: ["Socket.io", "Node.js", "Redis"],
    status: "development",
    route: "/projects/chat-app",
  },
];

// 渲染项目卡片
function renderProjects() {
  const container = document.getElementById("projectsContainer");

  // 清空容器
  container.innerHTML = "";

  // 渲染每个项目
  projects.forEach((project) => {
    const card = document.createElement("div");
    card.className = `project-card ${getTechClass(project.tech[0])}`;
    card.onclick = () => openProject(project.route);

    // 确定状态标签的类名
    let statusClass = "";
    let statusText = "";
    switch (project.status) {
      case "active":
        statusClass = "status-active";
        statusText = "🟢 运行中";
        break;
      case "development":
        statusClass = "status-development";
        statusText = "🟡 开发中";
        break;
      case "testing":
        statusClass = "status-testing";
        statusText = "🔵 测试中";
        break;
    }

    card.innerHTML = `
                    <div class="project-icon">
                        <i class="${project.icon}"></i>
                    </div>
                    <h3 class="project-title">${project.title}</h3>
                    <p class="project-desc">${project.description}</p>
                    <div class="project-meta">
                        <div class="project-tech">
                            ${project.tech.map((tech) => `<span class="tech-tag">${tech}</span>`).join("")}
                        </div>
                        <span class="project-status ${statusClass}">${statusText}</span>
                    </div>
                `;

    container.appendChild(card);
  });

  // 添加"添加新项目"按钮
  const addBtn = document.createElement("div");
  addBtn.className = "add-project-btn";
  addBtn.innerHTML = `
                <i class="fas fa-plus-circle"></i>
                <span>添加新项目</span>
            `;
  addBtn.onclick = addNewProject;
  container.appendChild(addBtn);
}

// 根据技术栈获取CSS类名
function getTechClass(tech) {
  const techMap = {
    "Node.js": "nodejs",
    Express: "express",
    MongoDB: "mongodb",
    Docker: "docker",
    API: "api",
    Web: "web",
  };
  return techMap[tech] || "api";
}

// 打开项目
function openProject(route) {
  // 这里可以改为实际的跳转逻辑
  alert(
    `即将进入: ${route}\n实际使用时请替换为 window.location.href = '${route}'`,
  );
  // window.location.href = route;
}

// 添加新项目
function addNewProject() {
  const newProject = {
    id: projects.length + 1,
    title: prompt("请输入项目名称:", "新项目"),
    icon: "fas fa-cube",
    description: prompt("请输入项目描述:", "这是一个新的测试项目"),
    tech: ["Node.js", "Express"],
    status: "development",
    route: `/projects/project-${projects.length + 1}`,
  };

  if (newProject.title && newProject.description) {
    projects.push(newProject);
    renderProjects();
    alert("项目添加成功！");
  }
}

// 退出登录
function logout() {
  if (confirm("确定要退出登录吗？")) {
    // 实际使用时替换为后端登出逻辑
    alert("已退出登录");
    // window.location.href = '/login';
  }
}

// 初始化
window.onload = function () {
  renderProjects();

  // 模拟在线人数更新
  setInterval(() => {
    const count = Math.floor(Math.random() * 5) + 1;
    document.getElementById("onlineCount").textContent = count;
  }, 5000);
};
