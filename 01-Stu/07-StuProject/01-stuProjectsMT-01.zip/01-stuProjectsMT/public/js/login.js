//引入心跳执行模块
import { createHttpHeartbeat } from "./http-heartbeat.js";

// DOM 元素
const loginForm = document.getElementById("loginForm");
const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");
const passwordToggle = document.getElementById("passwordToggle");
const loginBtn = document.getElementById("loginBtn");
const alertBox = document.getElementById("alertBox");
const serverStatus = document.getElementById("serverStatus");

// 表单验证
function validateForm() {
  let isValid = true;

  // 验证用户名
  if (usernameInput.value.trim() === "") {
    showError("usernameError", "请输入用户名");
    isValid = false;
  } else {
    hideError("usernameError");
  }

  // 验证密码
  if (passwordInput.value.trim() === "") {
    showError("passwordError", "请输入密码");
    isValid = false;
  } else if (passwordInput.value.length < 6) {
    showError("passwordError", "密码至少6位");
    isValid = false;
  } else {
    hideError("passwordError");
  }

  return isValid;
}

// 显示错误信息
function showError(elementId, message) {
  const errorElement = document.getElementById(elementId);
  errorElement.textContent = message;
  errorElement.classList.add("show");

  // 高亮输入框
  const inputElement = document.getElementById(elementId.replace("Error", ""));
  if (inputElement) {
    inputElement.classList.add("error");
  }
}

// 隐藏错误信息
function hideError(elementId) {
  const errorElement = document.getElementById(elementId);
  errorElement.classList.remove("show");

  const inputElement = document.getElementById(elementId.replace("Error", ""));
  if (inputElement) {
    inputElement.classList.remove("error");
  }
}

// 显示提示信息
function showAlert(message, type = "error") {
  alertBox.textContent = message;
  alertBox.className = `alert alert-${type} show`;

  // 3秒后自动隐藏
  setTimeout(() => {
    alertBox.classList.remove("show");
  }, 3000);
}

// 切换密码可见性
passwordToggle.addEventListener("click", function () {
  const type = passwordInput.getAttribute("type");
  if (type === "password") {
    passwordInput.setAttribute("type", "text");
    passwordToggle.classList.remove("fa-eye");
    passwordToggle.classList.add("fa-eye-slash");
  } else {
    passwordInput.setAttribute("type", "password");
    passwordToggle.classList.remove("fa-eye-slash");
    passwordToggle.classList.add("fa-eye");
  }
});

// 表单提交
loginForm.addEventListener("submit", async function (e) {
  e.preventDefault();

  // 验证表单
  if (!validateForm()) {
    return;
  }

  // 显示加载状态
  loginBtn.classList.add("loading");
  loginBtn.disabled = true;

  // 获取表单数据
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();
  const rememberMe = document.getElementById("rememberMe").checked;

  // 准备发送的数据
  const loginData = {
    username: username,
    password: password,
    rememberMe: rememberMe,
  };

  try {
    // 获取后端返回的服务器地址
    const serverInfo = await getServerInfo();

    const response = await fetch(
      `http://${serverInfo.localIP}:${serverInfo.port}/login`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        //js对象转JSON字符串
        body: JSON.stringify(loginData),
      },
    );

    // 解析响应
    const result = await response.json();
    console.log("服务器响应的数据为：", result);

    if (response.ok) {
      showAlert("登录成功，正在跳转...", "success");

      // 保存token（如果后端返回了）
      if (result.token) {
        localStorage.setItem("authToken", result.token);
      }

      // 保存用户信息（可选）
      if (result.user) {
        localStorage.setItem("userInfo", JSON.stringify(result.user));
      }

      // 如果勾选了记住我，保存到localStorage，否则保存到sessionStorage
      if (rememberMe) {
        localStorage.setItem("rememberMe", "true");
      } else {
        sessionStorage.setItem("isLoggedIn", "true");
      }

      // 延迟跳转，让用户看到成功提示
      setTimeout(() => {
        // 跳转到项目管理页面
        window.location.href = "/projectManager";
      }, 500);
    } else {
      // 登录失败
      const errorMessage = result.message || "登录失败，请检查用户名和密码";
      showAlert(errorMessage, "error");

      // 清空密码
      passwordInput.value = "";
    }
  } catch (error) {
    console.error("登录请求失败:", error);
    showAlert("网络错误，请检查服务器是否运行", "error");
    serverStatus.innerHTML =
      '<i class="fas fa-circle" style="color: #dc3545; font-size: 0.6rem;"></i> 服务器连接失败';
  } finally {
    // 恢复按钮状态
    loginBtn.classList.remove("loading");
    loginBtn.disabled = false;
  }
});

// 输入框实时验证
usernameInput.addEventListener("input", function () {
  if (this.value.trim() !== "") {
    hideError("usernameError");
  }
});

passwordInput.addEventListener("input", function () {
  if (this.value.trim() !== "") {
    hideError("passwordError");
  }
});

// 页面加载时,检查是否已登录
window.addEventListener("load", function () {
  // 检查是否已经登录
  if (
    localStorage.getItem("isLoggedIn") === "true" ||
    sessionStorage.getItem("isLoggedIn") === "true"
  ) {
    // 如果已经登录，直接跳转
    window.location.href = "/projectManager";
  }

  // 检查服务器连接
  checkServerConnection();
});

// 检查服务器连接
async function checkServerConnection() {
  //使用heartbeat模块,心跳检查一直执行，不启用关闭功能
  {
    // 获取后端返回的服务器地址
    const serverInfo = await getServerInfo();

    createHttpHeartbeat({
      url: `http://${serverInfo.localIP}:${serverInfo.port}/heartbeat`,
      interval: 60000, // 60秒一次
      timeout: 10000, // 10秒超时
      maxFailures: 10, // 10尝试连接

      onSuccess: (data) => {
        // console.log("✅ 心跳成功:", data);
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #28a745; font-size: 0.6rem;"></i> Connection Successful';
      },

      onFailure: (error) => {
        // console.error("❌ 连接断开:", error);
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
      },

      onError: (error, count) => {
        // console.warn(`⚠️ 心跳错误 (${count}):`, error.message);
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
      },
    });
  }
}

// 快捷键登录（按Enter键）
document.addEventListener("keydown", function (e) {
  if (e.key === "Enter" && !loginBtn.disabled) {
    loginForm.requestSubmit();
  }
});

// 显示忘记密码（示例函数）
function showForgotPassword(e) {
  e.preventDefault();
  alert("忘记密码功能开发中...");
}

// 显示注册页面（示例函数）
function showRegister(e) {
  e.preventDefault();
  if (confirm("是否跳转到注册页面？")) {
    window.location.href = "register.html";
  }
}

// 自动填充测试数据（开发环境使用）
if (window.location.hostname === "localhost") {
  document.addEventListener("keydown", function (e) {
    if (e.ctrlKey && e.key === "t") {
      usernameInput.value = "admin";
      passwordInput.value = "admin123";
      showAlert("已填充测试数据", "info");
    }
  });
}

//向后端获取服务器地址的实现
async function getServerInfo() {
  try {
    const response = await fetch("/server-info");

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("❌ 获取服务器信息失败:", error.message);
    throw error;
  }
}
