//引入相关资源库
var createError = require("http-errors");
var express = require("express");
const cors = require("cors");
var path = require("path");
var cookieParser = require("cookie-parser");
var logger = require("morgan");
var loginRouter = require("./src/routes/login");
const healthController = require("./src/controllers/healthController");

//生成express程序
var app = express();

//全站跨域
app.use(cors());

// 视图路径设置
app.set("views", path.join(__dirname, "views"));

// 添加 EJS 配置
app.set("view engine", "ejs");

//HTTP 请求日志中间件
app.use(logger("dev"));

//json解析
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

//coolie解析
app.use(cookieParser());

//设置静态资源路径
app.use(express.static(path.join(__dirname, "public")));

//路由：登录根目录
app.use("/", loginRouter);

//路由：健康检查
app.get("/health", healthController.healthCheck);

//路由：服务器地址响应
app.get("/server-info", (req, res) => {
  res.json({
    localIP: process.env.LOCAL_IP,
    port: process.env.PORT,
    timestamp: Date.now(),
  });
});

//路由：心跳交互
app.get("/heartbeat", (req, res) => {
  res.json({
    status: "ok",
    timestamp: Date.now(),
    message: "Heartbeat received",
  });
});

// 路由：404
app.use(function (req, res, next) {
  next(createError(404));
});

// 路由异常处理
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render("error");
});

module.exports = app;
