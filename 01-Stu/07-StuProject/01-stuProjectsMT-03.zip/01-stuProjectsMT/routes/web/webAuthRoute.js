var express = require("express");
const usersController = require("@MongoDB/controllers/users.controller.js");
var authRouter = express.Router();
const envData = {
  APP_NAME: process.env.APP_NAME || "stuProjectsMT",
  LOGIN_REDIRECT_URL: process.env.LOGIN_REDIRECT_URL || "/auth/login",
  REGISTER_REDIRECT_URL: process.env.REGISTER_REDIRECT_URL || "/auth/reg",
  FORGETPWD_REDIRECT_URL:
    process.env.FORGETPWD_REDIRECT_URL || "/auth/forgetpwd",
  HEARTBEAT_INTERVAL: process.env.HEARTBEAT_INTERVAL || 30000,
  HEARTBEAT_TIMEOUT: process.env.HEARTBEAT_TIMEOUT || 10000,
  MAX_HEARTBEAT_FAIL: process.env.HEARTBEAT_MAX_FAILURE || 10,
  ENABLE_REGISTER: process.env.ENABLE_REGISTER === "true",
  ENABLE_FORGET_PWD: process.env.ENABLE_FORGET_PWD === "true",
  NODE_ENV: process.env.NODE_ENV,
  API_PREFIX: "/auth",
};
//GET IP:PORT/auth/reg 注册页面
authRouter.get("/reg", function (req, res, next) {
  if (process.env.ENABLE_REGISTER === "false") {
    req.flash("error", "目前禁止注册，请联系管理员。");
    return res.redirect("/auth/login");
  } else {
    res.render("reg.auth.ejs", {
      env: envData,
    });
  }
});

//GET IP:PORT/auth/login 登录页面
authRouter.get("/login", function (req, res, next) {
  res.render("login.auth.ejs", {
    env: envData,
  });
});

//POST IP:PORT/auth/reg 注册数据POST
authRouter.post("/reg", async function (req, res, next) {
  try {
    const registerDate = await usersController.registerData(req);
    if (registerDate.type === 1) {
      return res.redirect("/auth/login");
    } else {
      // 1. 把错误存入flash
      req.flash("error", registerDate.msg);
      // 账号/邮箱地址存在，无法注册
      // 2. 重定向到GET注册页面，不要直接render
      return res.redirect("/auth/reg");
    }
  } catch (err) {
    req.flash("error", "注册服务异常，请稍后重试");
    return res.redirect("/auth/reg");
  }
});

//POST IP:PORT/auth/login 登录数据POST
authRouter.post("/login", async function (req, res, next) {
  try {
    const loginDate = await usersController.loginData(req);

    if (loginDate.type === 1) {
      return res.redirect("/projects");
    } else {
      // 1. 把错误存入flash
      req.flash("error", loginDate.msg);
      // 2. 重定向到GET登录页面，不要直接render
      return res.redirect("/auth/login");
    }
  } catch (err) {
    req.flash("error", "登录服务异常，请稍后重试");
    return res.redirect("/auth/login");
  }
});

//GET IP:PORT/auth/logout 登出
authRouter.get("/logout", async function (req, res, next) {
  try {
    await usersController.logoutData(req);
    // session销毁成功，跳登录页
    return res.redirect("/auth/login");
  } catch (err) {
    req.flash("error", "登出服务异常，请稍后重试");
    return res.redirect("/auth/login");
  }
});

module.exports = authRouter;
