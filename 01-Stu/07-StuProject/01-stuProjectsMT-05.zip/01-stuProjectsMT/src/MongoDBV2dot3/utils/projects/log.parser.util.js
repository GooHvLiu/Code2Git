/**
 * 解析子项目启动单行日志，提取可访问地址
 * 业务用途：自动抓取子Express打印的 Local / Network 访问链接，更新数据库 bindIp、bindPort
 * 优先级规则：优先返回局域网Network地址，不存在则降级使用本机Local地址，无匹配返回null
 * 匹配日志示例：
 *  1、Network: http://172.25.96.1:3000
 *  2、Local: http://localhost:3000
 *  兼容中英文冒号 `:` / `：`，适配不同打印日志格式
 * @param {string} fullLog 子进程拆分后的单行完整日志文本
 * @returns {null | {ip:string, port:string}} 匹配成功返回IP+端口对象，无地址返回null
 */
function parseNetworkUrl(fullLog) {
  /**
   * 正则表达式拆解
   * /(Local|Network)[:：]\s*http:\/\/([0-9a-zA-Z.]+):(\d+)/gi
   * 分组1 (Local|Network)：匹配地址类型，区分局域网/本地
   * [:：]：兼容英文冒号、中文全角冒号两种写法
   * \s*：匹配0个或多个空格
   * http:\/\/：固定协议前缀
   * 分组2 ([0-9a-zA-Z.]+)：匹配IP/域名（localhost、172.25.96.1）
   * 分组3 (\d+)：匹配端口数字
   * gi：全局匹配 + 忽略大小写
   */
  const reg = /(Local|Network)[:：]\s*http:\/\/([0-9a-zA-Z.]+):(\d+)/gi;
  // 存储局域网地址匹配结果
  let networkMatch = null;
  // 存储本地本机地址匹配结果
  let localMatch = null;
  // 循环匹配结果临时变量
  let match;
  // 记录匹配到地址的总条数，判断日志内是否存在地址
  let matchCount = 0;

  // 循环遍历所有正则匹配结果，全局查找日志内全部地址
  while ((match = reg.exec(fullLog)) !== null) {
    matchCount++;
    // 地址类型 Local / Network
    const type = match[1];
    // IP或域名 localhost / 172.25.96.1
    const ip = match[2];
    const port = match[3];
    if (type === "Network") {
      networkMatch = { ip, port };
    } else {
      // 本地地址，低优先级
      localMatch = { ip, port };
    }
  }
  // 日志中未匹配到任何地址，直接返回null
  if (matchCount === 0) return null;
  // 空值合并运算符：存在Network局域网地址优先返回，否则返回Local本地地址
  return networkMatch ?? localMatch;
}

module.exports = { parseNetworkUrl };
