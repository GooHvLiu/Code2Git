var express = require("express");
var webProjectsRouter = express.Router();
const projectController = require("@MongoDB/controllers/projects.controller.js");
const sessionAuth =
  require("@middleware/login.session.auth.help.js").checkSessionLogin;
const envData = {
  APP_NAME: process.env.APP_NAME || "stuProjectsMT",
  LOGOUT_REDIRECT_URL: process.env.LOGOUT_REDIRECT_URL || "/auth/logOUT",
  HEARTBEAT_REDIRECT_URL: process.env.HEARTBEAT_REDIRECT_URL || "/heartbeat",
  HEARTBEAT_INTERVAL: process.env.HEARTBEAT_INTERVAL || 30000,
  HEARTBEAT_INTERVAL: process.env.HEARTBEAT_INTERVAL || 30000,
  HEARTBEAT_TIMEOUT: process.env.HEARTBEAT_TIMEOUT || 10000,
  MAX_HEARTBEAT_FAIL: process.env.HEARTBEAT_MAX_FAILURE || 10,
  NODE_ENV: process.env.NODE_ENV,
};

//项目管理主页
webProjectsRouter.get(
  ["/", "/lists"],
  sessionAuth,
  async function (req, res, next) {
    const renderData = await projectController.getProjectsListData(req);
    res.render("index.pm.ejs", {
      user: req.session.username,
      projectsList: renderData.data,
      env: envData,
    });
  },
);

webProjectsRouter.post("/start/:id", sessionAuth, async function (req, res) {
  await projectController.start(req, res);
});
webProjectsRouter.post("/stop/:id", sessionAuth, async function (req, res) {
  await projectController.stop(req, res);
});
webProjectsRouter.post("/restart/:id", sessionAuth, async function (req, res) {
  await projectController.restart(req, res);
});

module.exports = webProjectsRouter;
