const { success, fail } = require("@MongoDB/utils/response.js");
const { projectsService } = require("@MongoDB/services/index.service.js");
const { spawn, execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

class ProjectsController {
  /**
   * 私有方法：通过lock文件+PID判断项目是否正在运行
   * @param {Object} project 项目数据库实体
   * @returns {boolean} true=运行中 false=已停止
   */
  async #getProjectRunStatus(project) {
    const lockFilePath = path.join(project.workDir, ".running.lock");
    // 锁文件不存在，直接判定未运行
    if (!fs.existsSync(lockFilePath)) return false;
    try {
      // 读取存储的进程PID
      const pid = fs.readFileSync(lockFilePath, "utf-8").trim();
      // Windows 查询进程列表，判断PID是否存活
      const taskOutput = execSync(`tasklist /FI "PID eq ${pid}"`, {
        encoding: "utf-8",
      });
      // 输出包含PID代表进程存在
      return taskOutput.includes(pid);
    } catch (err) {
      // 查询进程报错，说明进程已死亡，删除失效锁文件
      if (fs.existsSync(lockFilePath)) fs.unlinkSync(lockFilePath);
      return false;
    }
  }

  /**
   * 内部私有：仅执行停止逻辑，无http响应，返回布尔结果
   */
  async #stopInner(projectId) {
    try {
      const project = await projectsService.findById(projectId);
      if (!project) return false;

      const lockPath = path.join(project.workDir, ".running.lock");
      if (!fs.existsSync(lockPath)) return false;

      const pid = fs.readFileSync(lockPath, "utf-8").trim();
      execSync(`taskkill /F /PID ${pid}`, { encoding: "utf-8" });
      fs.unlinkSync(lockPath);

      project.status = "stopped";
      await project.save();
      return true;
    } catch (err) {
      console.error("内部停止逻辑异常", err);
      return false;
    }
  }

  /**
   * 内部私有：仅执行启动逻辑，无http响应，返回布尔结果
   */
  async #startInner(projectId) {
    try {
      const project = await projectsService.findById(projectId);
      if (!project) return false;

      const isRunning = await this.#getProjectRunStatus(project);
      if (isRunning) return false;

      const cmdArr = project.startCmd.split(" ");
      const execBin = cmdArr[0];
      const execArgs = cmdArr.slice(1);
      const lockPath = path.join(project.workDir, ".running.lock");

      // 复制父进程全部环境变量
      const childEnv = { ...process.env };
      // 删除继承过来的主程序PORT，子项目会读取自身.env的PORT=3000
      delete childEnv.PORT;

      const childProc = spawn(execBin, execArgs, {
        cwd: project.workDir,
        detached: true,
        stdio: ["ignore", "pipe", "pipe"],
        env: childEnv, // 传入清理后的环境变量
      });
      childProc.unref();

      // 打印日志不变
      childProc.stdout.on("data", (data) => {
        console.log(`【子项目${project.title}日志】${data.toString()}`);
      });
      childProc.stderr.on("data", (errData) => {
        console.error(`【子项目${project.title}错误】${errData.toString()}`);
      });
      childProc.on("close", (code) => {
        console.warn(`【子项目${project.title}进程退出，退出码：${code}`);
        if (fs.existsSync(lockPath)) fs.unlinkSync(lockPath);
      });

      fs.writeFileSync(lockPath, childProc.pid.toString(), "utf-8");

      await new Promise((resolve) => setTimeout(resolve, 800));
      const stillAlive = await this.#getProjectRunStatus(project);
      if (!stillAlive) {
        if (fs.existsSync(lockPath)) fs.unlinkSync(lockPath);
        return false;
      }

      project.status = "active";
      await project.save();
      return true;
    } catch (err) {
      console.error("内部启动逻辑异常", err);
      return false;
    }
  }

  // 【API接口】获取所有项目列表，同步实时运行状态
  async getProjectsList(req, res) {
    try {
      const projectsListData = await projectsService.findAll();
      // 循环同步每个项目运行状态
      for (const item of projectsListData) {
        // 加长等待，消除刚启动瞬时读取不到PID的问题
        await new Promise((resolve) => setTimeout(resolve, 100));
        const running = await this.#getProjectRunStatus(item);
        item.status = running ? "active" : "stopped";
        await item.save();
      }
      return success(res, projectsListData, "获取项目列表成功");
    } catch (err) {
      console.error("获取项目列表异常", err);
      return fail(res, err.message);
    }
  }

  // 【页面EJS渲染专用】获取项目列表数据
  async getProjectsListData(req) {
    try {
      const projectsListData = await projectsService.findAll();
      for (const item of projectsListData) {
        await new Promise((resolve) => setTimeout(resolve, 100));
        const running = await this.#getProjectRunStatus(item);
        item.status = running ? "active" : "stopped";
        await item.save();
      }
      return {
        type: 1,
        msg: "获取项目列表成功",
        data: projectsListData,
      };
    } catch (err) {
      console.error("页面列表查询异常", err);
      return {
        type: -1,
        msg: err.message || "获取项目列表失败，请检查填写数据",
        error: err,
      };
    }
  }

  // 【API】创建新项目
  async createProjects(req, res) {
    try {
      const createProjectsData = await projectsService.createProject(req.body);
      return success(res, createProjectsData, "创建成功");
    } catch (err) {
      console.error("创建项目异常", err);
      return fail(res, err.message);
    }
  }

  // 页面渲染专用创建方法
  async createProjectsData(Object) {
    try {
      const data = await projectsService.createProject(Object);
      return {
        type: 1,
        msg: "创建成功",
        data: data,
      };
    } catch (err) {
      return {
        type: -1,
        msg: err.message || "项目创建失败，请检查填写数据",
        error: err,
      };
    }
  }

  // 启动项目
  async start(req, res) {
    try {
      const { id } = req.params;
      const project = await projectsService.findById(id);
      if (!project) return fail(res, "项目不存在");

      const isRunning = await this.#getProjectRunStatus(project);
      if (isRunning) return fail(res, "该项目已在运行中");

      const cmdArr = project.startCmd.split(" ");
      const execBin = cmdArr[0];
      const execArgs = cmdArr.slice(1);
      const lockPath = path.join(project.workDir, ".running.lock");

      // 复制父进程全部环境变量
      const childEnv = { ...process.env };
      // 删除继承过来的主程序PORT，子项目会读取自身.env的PORT=3000
      delete childEnv.PORT;

      const childProc = spawn(execBin, execArgs, {
        cwd: project.workDir,
        detached: true,
        stdio: ["ignore", "pipe", "pipe"],
        env: childEnv, // 传入清理后的环境变量
      });
      childProc.unref();

      // 打印日志不变
      childProc.stdout.on("data", (data) => {
        console.log(`【子项目${project.title}日志】${data.toString()}`);
      });
      childProc.stderr.on("data", (errData) => {
        console.error(`【子项目${project.title}错误】${errData.toString()}`);
      });
      childProc.on("close", (code) => {
        console.warn(`【子项目${project.title}进程退出，退出码：${code}`);
        if (fs.existsSync(lockPath)) fs.unlinkSync(lockPath);
      });

      fs.writeFileSync(lockPath, childProc.pid.toString(), "utf-8");

      await new Promise((resolve) => setTimeout(resolve, 500));
      const stillAlive = await this.#getProjectRunStatus(project);
      if (!stillAlive) {
        if (fs.existsSync(lockPath)) fs.unlinkSync(lockPath);
        return fail(res, "项目启动后立刻闪退，请查看后端控制台日志");
      }

      project.status = "active";
      await project.save();
      return success(res, null, "项目启动成功");
    } catch (err) {
      console.error("【启动接口完整错误堆栈】", err);
      return fail(res, err.message || "项目启动失败");
    }
  }

  // 停止项目
  async stop(req, res) {
    try {
      const { id } = req.params;
      const project = await projectsService.findById(id);
      if (!project) return fail(res, "项目不存在");

      const lockPath = path.join(project.workDir, ".running.lock");
      if (!fs.existsSync(lockPath)) return fail(res, "项目当前未运行");

      // 读取PID
      const pid = fs.readFileSync(lockPath, "utf-8").trim();
      // Windows强制杀死进程
      execSync(`taskkill /F /PID ${pid}`, { encoding: "utf-8" });
      // 删除锁文件
      fs.unlinkSync(lockPath);

      project.status = "stopped";
      await project.save();
      return success(res, null, "项目已停止");
    } catch (err) {
      console.error("【停止接口完整错误堆栈】", err);
      return fail(res, err.message || "停止项目失败");
    }
  }

  // 重启项目
  async restart(req, res) {
    try {
      const { id } = req.params;
      const project = await projectsService.findById(id);
      if (!project) return fail(res, "项目不存在");

      // 1、调用内部停止逻辑，不传入res，不会触发success/fail发送响应
      const stopOk = await this.#stopInner(id);
      if (!stopOk) {
        return fail(res, "停止旧进程失败，无法执行重启");
      }
      // 等待端口完全释放
      await new Promise((resolve) => setTimeout(resolve, 800));
      // 2、调用内部启动逻辑
      const startOk = await this.#startInner(id);
      if (!startOk) {
        return fail(res, "停止成功，但新项目启动失败，请查看控制台");
      }
      // 仅此处统一返回一次响应给前端
      return success(res, null, "项目重启完成");
    } catch (err) {
      console.error("【重启接口完整错误堆栈】", err);
      return fail(res, err.message || "重启项目失败");
    }
  }

  /** 注释保留的删除/查询/更新接口，逻辑不变无需改动
  // 【API接口用】删除单一项目（软删）,返回JSON给前端ajax
  async deleteProject(req, res) {
    try {
      const { id } = req.params;
      const deleteProjectData = await projectsService.deleteById(id);
      return success(res, deleteProjectData, "删除成功");
    } catch (err) {
      return fail(res, err);
    }
  }

  // 【页面模板渲染专用】删除唯一项目（软删）,只处理，返回处理结果通知
  async deleteProjectData(req) {
    try {
      const { id } = req.params;
      const data = await projectsService.deleteById(id);
      return {
        type: 1,
        msg: "删除成功",
        data: data,
      };
    } catch (err) {
      return {
        type: -1,
        msg: err.message || "删除项目失败，请检查填写数据",
        error: err,
      };
    }
  }

  // 【API接口用】根据ID查询,返回JSON给前端ajax
  async getOneProjectById(req, res) {
    try {
      const getOneProjectData = await projectsService.findById(req.params.id);
      return success(res, getOneProjectData, "查找成功");
    } catch (err) {
      return fail(res, err);
    }
  }

  // 【页面模板渲染专用】根据ID查询,返回结果
  async getOneProjectByIdData(id) {
    try {
      const data = await projectsService.findById(id);
      return {
        type: 1,
        msg: "查询成功",
        data: data,
      };
    } catch (err) {
      return {
        type: -1,
        msg: err.message || "根据ID查找失败，请检查填写数据",
        error: err,
      };
    }
  }

  // 【API接口用】更新单一账目，返回JSON给前端ajax
  async updateProjectById(req, res) {
    try {
      const { id } = req.params;
      const updateProjectData = await projectsService.updateById(id, req.body);
      return success(res, updateProjectData, "更新成功");
    } catch (err) {
      return fail(res, err);
    }
  }

  // 【页面模板渲染专用】更新唯一账目
  async updateProjectByIdData(id, updateObject) {
    try {
      const data = await projectsService.updateById(id, updateObject);
      return {
        type: 1,
        msg: "更新账目成功",
        data: data,
      };
    } catch (err) {
      return {
        type: -1,
        msg: err.message || "更新账目失败，请检查填写数据",
        error: err,
      };
    }
  }
 */
}

module.exports = new ProjectsController();
