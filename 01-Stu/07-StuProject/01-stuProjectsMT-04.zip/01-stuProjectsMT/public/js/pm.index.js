//引入心跳执行模块并获取服务器地址参数
import { createHttpHeartbeat } from "./http-heartbeat.js";

// 全局环境变量，从reg.auth.ejs页面注入，统一配置
const GLOBAL_ENV = window.GLOBAL_ENV || {};

// DOM
const serverStatus = document.getElementById("serverStatus");

// 页面加载初始化
window.onload = async function () {
  // 绑定所有启停按钮事件
  bindOperateBtn();
  // 心跳检测
  checkServerConnection();
};

// 绑定卡片启动/停止/重启按钮点击事件
function bindOperateBtn() {
  // 启动按钮
  document.querySelectorAll(".start-btn").forEach((btn) => {
    btn.onclick = async (e) => {
      e.stopPropagation();
      const pid = btn.closest(".project-card").dataset.pid;
      try {
        const res = await fetch(`/projects/start/${pid}`, { method: "POST" });
        const data = await res.json();
        alert(`✅ ${data.msg}，3秒后自动刷新页面查看状态，请等待端口监听完成`);
        setTimeout(() => window.location.reload(), 3000);
      } catch (err) {
        console.error("启动接口请求异常", err);
        alert("❌ 请求失败：服务端异常，请查看控制台日志");
      }
    };
  });

  // 停止按钮
  document.querySelectorAll(".stop-btn").forEach((btn) => {
    btn.onclick = async (e) => {
      e.stopPropagation();
      const pid = btn.closest(".project-card").dataset.pid;
      try {
        const res = await fetch(`/projects/stop/${pid}`, { method: "POST" });
        const data = await res.json();
        alert(`✅ ${data.msg}`);
        window.location.reload();
      } catch (err) {
        console.error("停止接口请求异常", err);
        alert("❌ 请求失败：服务端异常，请查看控制台日志");
      }
    };
  });

  // 重启按钮同理，弹窗延时8000
  document.querySelectorAll(".restart-btn").forEach((btn) => {
    btn.onclick = async (e) => {
      e.stopPropagation();
      const pid = btn.closest(".project-card").dataset.pid;
      try {
        const res = await fetch(`/projects/restart/${pid}`, {
          method: "POST",
        });
        const data = await res.json();
        alert(`✅ ${data.msg}，3秒后自动刷新页面同步状态`);
        setTimeout(() => window.location.reload(), 3000);
      } catch (err) {
        console.error("重启接口请求异常", err);
        alert("❌ 请求失败：服务端异常，请查看控制台日志");
      }
    };
  });
}

// 心跳检测
async function checkServerConnection() {
  createHttpHeartbeat({
    url: GLOBAL_ENV.HEARTBEAT_REDIRECT_URL,
    interval: GLOBAL_ENV.HEARTBEAT_INTERVAL,
    timeout: GLOBAL_ENV.HEARTBEAT_TIMEOUT,
    maxFailures: GLOBAL_ENV.MAX_HEARTBEAT_FAIL,
    onSuccess: () => {
      serverStatus.innerHTML =
        '<i class="fas fa-circle" style="color: #28a745; font-size: 0.6rem;"></i> Connecting';
    },
    onFailure: () => {
      serverStatus.innerHTML =
        '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
    },
    onError: () => {
      serverStatus.innerHTML =
        '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
    },
  });
}

// 退出登录
window.logout = function logout() {
  if (confirm("确定要退出登录吗？")) {
    // 清空旧版本地存储
    localStorage.removeItem("authToken");
    localStorage.removeItem("userInfo");
    localStorage.removeItem("rememberMe");
    sessionStorage.removeItem("isLoggedIn");
    // 跳转登出接口
    window.location.href = GLOBAL_ENV.LOGOUT_REDIRECT_URL;
  }
};
