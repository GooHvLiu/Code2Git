## 07-学习项目

### stuProjects

#### 项目需求

##### 基本需求

* 创建数据库保存登录信息
* 将学习各个平台的封装到同一个项目中
* 通过登录选择进入某一个学习平台界面
* 后台使用MEN（MongoDB+Express+Node.js）创建
* 后端Node.js + Express + MongoDB + JWT认证流程实现
* 前端:
  * 前期使用HTML+CSS+JavaScript创建，通过 **HTTPS**（或局域网内的安全传输）将明文密码发送给后端
  * 后期使用MEVN（MongoDB+Express+Vue+Node.js）创建

##### 掌握技能

* express基本使用与环境搭建
* 环境变量设置与调用
* MongoDB的基本使用
* MD5加密基本使用
* API接口设置与测试
* Cookie/Session/Taken基本使用

#### 架构搭建

##### 安装依赖

###### 框架模板

通过generator应用生成器工具 `express-generator` 可以快速创建一个应用的骨架，首先全局安装应用生成器工具 `express-generator` ：

```cmd
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject> npm i -g express express-generator
npm warn deprecated mkdirp@0.5.1: Legacy versions of mkdirp are no longer supported. Please update to mkdirp 1.x. (Note that the API surface has changed to use Promises in 1.x.)

changed 77 packages in 2s

24 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject> 
```

###### 创建项目

通过express -e命令生成新项目文件夹，系统会基于express-generator工具自动将基本依赖包安装好：

```bash
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject> express -e stuProjectsMT

  warning: option `--ejs' has been renamed to `--view=ejs'


   create : stuProjectsMT\
   create : stuProjectsMT\public\
   create : stuProjectsMT\public\javascripts\
   create : stuProjectsMT\public\images\
   create : stuProjectsMT\public\stylesheets\
   create : stuProjectsMT\public\stylesheets\style.css
   create : stuProjectsMT\routes\
   create : stuProjectsMT\routes\index.js
   create : stuProjectsMT\routes\users.js
   create : stuProjectsMT\views\
   create : stuProjectsMT\views\error.ejs
   create : stuProjectsMT\views\index.ejs
   create : stuProjectsMT\app.js
   create : stuProjectsMT\package.json
   create : stuProjectsMT\bin\
   create : stuProjectsMT\bin\www

   change directory:
     > cd stuProjectsMT

   install dependencies:
     > npm install

   run the app:
     > SET DEBUG=stuprojectsmt:* & npm start

PS F:\CodingMan\Code2Git\01-Stu\07-StuProject> 
```

> 项目名称更改为01-stuProjectMT

###### 解决跨域

- cors解决浏览器跨域请求问题
- cors允许前端应用从不同域名访问你的 API

```bash
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i cors

added 56 packages in 1s

1 package is looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT>
```

> 在app.js中使用cors
>
> ```js
> ...
> var express = require("express");
> const cors = require("cors");
> ...
> //全域开启跨域
> app.use(cors());
> ...
> ```

###### 自动构建

nodemon包适用于node.js环境下修改代码自动更新，无需手动再次启动服务

```js
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i nodemon

added 28 packages in 1s

6 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> 
```

> - 修改package.json,实现修改后自动重新服务
>
> ```json
> "start": "node ./bin/www"
> 修改为：
> "start": "nodemon ./bin/www"
> ```
>
> - 启动服务
>
> ```bash
> > npm start
> > 客户端打开http://127.0.0.1:3000
> ```

###### 变量加载

为了将基本变量统一进行管理，在项目根目录下创建.env文件用于项目变量的存储，env文件的内容基本如下：

```env
# ============================================
# 服务器配置
# process.env.LISTEN_AREA: 用于设定是否在本地使用还是局域网内使用
# ============================================
PORT=3000
LISTEN_AREA=0.0.0.0
NODE_ENV=development
SERVER_IP=http://${LOCAL_IP}:${PORT}

# ============================================
# 局域网IP
# 自动获取的局域网IP（由 setup-env.js 自动更新）
# ============================================
LOCAL_IP=172.29.32.1

# ============================================
# 数据库配置
# ============================================
MONGODB_DBHOST=${LOCAL_IP}
MONGODB_DBPORT=27017
MONGODB_DBNAME=expressTest4Demo
MONGODB_USER=
MONGODB_PASSWORD=
MONGODB_POOL_SIZE=10
MONGODB_TIMEOUT=5000
EXIT_ON_DB_ERROR=true

# ============================================
# CORS 配置
# ============================================
CORS_ORIGINS=["http://localhost:3000","http://localhost:8080"]
```

dotenv 是一个 Node.js 的 npm 包，它的唯一作用就是：把 .env 文件里的变量加载到 process.env 对象中，每个后端服务器都有自己的环境配置等信息，可以使用dotenv包进行管理和加载。

安装 dotenv非常简单，按照以下步骤操作即可。

```cmd
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i dotenv

added 1 package in 773ms

7 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT>  
```

> 安装好后，就可以通过创建.env文件，并在www或其他服务文件下导入即可使用。
>
> dotenv 默认不支持变量引用，若想使用变量引用，需要安装变量增强工具包
>
> > SERVER_IP=http://${LOCAL_IP}:${PORT}
> >
> > LOCAL_IP=192.168.10.148
> >
> > process.env.SERVER_IP      // "http://${LOCAL_IP}:${PORT}"  (字面量，不会解析)

###### 变量增强

dotenv 默认不支持变量引用，若想使用变量引用，需要安装变量增强工具包dotenv-expand，具体安装方式如下：

```bash
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i dotenv-expand

added 1 package in 763ms

8 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> 
```

###### 文件操作

因为涉及到对env文件的写入操作，所以需要fs依赖的安装。

```bash
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i fs

added 1 package in 800ms

8 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> 
```

###### 数据库包

该项目统一使用MongoDB进行数据管理。

MongoDB需要使用mongoose包进行管理

```cmd
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i mongoose

added 18 packages in 2s

9 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT>
```

###### 加解密包

密码保存/密码对比需要进行加密和解密工作，此项目使用bcryptjs包：

```js
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i bcryptjs

added 1 package in 791ms

9 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT>  
```

###### 路径混乱

moduleAliases是第三方库，可以配置package.json后实现路径引用问题，具体安装方式如下：

```bash
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i module-alias

added 1 package in 775ms

9 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> 
```

> * 路径映射
>   * package.json配置如下：
>
> ```json
> "_moduleAliases": {
>     "@bin": "./bin",
>     "@middleware": "./middleware",
>     "@public": "./public",
>     "@routes": "./routes",
>     "@views": "./views",
>     "@MongoDB": "./src/database/MongoDBV2dot1"
>   }
> ```
>
> * 引用路径
>   * 按照如下方式使用：
>
> ```js
> const expend = require("@middleware/listenExpend.js");
> ```

###### 签发校验

`jsonwebtoken` 是 Node.js 最主流 JWT 签发 / 校验库，用于**无状态登录鉴权**，项目里登录生成 token、`authMiddleware` 校验 token 全依赖它。

```js
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i jsonwebtoken

added 13 packages in 930ms

9 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT>
```

> 此为token模式

```js
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i express-session

up to date in 905ms

11 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> 
```

> 此为Session模式，该项目因为采用ejs，所以只能使用session模式

###### 时间格式

**Day.js** 是一个**极简、快速、2KB**的 JavaScript 日期处理库，专为现代浏览器和 Node.js 环境设计。本案例针对于数据库存储的关于时间戳的转换为可视化的格式。

```bash
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm install dayjs

added 1 package in 1s

9 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> 
```

> 项目引入:const dayjs = require('dayjs');

核心使用语法及案例如下：

```js
// 1. 当前时间
const now = dayjs()

// 2. ISO/标准字符串
dayjs('2026-06-19')
dayjs('2026-06-19 20:30:15')
dayjs('2026-06-19T20:30:15+08:00')

// 3. 毫秒时间戳（13位）
dayjs(1781890215000)

// 4. 原生 Date 对象
dayjs(new Date())

// 5. 数组 [年,月(0开始),日,时,分,秒]
dayjs([2026, 5, 19]) // 6月19日（月份0=1月）

// 6. 以下为格式化常用语法
const d = dayjs('2026-06-19 08:05:09')
d.format() // 默认ISO：2026-06-19T08:05:09+08:00
d.format('YYYY-MM-DD') // 2026-06-19
d.format('YYYY年MM月DD日 HH:mm:ss') // 2026年06月19日 08:05:09
d.format('x') // 毫秒时间戳 1781890215000
d.format('X') // 秒级时间戳 1781890215
```

###### 会话控制

在express架构上使用session会话控制，需要安装两个依赖包，分别为express-session connect-mongo，安装方式如下：

```bash
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i express-session connect-mongo

added 14 packages in 1s

11 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> 
```

> 具体使用方式如下:
>
> ```js
> const session = require("express-session");
> //V5/v6新版标准写法
> const MongoStore = require("connect-mongo").default;
> ......
> // 4. 设置 session 的中间件
> app.use(
> session({
>  //设置cookie的name，默认值是：connect.sid
>  name: "sid",
>  //参与加密的字符串（又称签名），加盐
>  secret: "atguigu",
>  //是否为每次请求都设置一个cookie用来存储session的id
>  saveUninitialized: false,
>  //是否在每次请求时重新保存session，生命周期,生产环境建议改为 false，减少数据库频繁写入
>  resave: true,
>  //数据库的连接配置
>  store: MongoStore.create({
>    mongoUrl: MONGOURL,
>  }),
>  cookie: {
>    // 开启后前端无法通过 JS 操作
>    httpOnly: true,
>    // 这一条 是控制 sessionID 的过期时间的,1000 *300 = 300秒 =5min
>    maxAge: 1000 * 300,
>  },
> }),
> );
> 
> // 5.1 创建 session
> app.get("/login", (req, res) => {
> //假定用户名和密码都是admin，浏览器访问：http://127.0.0.1:3000/login?username=admin&password=admin
> if (req.query.username === "admin" && req.query.password === "admin") {
>  req.session.username = "zhangsan";
>  req.session.email = "zhangsan@qq.com";
>  res.send("登录成功");
> } else {
>  res.send("登录失败");
> }
> });
> 
> // 5.2 获取 session
> app.get("/cart", (req, res) => {
> if (req.session.username) {
>  res.send(`购物车页面，欢迎您${req.session.username}`);
> } else {
>  res.send(`${req.session.username}还没有登录`);
> }
> });
> 
> // 5.3 销毁 session
> app.get("/logout", (req, res) => {
> //销毁session
> // res.send('设置session');
> req.session.destroy((err) => {
>  if (err) return res.send("退出失败");
>  res.clearCookie("sid"); // 手动清除浏览器sid cookie，彻底失效
>  res.send("成功退出");
> });
> });
> ```

###### 端口释放

日常开发会出现端口被占用的情况，处理起来比较麻烦，可以通过如下依赖包快速释放端口：

```bash
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i -g kill-port

changed 3 packages in 882ms
```

> * 手动清理
>   * 在项目中可以通过`kill-port 3000`释放端口
>
> * 自动清理
>   * 启动脚本增加自动清理，package.json 配置：
>
> ```json
> "scripts": {
>   "dev": "kill-port 3000 && node app.js"
> }
> ```
>
> > node app.js可以替换为实际的启动文件

##### 架构增强

架构增强主要是针对bin/www和根目录文件执行的，最终封装为类进行引入使用。拷贝01-myAccounts/middleware到该项目根目录下。

###### 新建脚本

拷贝01-myAccounts/.env和01-myAccounts/.env.example到该项目根目录下并定制化修改，核心参数如下：

```env
# ============================================
# 服务器配置
# process.env.LISTEN_AREA: 用于设定是否在本地使用还是局域网内使用
# ============================================
PORT=1234
LISTEN_AREA=0.0.0.0
NODE_ENV=development
SERVER_IP=http://${LOCAL_IP}:${PORT}

# ============================================
# 局域网IP
# 自动获取的局域网IP（由 setup-env.js 自动更新）
# ============================================
LOCAL_IP=172.23.64.1

# ============================================
# MONGODB数据库配置
# ============================================
MONGODB_DBHOST=${LOCAL_IP}
MONGODB_DBPORT=27017
MONGODB_DBNAME=stuProjects4mt
MONGODB_USERCOLLECTION=users
MONGODB_USER=
MONGODB_PASSWORD=
MONGODB_POOL_SIZE=10
MONGODB_TIMEOUT=5000
EXIT_ON_DB_ERROR=true

# ============================================
# 登录鉴权、跳转相关
# ============================================
REDIRECT_WAITTIME=3000
LOGIN_REDIRECT_URL =/auth/login
REGISTER_REDIRECT_URL=/auth/reg
PROJECTSLIST_REDIRECT_URL=/myProjects
UNAUTH_CODE = 401
UNAUTH_MSG = 登录已失效，请重新登录

# ============================================
# JWT 配置
# JWT_EXPIRES 合法过期时间：s秒 m分 h时 d天
# ============================================
JWT_SECRET=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWUsImlhdCI6MTUxNjIzOTAyMiwianRpIjoiODAwN2QwOGItMzMzYi00MmFjLTgyYzktOTY2MDliNDU1NWNmIn0.MgSCWHLfQfq2tV8DR1nvk0QZsERX-gbSXTrxMKQFERI9iwPHCWVZ4TdAeG_X8ghJFYsxZ3DvrP87GID1VvDgARre2PMNRR2LN0wcwvz0tOXSpKl9mlYu2Le_4RE8NiAQidz_KW4zLb1hn4zT3pz4xO7tUzEKP-JUNzxJdgVCW1flH_ms9l9pDJcBIHtah-Qag2NyO8kQ-fPXHIS0fWmjUyNGfyNKjcITOkojRsmS_eCM9xPtocLjHkKS2xHb50Q71rJWtO0JjF8JNwj9e85k68ptt8im51va1CjtplEiV28yLrgDm4HhyW2OyPqhyvDS2_Z8XMRQNTj7OzjJ3FEN7A
JWT_REFRESH_SECRET=eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJEaW5vQ2hpZXNhLmdpdGh1Yi5pbyIsInN1YiI6InNoZW5pcXVhIiwiYXVkIjoibmF0YWxpYSIsImlhdCI6MTc4MjEyNzQxOCwiZXhwIjoxNzgyMTI4MDE4LCJwcm9wWCI6MTcxNTd9.HwKE8r18zYjZvBHLA-MHhSwfZ228rLT0wZ105Gz1_tM3OKrwqNOX36BjQlo4fTVFH18AKBM4CT6WZB5GTW5cVC8mq39ireJiGXqmLxzJTQsZ9x71QTDqlEQBKnMM3chC93TQth7WVGpU05U8s7b75MB1RyPGuGi3eF5i7UERe9ENsPDrj5hvx9tkLzLItBlSLxYuM-5XXYEjVynT5XmZfH5WTUg42a68xzCLPScjlG_8au-72Fwaz4nnNCPVTwX9es1_3x4Hv5MZvWBCgFkiy7YVUidJckQx23Nf5QANWinC3lPrZ3LQHMQlRKkZW1KLRY2UUwmqMiIf4iyFraSk_Q
JWT_EXPIRES=2h
JWT_AUTH_HEADER_KEY=authorization
JWT_AUTH_PREFIX=Bearer

# ============================================
# CORS 配置
# ============================================
CORS_ORIGINS=["http://localhost:3000","http://localhost:8080"]


```

###### 变量加载

在www启动文件内引用变量加载和变量增强依赖包，后续文件直接可以调用环境变量设置内的值。

```js
require("dotenv-expand").expand(require("dotenv").config());
```

###### 自动构建

将在根目录创建modemon.json用于确定追踪文件夹清单：

```json
{
  "watch": ["src", "routes", "bin", "middleware", "public", "views"],
  "ignore": ["ldb.json", "src/**/**/*.json"],
  "exec": "node ./bin/www"
}

```

###### 配置路径

为了解决路径混乱问题，在package.json下配置如下路径：

```json
  "_moduleAliases": {
    "@bin": "./bin",
    "@middleware": "./middleware",
    "@public": "./public",
    "@routes": "./routes",
    "@views": "./views",
    "@MongoDB": "./src/MongoDBV2dot2"
  }
```

> * 拷贝MongoDB标准模板到“./src/MongoDBV2dot2”下
> * www启动文件下，引用依赖包，后续都可以直接使用：
>
> ```js
> require("module-alias/register");
> ```

###### 配置脚本

在项目启动前进行对网络的检查与显示，并对env文件的写入动作，实现服务器启动即显示相关信息。修改package.json文件，将middleware/dotenvInit.js在项目www启动前启动，使用npm命令，仅启动一次即可：

```json
"scripts": {
    "init": "node ./middleware/dotenvInit.js",
    "start": "node ./bin/www"
  }
```

###### 端口释放

在项目启动前对需要的端口进行释放操作，并进一步优化start命令：

```json
"scripts": {
    "kPort": "kill-port 3000",
    "init": "npm run kPort && node ./middleware/dotenvInit.js",
    "start": "npm run init && nodemon ./bin/www"
  },
```

###### 增强监听

其中包括：优雅关闭服务器、调试及提示信息、请求超时配置、服务器错误增强，将其在www文件下引用并使用：

```js
const expend = require("@middleware/listenExpend.js");
......
function onError(error) {
  //新增：错误提示增强
  expend.serverOnError(error, port);
}
function onListening() {
  var addr = server.address();
  var bind = typeof addr === "string" ? "pipe " + addr : "port " + addr.port;
  debug("Listening on " + bind);
  // 新增：优雅关闭处理
  expend.setupGracefulShutdown(server);
  //新增：调试及提示窗口
  expend.debugMsg(addr);
  //新增: 请求超时
  expend.serverSetTimeOut(server);
}
```

###### 解决跨域

在app.js中引入跨域解决依赖包：

```js
const cors = require("cors");
app.use(cors());
```

###### 上线服务

重新设计端口号，与其他服务不同即可，修改www文件如下所示。

```js
var port = normalizePort(process.env.PORT || "1234");
 server.listen(port, "0.0.0.0");
```

###### 多余文件

将routes/users.js删除，只保留index.js用于后续操作，更改app.js对users.js的引用和使用：
```js
//删除以下两行
app.use('/users', usersRouter);
var usersRouter = require('./routes/users');
```

>  将public下更改为js和css文件，并删除其文件夹内部文件，将创建favicon.ico文件。

###### 项目启动

正式启动项目，项目展示信息如下：

```bash'
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm start

> stuprojectsmt@0.0.0 start
> npm run init && nodemon ./bin/www


> stuprojectsmt@0.0.0 init
> npm run kPort && node ./middleware/dotenvInit.js


> stuprojectsmt@0.0.0 kPort
> kill-port 3000

Process on port 3000 killed
🔧 开始配置环境变量...
🌐 检测到局域网IP: 172.23.64.1
✅ .env 文件已更新: F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT\.env
✅ 环境变量配置完成！
💡 LOCAL_IP = 172.23.64.1
[nodemon] 3.1.14
[nodemon] to restart at any time, enter `rs`
[nodemon] watching path(s): src\**\* routes\**\* bin\**\* middleware\**\* public\**\* views\**\*
[nodemon] watching extensions: js,mjs,cjs,json
[nodemon] starting `node ./bin/www ./bin/www`
◇ injected env (26) from .env // tip: ⌘ custom filepath { path: '/custom/path/.env' }

==================================================
🚀 Server Startup Successful!
==================================================
📡 Environment: development
📡 Ports: 1234
📡 Process ID: 29024
📡 SERVER IP: 172.23.64.1

📍 Access Address:
   • Local Address:    http://localhost:1234
   • Local IP:    http://172.23.64.1:1234
GET / 200 8.391 ms - 207
GET /stylesheets/style.css 200 2.351 ms - 111
```

##### 数据引用

在app.js文件中引入并创建数据库连接：

```js
// 引入数据库连接库
const dbConnect = require("@MongoDB/config/db.js");
// 异步自执行函数：等待数据库连接成功后再加载路由
(async () => {
  try {
    await dbConnect();
  } catch (error) {
    console.log("主程序获取连接错误：" + error);
    process.exit(1);
  }
})();
```

> 数据库使用【MongoDBV2dot2_01.zip】
>
> 启动项目后显示如下：
>
> ```bash
> 📍 Access Address:
>    • Local Address:    http://localhost:1234
>    • Local IP:    http://192.168.43.190:1234
> MongoDB Connected Succes. Connecting to: 192.168.43.190:27017
> ```

##### 静态资源

###### 指引文件

美化error.ejs，error.ejs，存在msg/error.stack/error.status/url参数，修改app.js代码：

```js
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render("error", {
    msg: err.message,
    error: err,
    url: "/",
  });
});
```

###### 数据拷贝

* css/js文件放入public/js和public/css文件夹内
* ejs文件放入views文件夹内

修改app.js文件和路由文件：

```js
var webMainRouter = require("@routes/web/webMainRoute.pm.js");
app.get("/", (req, res) => res.redirect("/projects"));
app.use("/projects", webMainRouter);
```

#### 基本功能

##### 注登展示

###### 设置路由

创建webAuthRoute.js，并在app.js中引入并设置：

```js
const webMainRouter = require("@routes/web/webMainRoute.pm.js");
const webAuthRouter = require("@routes/web/webAuthRoute.js");
app.use("/projects", webMainRouter);
app.use("/auth", webAuthRouter);
```

> 注册登录前缀为/auth

###### 创建路由

webAuthRoute.js中添加两个路由，具体如下：

```js
//GET IP:PORT/auth/reg 注册页面
authRouter.get("/reg", function (req, res, next) {
  res.render("reg.auth.ejs");
});

//GET IP:PORT/auth/login 登录页面
authRouter.get("/login", function (req, res, next) {
  res.render("login.auth.ejs");
});
```

###### 创建页面

创建静态页面reg.auth.ejs和login.auth.ejs，在此不做更细讲解。请注意，由于使用ejs模式，所有静态页面采用post发送请求模式。

##### 心跳检查

###### 标准模块

将public/js/http-heartbeat.js移栽到该项目目录下。

```js
/**
 * HTTP 心跳检测模块
 * 使用方式：
 *   import { createHttpHeartbeat, updateServerStatus } from './http-heartbeat.js';
 */

/**
 * 创建 HTTP 心跳检测实例
 * @param {Object} options - 配置选项
 * @param {string} options.url - 心跳接口地址（必填）
 * @param {number} [options.interval=30000] - 心跳间隔（毫秒），默认 30 秒
 * @param {number} [options.timeout=10000] - 超时时间（毫秒），默认 10 秒
 * @param {number} [options.maxFailures=3] - 最大失败次数，默认 3 次
 * @param {string} [options.method='GET'] - 请求方法，默认 GET
 * @param {Object} [options.headers={}] - 请求头
 * @param {Object} [options.body=null] - 请求体（仅 POST/PUT 有效）
 * @param {boolean} [options.autoStart=true] - 是否自动启动心跳
 * @param {Function} [options.onSuccess] - 心跳成功回调 (data, response)
 * @param {Function} [options.onFailure] - 心跳失败回调 (error)
 * @param {Function} [options.onError] - 心跳错误回调 (error, failureCount)
 * @param {Function} [options.onReconnect] - 重连成功回调
 * @returns {Object} - HTTP 心跳实例
 */
export function createHttpHeartbeat(options = {}) {
  const {
    url,
    interval = 30000,
    timeout = 10000,
    maxFailures = 3,
    method = "GET",
    headers = {},
    body = null,
    autoStart = true,
    onSuccess = null,
    onFailure = null,
    onError = null,
    onReconnect = null,
  } = options;

  // 验证必填参数
  if (!url) {
    throw new Error("[HTTP Heartbeat] URL is required");
  }

  let timer = null;
  let failureCount = 0;
  let successCount = 0;
  let isRunning = false;
  let lastResponse = null;
  let lastError = null;

  /**
   * 启动心跳检测
   */
  function start() {
    if (isRunning) {
      console.warn("[HTTP Heartbeat] 心跳检测已在运行中");
      return;
    }

    console.log("🚀 [HTTP Heartbeat] 启动心跳检测...");
    isRunning = true;
    failureCount = 0;
    sendHeartbeat();
  }

  /**
   * 停止心跳检测
   */
  function stop() {
    if (!isRunning) {
      console.warn("[HTTP Heartbeat] 心跳检测未运行");
      return;
    }

    console.log("🛑 [HTTP Heartbeat] 停止心跳检测...");
    if (timer) {
      clearTimeout(timer);
      timer = null;
    }
    isRunning = false;
    failureCount = 0;
  }

  /**
   * 发送心跳请求
   */
  async function sendHeartbeat() {
    if (!isRunning) return;

    try {
      console.log("💓 [HTTP Heartbeat] 发送心跳请求...");

      // 创建 AbortController 用于超时控制
      const controller = new AbortController();
      const timeoutId = setTimeout(() => {
        controller.abort();
      }, timeout);

      // 构建请求配置
      const fetchOptions = {
        method: method.toUpperCase(),
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          ...headers,
        },
      };

      // 如果是 POST/PUT/DELETE，添加 body
      if (["POST", "PUT", "DELETE"].includes(method.toUpperCase())) {
        fetchOptions.body = body ? JSON.stringify(body) : null;
      }

      // 发送请求
      const response = await fetch(url, fetchOptions);
      clearTimeout(timeoutId);

      // 检查 HTTP 状态码
      if (!response.ok) {
        throw new Error(`HTTP ${response.status} ${response.statusText}`);
      }

      // 解析响应数据
      const data = await response.json();
      lastResponse = data;
      successCount++;
      failureCount = 0;

      console.log("✅ [HTTP Heartbeat] 心跳成功", data);

      // 触发成功回调
      if (typeof onSuccess === "function") {
        onSuccess(data, response);
      }

      // 如果之前失败过，现在成功了，触发重连回调
      if (failureCount === 0 && successCount > 1) {
        if (typeof onReconnect === "function") {
          onReconnect(data);
        }
      }
    } catch (error) {
      failureCount++;
      lastError = error;

      console.error(
        `❌ [HTTP Heartbeat] 心跳失败 (${failureCount}/${maxFailures}):`,
        error.message,
      );

      // 触发错误回调
      if (typeof onError === "function") {
        onError(error, failureCount);
      }

      // 达到最大失败次数
      if (failureCount >= maxFailures) {
        console.error("🚨 [HTTP Heartbeat] 连接断开，达到最大失败次数");

        // 触发失败回调
        if (typeof onFailure === "function") {
          onFailure(error);
        }

        // 停止心跳
        stop();
        return;
      }
    } finally {
      // 如果还在运行，设置下一次心跳
      if (isRunning) {
        timer = setTimeout(sendHeartbeat, interval);
      }
    }
  }

  /**
   * 手动触发一次心跳
   */
  function trigger() {
    if (!isRunning) {
      console.warn("[HTTP Heartbeat] 心跳检测未运行，无法手动触发");
      return;
    }

    console.log("🔄 [HTTP Heartbeat] 手动触发心跳...");
    if (timer) {
      clearTimeout(timer);
    }
    sendHeartbeat();
  }

  /**
   * 获取当前状态
   */
  function getStatus() {
    return {
      isRunning,
      failureCount,
      successCount,
      lastResponse,
      lastError,
      url,
      interval,
      timeout,
      maxFailures,
    };
  }

  /**
   * 重置失败计数
   */
  function resetFailures() {
    failureCount = 0;
    console.log("[HTTP Heartbeat] 失败计数已重置");
  }

  // 自动启动
  if (autoStart) {
    start();
  }

  // 返回公共 API
  return {
    start,
    stop,
    trigger,
    resetFailures,
    getStatus,
    getFailureCount: () => failureCount,
    getSuccessCount: () => successCount,
    getLastResponse: () => lastResponse,
    getLastError: () => lastError,
    isRunning: () => isRunning,
    isConnected: () => isRunning && failureCount === 0,
  };
}

/**
 * 更新服务器状态显示
 * @param {string|HTMLElement} element - 状态显示元素或选择器
 * @param {boolean} isConnected - 是否连接成功
 * @param {Object} [options] - 配置选项
 * @param {string} [options.successText='Connection Successful'] - 连接成功文本
 * @param {string} [options.failureText='Connection Failed'] - 连接失败文本
 * @param {string} [options.connectingText='Connecting...'] - 连接中文本
 */
export function updateServerStatus(element, isConnected, options = {}) {
  const {
    successText = "Connection Successful",
    failureText = "Connection Failed",
    connectingText = "Connecting...",
  } = options;

  // 获取 DOM 元素
  let statusElement;
  if (typeof element === "string") {
    statusElement = document.querySelector(element);
  } else {
    statusElement = element;
  }

  if (!statusElement) {
    console.warn("[HTTP Heartbeat] 未找到状态显示元素:", element);
    return;
  }

  // 根据连接状态更新显示
  if (isConnected) {
    // 连接成功 - 绿色
    statusElement.innerHTML = `
      <i class="fas fa-circle" style="color: #28a745; font-size: 0.6rem; margin-right: 5px;"></i>
      ${successText}
    `;
    statusElement.style.color = "#28a745";
  } else {
    // 连接失败 - 黄色/红色
    statusElement.innerHTML = `
      <i class="fas fa-circle" style="color: #dc3545; font-size: 0.6rem; margin-right: 5px;"></i>
      ${failureText}
    `;
    statusElement.style.color = "#dc3545";
  }
}

/**
 * 创建带状态显示的 HTTP 心跳实例（快捷方式）
 * @param {Object} options - 配置选项
 * @param {string} options.url - 心跳接口地址
 * @param {string} options.statusElement - 状态显示元素选择器
 * @param {Object} [options.heartbeatOptions] - createHttpHeartbeat 的其他选项
 * @returns {Object} - HTTP 心跳实例
 */
export function createHttpHeartbeatWithStatus(options = {}) {
  const { url, statusElement, heartbeatOptions = {} } = options;

  if (!url) {
    throw new Error("[HTTP Heartbeat] URL is required");
  }

  if (!statusElement) {
    throw new Error("[HTTP Heartbeat] statusElement is required");
  }

  // 创建心跳实例
  const heartbeat = createHttpHeartbeat({
    url,
    ...heartbeatOptions,
    onSuccess: (data, response) => {
      updateServerStatus(statusElement, true);
      // 调用用户自定义的 onSuccess
      if (typeof heartbeatOptions.onSuccess === "function") {
        heartbeatOptions.onSuccess(data, response);
      }
    },
    onFailure: (error) => {
      updateServerStatus(statusElement, false);
      // 调用用户自定义的 onFailure
      if (typeof heartbeatOptions.onFailure === "function") {
        heartbeatOptions.onFailure(error);
      }
    },
    onError: (error, failureCount) => {
      // 如果是第一次失败，显示警告状态
      if (failureCount === 1) {
        const statusEl =
          typeof statusElement === "string"
            ? document.querySelector(statusElement)
            : statusElement;

        if (statusEl) {
          statusEl.innerHTML = `
            <i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem; margin-right: 5px;"></i>
            Connection Unstable
          `;
          statusEl.style.color = "#ffc107";
        }
      }

      // 调用用户自定义的 onError
      if (typeof heartbeatOptions.onError === "function") {
        heartbeatOptions.onError(error, failureCount);
      }
    },
  });

  return heartbeat;
}

// 默认导出
export default {
  createHttpHeartbeat,
  updateServerStatus,
  createHttpHeartbeatWithStatus,
};

```

> 标准模块可能随时更新和修复，按照最新项目引用使用。

###### 创建心跳

心跳参数由后端传递给前端，配置env参数如下：

```js
# ============================================
# 心跳数据
# ============================================
# 心跳检测间隔 单位毫秒
HEARTBEAT_INTERVAL=300000
# 心跳超时时间
HEARTBEAT_TIMEOUT=10000
# 最大失败重连次数
HEARTBEAT_MAX_FAILURE=10
```

在后台app.js中创建服务器参数获取及心跳交互函数，具体函数如下：

```js
// 创建路由 服务器地址响应
app.get("/server-info", (req, res) => {
  res.json({
    localIP: process.env.LOCAL_IP,
    port: process.env.PORT,
    loginRedirect: process.env.LOGIN_REDIRECT_URL,
    registerRedirect: process.env.REGISTER_REDIRECT_URL,
    timestamp: Date.now(),
  });
});
//创建路由 心跳交互
app.get("/heartbeat", (req, res) => {
  res.json({
    status: "ok",
    timestamp: Date.now(),
    message: "Heartbeat Success Received.",
  });
});
```

###### 用户注册

在reg.js中引用心跳模块，并创建如下函数方法：

```js
//引入心跳执行模块并获取服务器地址参数
import { createHttpHeartbeat } from "./http-heartbeat.js";
// 这里有个隐患，js不允许上层使用await，待修复
const SERVERINFO = await getServerInfo();
 ......
 
window.addEventListener("load", function () {
 ......
  // 检查服务器连接
  checkServerConnection();
});
......
// 心跳检查 - 检查服务器连接
async function checkServerConnection() {
  //使用heartbeat模块,心跳检查一直执行，不启用关闭功能
  {
    createHttpHeartbeat({
      url: `http://${SERVERINFO.localIP}:${SERVERINFO.port}/heartbeat`,
      interval: SERVERINFO.heartbeat.interval,
      timeout: SERVERINFO.heartbeat.timeout,
      maxFailures: SERVERINFO.heartbeat.maxFailures,
    

      onSuccess: (data) => {
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #28a745; font-size: 0.6rem;"></i> Connection Successful';
      },

      onFailure: (error) => {
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
      },

      onError: (error, count) => {
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
      },
    });
  }
}
......
// 获取服务器IP端口
async function getServerInfo() {
  try {
    const res = await fetch("/server-info");
    if (!res.ok) throw new Error("接口异常");
    return await res.json();
  } catch (err) {
    console.error("获取服务信息失败：", err);
    throw err;
  }
}
```

> 打开浏览器控制台测试心跳，获得如下数据：
>
> ```bash
> 🚀 [HTTP Heartbeat] 启动心跳检测...
> http-heartbeat.js:92 💓 [HTTP Heartbeat] 发送心跳请求...
> http-heartbeat.js:130 ✅ [HTTP Heartbeat] 心跳成功 {status: 'ok', timestamp: 1782350969886, message: 'Heartbeat Success Received.'}
> ```

###### 用户登录

在login.js中引用心跳模块，并创建如下函数方法：

```js
//引入心跳执行模块并获取服务器地址参数
import { createHttpHeartbeat } from "./http-heartbeat.js";
// 这里有个隐患，js不允许上层使用await，待修复
const SERVERINFO = await getServerInfo();
 ......
 
window.addEventListener("load", function () {
 ......
  // 检查服务器连接
  checkServerConnection();
});
......
// 心跳检查 - 检查服务器连接
async function checkServerConnection() {
  //使用heartbeat模块,心跳检查一直执行，不启用关闭功能
  {
    createHttpHeartbeat({
      url: `http://${SERVERINFO.localIP}:${SERVERINFO.port}/heartbeat`,
      interval: SERVERINFO.heartbeat.interval,
      timeout: SERVERINFO.heartbeat.timeout,
      maxFailures: SERVERINFO.heartbeat.maxFailures,
    
      onSuccess: (data) => {
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #28a745; font-size: 0.6rem;"></i> Connection Successful';
      },

      onFailure: (error) => {
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
      },

      onError: (error, count) => {
        serverStatus.innerHTML =
          '<i class="fas fa-circle" style="color: #ffc107; font-size: 0.6rem;"></i> Connection failed';
      },
    });
  }
}
......
// 获取服务器IP端口
async function getServerInfo() {
  try {
    const res = await fetch("/server-info");
    if (!res.ok) throw new Error("接口异常");
    return await res.json();
  } catch (err) {
    console.error("获取服务信息失败：", err);
    throw err;
  }
}
```

> 打开浏览器控制台测试心跳，获得如下数据：
>
> ```bash
> 🚀 [HTTP Heartbeat] 启动心跳检测...
> http-heartbeat.js:92 💓 [HTTP Heartbeat] 发送心跳请求...
> http-heartbeat.js:130 ✅ [HTTP Heartbeat] 心跳成功 {status: 'ok', timestamp: 1782350969886, message: 'Heartbeat Success Received.'}
> ```

##### 用户管理

用户管理分为注册用户和登录用户两个模块，采用标准MongoDB模块实现。

###### 注册用户

users.controller.js中的注册方法：

```js
  // 【页面模板渲染专用】注册用户,仅校验重复，返回用户对象，不返回JSON
  async registerData(req) {
    try {
      let { username, email, password } = req.body;
      // $or: [{ username }, { email }]
      const exist = await usersService.findOne({
        $or: [{ username }, { email }],
      });
      if (exist)
        return {
          type: 0,
          msg: "用户名已存在",
        };
      const user = await usersService.createUser({
        username,
        password,
        email,
      });
      return {
        type: 1,
        msg: "创建成功",
        user: { id: user._id, username: user.username, email: user.email },
      };
    } catch (err) {
      return {
        type: -1,
        msg: error.message || "创建失败，请检查填写数据",
        error: err,
      };
    }
  }
```

在webAuthRoute.js中创建注册路由：

```js
//POST IP:PORT/auth/reg 注册数据POST
authRouter.post("/reg", async function (req, res, next) {
  try {
    const registerDate = await usersController.registerData(req);
    if (registerDate.type === 1) {
      res.status(200).json({
        code: 200,
        msg: "注册成功",
        data: registerDate,
      });
    } else {
      res.status(500).json({
        code: 500,
        msg: "注册失败",
        data: registerDate,
      });
    }
  } catch (err) {
    res.status(404).json({
      code: 404,
      msg: "注册异常",
      data: err,
    });
  }
});
```

> 01-前端使用js解析json，使用users.service.js里面的ejs模块；
>
> 02-MongoDB的models模型基于需求进行微调使用

###### 登录用户

users.controller.js中的登录方法：

```js
  // 【页面模板渲染专用】登录用户,校验账号密码，返回session信息
  async loginData(req) {
    try {
      const { username, password } = req.body;
      const user = await usersService.findOne({ username });
      console.log("当前的user:", user);

      if (!user)
        return {
          type: -1,
          msg: "账号不存在",
          error: "账号不存在",
        };
      const isMatch = await comparePassword(password, user.password);
      if (!isMatch)
        return {
          type: -1,
          msg: "密码错误",
          error: "密码错误",
        };
      // 登录刷新session，生成全新sessionId（安全规范）
      await new Promise((resolve, reject) => {
        req.session.regenerate((err) => {
          if (err) reject(err);
          resolve();
        });
      });
      // 生成session,写入session的主要目的就是为了让浏览器具备这个参数，以后访问的时候携带者这些数据
      req.session.userId = user._id;
      req.session.username = user.username;
      req.session.role = user.role;

      return {
        type: 1,
        msg: "登录成功",
        session: req.session,
        user: { id: user._id, username: user.username, role: user.role },
      };
    } catch (err) {
      return {
        type: -1,
        msg: err.message || "登录失败，请检查填写数据",
        error: err,
      };
    }
  }
```

在webAuthRoute.js中创建登录路由：

```js
//POST IP:PORT/auth/login 登录数据POST
authRouter.post("/login", async function (req, res, next) {
  try {
    const loginDate = await usersController.loginData(req);

    if (loginDate.type === 1) {
      return res.redirect("/projects");
    } else {
      return res.render("login.auth.ejs", { errMsg: loginDate.msg });
    }
  } catch (err) {
    res.status(404).json({
      code: 404,
      msg: "登录异常",
      data: err,
    });
  }
});
```

###### 登出用户

users.controller.js中的登出方法：

```js
// 【页面模板渲染专用】登出用户,注销session数据
  async logoutData(req) {
    try {
      const result = await new Promise((resolve, reject) => {
        req.session.destroy((err) => {
          if (err) reject(err);
          resolve({
            type: 1,
            msg: "session已销毁",
            data: null,
          });
        });
      });
      return result;
    } catch (err) {
      return {
        type: -1,
        msg: err.message || "session销毁异常",
        error: err,
      };
    }
  }
```

在webAuthRoute.js中创建登出路由：

```js
//GET IP:PORT/auth/logout 登出
authRouter.get("/logout", async function (req, res, next) {
  try {
    await usersController.logoutData(req);
    // session销毁成功，跳登录页
    return res.redirect("/auth/login");
  } catch (err) {
    res.render("error.ejs", {
      msg: "用户登出异常",
      error: err,
    });
  }
});
```

###### 用户鉴权

目前只能使用session的方式实现权限鉴验，因为在ejs的模式下，页面跳转无法携带token字段，导致无法鉴权。

* 鉴权白名单

在鉴权中间件中需要设置白名单，也就是白名单中的请求无需进行鉴权，比如：与服务器握手、心跳检查等

```js
// 白名单放行登录、注册接口，阻断鉴权死循环，从.env读取白名单字符串，切割为数组
const whiteListStr = process.env.TOKEN_WHITE_LIST || "";
// 分割、去空格、过滤空字符串
const whiteList = whiteListStr.split(",").map((item) => item.trim()).filter(Boolean);
```

* 鉴权件定义

鉴权中间件middleware/login.session.auth.help.js:

```js
/**
 * 登录鉴权中间件类
 * @class CheckLogin
 * @description 全局会话登录校验，区分页面/API请求，异常捕获+日志埋点
 */
class CheckSessionLogin {
  // 业务配置抽离，统一管理路由地址
  static LOGIN_REDIRECT_URL = process.env.LOGIN_REDIRECT_URL;
  static UNAUTH_CODE = Number(process.env.UNAUTH_CODE) || 401;
  static UNAUTH_MSG = process.env.UNAUTH_MSG || "登录失效，请重新登录";

  /**
   * 登录校验中间件函数
   * @param {import('express').Request} req 请求对象
   * @param {import('express').Response} res 响应对象
   * @param {import('express').NextFunction} next 放行函数
   * @returns {void}
   */
  checkSessionLogin(req, res, next) {
    try {
      // 白名单放行登录、注册接口，阻断鉴权死循环，从.env读取白名单字符串，切割为数组
      const whiteListStr = process.env.TOKEN_WHITE_LIST || "";
      // 分割、去空格、过滤空字符串
      const whiteList = whiteListStr
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);
      const path = req.originalUrl.split("?")[0];
      if (whiteList.includes(path)) {
        return next();
      }
      // 兜底：session 对象不存在（存储服务断开）
      if (!req.session) {
        console.warn(
          `[鉴权拦截] ${req.method} ${req.originalUrl} - Session 对象丢失`,
        );
        return this._handleUnauthorized(req, res);
      }

      // 核心登录态判断：无登录用户名则拦截
      if (!req.session.username) {
        console.warn(
          `[鉴权拦截] ${req.method} ${req.originalUrl} - 未登录/会话过期`,
        );
        return this._handleUnauthorized(req, res);
      }

      // 登录校验通过，放行后续中间件/路由
      next();
    } catch (error) {
      // 捕获session读取、存储所有异常，防止服务崩溃
      console.error(
        `[鉴权异常] ${req.method} ${req.originalUrl}`,
        error.message,
      );
      // 统一返回未授权逻辑
      return this._handleUnauthorized(req, res);
    }
  }

  /**
   * 统一处理未登录响应：区分页面渲染 / 接口JSON返回
   * @private
   * @param {import('express').Request} req
   * @param {import('express').Response} res
   */
  _handleUnauthorized(req, res) {
    // 可选链防止 accept 不存在报错
    const isApiRequest = req.headers.accept?.includes("application/json");

    if (isApiRequest) {
      // 静态类名严格保持 CheckSessionLogin，和class定义一致
      return res.status(CheckSessionLogin.UNAUTH_CODE).json({
        code: CheckSessionLogin.UNAUTH_CODE,
        msg: CheckSessionLogin.UNAUTH_MSG,
        redirect: CheckSessionLogin.LOGIN_REDIRECT_URL,
      });
    } else {
      // 页面浏览器请求：302重定向登录页
      return res.redirect(CheckSessionLogin.LOGIN_REDIRECT_URL);
    }
  }
}
// 创建实例并绑定this上下文，解决单独提取方法后this丢失问题
const sessionAuthInstance = new CheckSessionLogin();

// 强制绑定实例上下文，无论函数单独提取使用，this永远指向当前实例
sessionAuthInstance.checkSessionLogin =
  sessionAuthInstance.checkSessionLogin.bind(sessionAuthInstance);

// 全局单例导出，项目全局复用同一个实例
module.exports = sessionAuthInstance;

```

* 鉴权件使用

在webAuthRoute.pm.js文件中引入：

```js
const sessionAuth =
  require("@middleware/login.session.auth.help.js").checkSessionLogin;
......
//项目管理主页
webMainRouter.get("/", sessionAuth, function (req, res, next) {
  res.render("index.pm.ejs", { user: req.session.username });
});
```

##### 交互体验

###### 登录异常

在设备登录异常的时候，直接在原有页面进行弹窗提示，

views/login.auth.ejs增加弹窗条件判断：

```js
<!-- 错误提示区域 -->
    <div id="alertBox" class="alert"></div>
      <!-- 后端回传登录错误信息给前端JS -->
      <% if (errMsg) { %>
      <script>
        window.LOGIN_ERROR_MSG = "<%= errMsg %>";
      </script>
      <% } %>
```

routes/webAuthRoute.js路由优化如下：

```js
//GET IP:PORT/auth/login 登录页面
authRouter.get("/login", function (req, res, next) {
  res.render("login.auth.ejs", { errMsg: null });
});
//POST IP:PORT/auth/login 登录数据POST
authRouter.post("/login", async function (req, res, next) {
  try {
    const loginDate = await usersController.loginData(req);

    if (loginDate.type === 1) {
      return res.redirect("/projects");
    } else {
      // 账号/密码错误、账号不存在
      return res.render("login.auth.ejs", { errMsg: loginDate.msg });
    }
  } catch (err) {
    // 数据库/服务异常，统一渲染登录页，不返回json
    return res.render("login.auth.ejs", { errMsg: "登录服务异常，请稍后重试" });
  }
});
```

public/js/login.js需要注册异常事件弹窗：

```js
// 页面加载时
window.addEventListener("load", function () {
  // 后端返回登录错误：弹出提示 + 清空密码框，用户名保留
  if (window.LOGIN_ERROR_MSG) {
    showAlert(window.LOGIN_ERROR_MSG, "error");
    passwordInput.value = "";
    // 清除标记，F5刷新不再重复弹窗
    delete window.LOGIN_ERROR_MSG;
  }
  checkServerConnection();
});
```

###### 注册异常

在设备异常异常的时候，直接在原有页面进行弹窗提示，

views/reg.auth.ejs增加弹窗条件判断：

```js
<!-- 错误提示区域 -->
    <div id="alertBox" class="alert"></div>
      <!-- 后端回传登录错误信息给前端JS -->
      <% if (errMsg) { %>
      <script>
        window.LOGIN_ERROR_MSG = "<%= errMsg %>";
      </script>
      <% } %>
```

routes/webAuthRoute.js路由优化如下：

```js
//GET IP:PORT/auth/reg 注册页面
authRouter.get("/reg", function (req, res, next) {
  res.render("reg.auth.ejs", { errMsg: null });
});
//POST IP:PORT/auth/reg 注册数据POST
authRouter.post("/reg", async function (req, res, next) {
  try {
    const registerDate = await usersController.registerData(req);
    if (registerDate.type === 1) {
      return res.redirect("/auth/login");
    } else {
      // 账号/邮箱地址存在，无法注册
      return res.render("reg.auth.ejs", { errMsg: registerDate.msg });
    }
  } catch (err) {
    //数据库/服务异常，统一渲染登录页，不返回json
    return res.render("reg.auth.ejs", { errMsg: "注册服务异常，请稍后重试" });
  }
});
```

public/js/reg.js需要注册异常事件弹窗：

```js
// 页面加载初始化
window.addEventListener("load", async function () {
  // 读取后端返回的注册错误提示
  if (window.LOGIN_ERROR_MSG) {
    showAlert(window.LOGIN_ERROR_MSG, "error");
    // 清空两个密码框，用户名、邮箱保留
    passwordInput.value = "";
    rePasswordInput.value = "";
    // 清除标记，刷新不再重复弹窗
    delete window.LOGIN_ERROR_MSG;
  }
  await checkServerConnection();
});
```

###### 
