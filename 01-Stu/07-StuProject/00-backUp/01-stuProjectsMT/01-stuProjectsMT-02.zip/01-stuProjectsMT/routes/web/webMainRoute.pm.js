var express = require("express");
var webMainRouter = express.Router();
const sessionAuth =
  require("@middleware/login.session.auth.help.js").checkSessionLogin;

//项目管理主页
webMainRouter.get("/", sessionAuth, function (req, res, next) {
  res.render("index.pm.ejs", { user: req.session.username });
});

module.exports = webMainRouter;
