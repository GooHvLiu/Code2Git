var express = require("express");
const usersController = require("@MongoDB/controllers/users.controller.js");
var authRouter = express.Router();
//GET IP:PORT/auth/reg 注册页面
authRouter.get("/reg", function (req, res, next) {
  res.render("reg.auth.ejs", { errMsg: null });
});

//GET IP:PORT/auth/login 登录页面
authRouter.get("/login", function (req, res, next) {
  res.render("login.auth.ejs", { errMsg: null });
});

//POST IP:PORT/auth/reg 注册数据POST
authRouter.post("/reg", async function (req, res, next) {
  try {
    const registerDate = await usersController.registerData(req);
    if (registerDate.type === 1) {
      return res.redirect("/auth/login");
    } else {
      // 账号/邮箱地址存在，无法注册
      console.log("当前的提示是：", registerDate);

      return res.render("reg.auth.ejs", { errMsg: registerDate.msg });
    }
  } catch (err) {
    //数据库/服务异常，统一渲染登录页，不返回json
    return res.render("reg.auth.ejs", { errMsg: "注册服务异常，请稍后重试" });
  }
});

//POST IP:PORT/auth/login 登录数据POST
authRouter.post("/login", async function (req, res, next) {
  try {
    const loginDate = await usersController.loginData(req);

    if (loginDate.type === 1) {
      return res.redirect("/projects");
    } else {
      // 账号/密码错误、账号不存在
      return res.render("login.auth.ejs", { errMsg: loginDate.msg });
    }
  } catch (err) {
    //数据库/服务异常，统一渲染登录页，不返回json
    return res.render("login.auth.ejs", { errMsg: "登录服务异常，请稍后重试" });
  }
});

//GET IP:PORT/auth/logout 登出
authRouter.get("/logout", async function (req, res, next) {
  try {
    await usersController.logoutData(req);
    // session销毁成功，跳登录页
    return res.redirect("/auth/login");
  } catch (err) {
    res.render("error.ejs", {
      msg: "用户登出异常",
      error: err,
    });
  }
});

module.exports = authRouter;
