const usersController = require("./users.controller.js");
const accountsController = require("./accounts.controller.js");

module.exports = {
  usersController,
  accountsController,
};
