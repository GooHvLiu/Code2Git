const jwt = require("jsonwebtoken");
const { success, fail } = require("@MongoDB/utils/response.js");
const { usersService } = require("@MongoDB/services/index.service.js");
const { comparePassword } = require("@MongoDB/utils/encryptSalted.js");

class UserController {
  // 【API接口用】注册用户,返回JSON给前端ajax
  async register(req, res) {
    try {
      let { username, role, password } = req.body;
      // $and: [{ username }, { role }]
      const exist = await usersService.findOne({ username });
      if (exist) return fail(res, "用户名已存在");
      const user = await usersService.createUser({
        username,
        password,
        role,
      });
      return success(
        res,
        { id: user._id, username: user.username, role: user.role },
        "注册成功",
      );
    } catch (error) {
      return fail(res, error);
    }
  }

  // 【API接口用】登录用户,返回JSON给前端ajax
  async login(req, res) {
    try {
      const { username, password } = req.body;
      const user = await usersService.findOne({ username });
      if (!user) return fail(res, "账号不存在");
      const isMatch = await comparePassword(password, user.password);
      if (!isMatch) return fail(res, "密码错误");

      // 生成token
      const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRES || "2h",
      });
      return success(
        res,
        {
          token,
          user: { id: user._id, username: user.username, role: user.role },
        },
        "登录成功",
      );
    } catch (error) {
      return fail(res, error);
    }
  }

  // 【API接口用】获取用户列表（管理员）,返回JSON给前端ajax
  async getUserList(req, res) {
    try {
      const { page = 1, limit = 10, username } = req.query;
      const query = {};
      if (username) query.username = new RegExp(username, "i");
      const data = await usersService.getUserList(query, page, limit);
      return success(res, data);
    } catch (error) {
      return fail(res, error);
    }
  }

  // 【API接口用】获取当前登录用户信息,返回JSON给前端ajax
  async getInfo(req, res) {
    return success(res, req.user);
  }

  // 【API接口用】删除用户（软删）,返回JSON给前端ajax
  async deleteUser(req, res) {
    try {
      const { id } = req.params;
      await usersService.deleteById(id);
      return success(res, null, "删除成功");
    } catch (error) {
      return fail(res, error);
    }
  }

  // 【页面模板渲染专用】注册用户,仅校验重复，返回用户对象，不返回JSON
  async registerData(req) {
    try {
      let { username, role, password } = req.body;
      // $or: [{ username }, { email }]
      const exist = await usersService.findOne({ username });
      if (exist)
        return {
          type: 0,
          msg: "用户名已存在",
        };
      const user = await usersService.createUser({
        username,
        password,
        role,
      });
      return {
        type: 1,
        msg: "创建成功",
        user: { id: user._id, username: user.username, role: user.role },
      };
    } catch (error) {
      return {
        type: -1,
        msg: error.message || "创建失败，请检查填写数据",
        error: error,
      };
    }
  }

  // 【页面模板渲染专用】登录用户,校验账号密码，返回token+用户信息
  async loginData(req) {
    try {
      const { username, password } = req.body;
      const user = await usersService.findOne({ username });

      if (!user)
        return {
          type: -1,
          msg: "账号不存在",
          error: "账号不存在",
        };
      const isMatch = await comparePassword(password, user.password);
      if (!isMatch)
        return {
          type: -1,
          msg: "密码错误",
          error: "密码错误",
        };

      // 生成token
      const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRES || "2h",
      });
      return {
        type: 1,
        msg: "登录成功",
        token: token,
        user: { id: user._id, username: user.username, role: user.role },
      };
    } catch (error) {
      return {
        type: -1,
        msg: err.message || "登录失败，请检查填写数据",
        error: err,
      };
    }
  }

  // 【页面模板渲染专用】获取用户列表（管理员）,分页原始数据
  async getUserListData(req) {
    try {
      const { page = 1, limit = 10, username } = req.query;
      const query = {};
      if (username) query.username = new RegExp(username, "i");
      const data = await usersService.getUserList(query, page, limit);
      return {
        type: 1,
        msg: "获取账单列表成功",
        data: data,
      };
    } catch (error) {
      return {
        type: -1,
        msg: err.message || "获取账单列表失败，请检查填写数据",
        error: err,
      };
    }
  }

  // 【页面模板渲染专用】个人中心页面：当前登录用户数据
  async getInfoData(req) {
    return {
      type: 1,
      msg: "获取成功",
      data: req.user,
    };
  }

  // 【页面模板渲染专用】删除用户（软删）,仅执行删除逻辑，返回提示文本
  async deleteUserData(req) {
    try {
      const { id } = req.params;
      const data = await usersService.deleteById(id);
      return {
        type: 1,
        msg: "删除成功",
        data: data,
      };
    } catch (error) {
      return {
        type: -1,
        msg: err.message || "删除创建失败，请检查填写数据",
        error: err,
      };
    }
  }

  // 【页面模板渲染专用】创建用户信息,返回结果
  async createUserData(Object) {
    try {
      const data = await usersService.createUser(Object);
      return {
        type: 1,
        msg: "创建成功",
        data: data,
      };
    } catch (error) {
      return {
        type: -1,
        msg: err.message || "账目创建失败，请检查填写数据",
        error: err,
      };
    }
  }

  // 【页面模板渲染专用】通过ID查找用户信息,返回结果
  async findByIdData(Object) {
    try {
      const data = await usersService.findById(Object);
      return {
        type: 1,
        msg: "查找成功",
        data: data,
      };
    } catch (error) {
      return {
        type: -1,
        msg: err.message || "没有找到对应的用户信息",
        error: err,
      };
    }
  }

  // 【页面模板渲染专用】条件查询单条,返回结果
  async findOneData(Object) {
    try {
      const data = await usersService.findOne(Object);
      return {
        type: 1,
        msg: "查找成功",
        data: data,
      };
    } catch (error) {
      return {
        type: -1,
        msg: err.message || "没有找到对应的用户信息",
        error: err,
      };
    }
  }
}

module.exports = new UserController();
