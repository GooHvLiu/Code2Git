const jwt = require("jsonwebtoken");
const { success, fail } = require("../utils/response");
const userService = require("../services/user.service");
const { comparePassword } = require("../utils/encryptSalted");

class UserController {
  // 注册用户
  async register(req, res) {
    const { username, email, password } = req.body;
    // 空字符串、undefined、null 全部替换成默认邮箱,这么做是为了在特殊项目中,email不做要求,直接注册就好了
    const realEmail = email || "email@email.com";
    const exist = await userService.findOne({
      $or: [{ username }, { realEmail }],
    });
    if (exist) return fail(res, "用户名或邮箱已存在");
    const user = await userService.createUser({
      username,
      realEmail,
      password,
    });
    return success(res, { id: user._id, username: user.username }, "注册成功");
  }

  // 登录用户
  async login(req, res) {
    const { username, password } = req.body;
    const user = await userService.findOne({ username });
    if (!user) return fail(res, "账号不存在");
    const isMatch = await comparePassword(password, user.password);
    if (!isMatch) return fail(res, "密码错误");

    // 生成token
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES || "2h",
    });
    return success(
      res,
      {
        token,
        user: { id: user._id, username: user.username, role: user.role },
      },
      "登录成功",
    );
  }

  // 获取用户列表（管理员）
  async getUserList(req, res) {
    const { page = 1, limit = 10, username } = req.query;
    const query = {};
    if (username) query.username = new RegExp(username, "i");
    const data = await userService.getUserList(query, page, limit);
    return success(res, data);
  }

  // 获取当前登录用户信息
  async getInfo(req, res) {
    return success(res, req.user);
  }

  // 删除用户（软删）
  async deleteUser(req, res) {
    const { id } = req.params;
    await userService.deleteById(id);
    return success(res, null, "删除成功");
  }
}

module.exports = new UserController();
