// 1.1 引入依赖包和定义变量
const { betterAuth } = require("better-auth");
const { mongodbAdapter } = require("better-auth/adapters/mongodb");
const { getDb } = require("../models/db");
let _auth = null;

/**
 * 1.2 process.env.LISTEN_AREA
 */
{
  const dotenv = require("dotenv");
  const dotenvExpand = require("dotenv-expand");
  const myEnv = dotenv.config();
  dotenvExpand.expand(myEnv);
}

// 1.3 为 npx auth generate CLI 提供同步配置入口,CLI 无法等待异步 getDb()，因此这里直接使用环境变量中的连接字符串
const auth = betterAuth({
  database: mongodbAdapter(process.env.MONGODB_URI),
});

// 2. 初始化Auth（运行时异步初始化，保持原有逻辑不变）
async function initAuth() {
  if (_auth) return _auth;

  const db = await getDb();

  _auth = betterAuth({
    database: mongodbAdapter(db),
  });

  return _auth;
}

// 3. 获取auth
function getAuth() {
  if (!_auth) {
    throw new Error("Auth 未初始化，请先调用 initAuth()");
  }
  return _auth;
}

// auth 命名导出以兼容 CLI
module.exports = { auth, initAuth, getAuth };
