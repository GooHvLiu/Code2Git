// 1. 同步加载基础依赖
var createError = require("http-errors");
var express = require("express");
var path = require("path");
var cookieParser = require("cookie-parser");
var logger = require("morgan");

var indexRouter = require("./routes/index");
var usersRouter = require("./routes/users");

// 2. 同步创建 Express 实例
var app = express();

// 3. 立即同步导出 app，确保 bin/www 能正确拿到 Express 实例
module.exports = app;

// 4. 正常的中间件和路由配置（同步执行）
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "jade");

app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

app.use("/", indexRouter);
app.use("/users", usersRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};
  res.status(err.status || 500);
  res.render("error");
});

// 5. 异步初始化 Auth（不阻塞 app 的创建与导出）
(async () => {
  try {
    const { initAuth } = require("./src/utils/auth.js");
    await initAuth();
    console.log("✅ Better-Auth 初始化完成");
  } catch (err) {
    console.error("❌ Auth 初始化失败:", err);
    // Auth 初始化失败可以选择退出，或者仅打印警告让服务继续启动
    process.exit(1);
  }
})();

// 6. 优雅退出钩子
const { closeDb } = require("./src/models/db");
process.on("SIGINT", async () => {
  await closeDb();
  process.exit(0);
});
process.on("SIGTERM", async () => {
  await closeDb();
  process.exit(0);
});
