#### BetterAuth

##### 前期安装

###### 前端框架

express 本身是一个 npm 包，所以可以通过 npm 安装 :

```cmd
PS F:\CodingMan\Code2Git\01-Stu\06-F2B_Advanced\03-BetterAuth\01-simpleExample> npm init
This utility will walk you through creating a package.json file.
It only covers the most common items, and tries to guess sensible defaults.

See `npm help init` for definitive documentation on these fields
and exactly what they do.

Use `npm install <pkg>` afterwards to install a package and
save it as a dependency in the package.json file.

Press ^C at any time to quit.
package name: (01-stuprojects) simpleExample
version: (1.0.0) 
description: simpleExample.
entry point: (index.js) 
test command: 
git repository: 
keywords: 
author: GooHv
license: (ISC) 
type: (commonjs) 
About to write to F:\CodingMan\Code2Git\01-Stu\06-F2B_Advanced\03-BetterAuth\01-simpleExample\package.json:

{
  "name": "stu_projects",
  "version": "1.0.0",
  "description": "simpleExample.",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "GooHv",
  "license": "ISC",
  "type": "commonjs"
}


Is this OK? (yes) 
PS F:\CodingMan\Code2Git\01-Stu\06-F2B_Advanced\03-BetterAuth\01-simpleExample> npm i express

added 66 packages in 1s

24 packages are looking for funding
  run `npm fund` for details
PS C:\Users\Administrator\Desktop\01-simpleExample> 
```

###### 模板生成

通过generator应用生成器工具 `express-generator` 可以快速创建一个应用的骨架。

你可以通过 `npx` （包含在 Node.js 8.2.0 及更高版本中）命令来运行 Express 应用程序生成器。

```cmd
PS F:\CodingMan\Code2Git\01-Stu\06-F2B_Advanced\03-BetterAuth\01-simpleExample> npx express-generatonpx express-generator

  warning: the default view engine will not be jade in future releases
  warning: use `--view=jade' or `--help' for additional options

destination is not empty, continue? [y/N] y

   create : public\
   create : public\javascripts\
   create : public\images\
   create : public\stylesheets\
   create : public\stylesheets\style.css
   create : routes\
   create : routes\index.js
   create : routes\users.js
   create : views\
   create : views\error.jade
   create : views\index.jade
   create : views\layout.jade
   create : app.js
   create : package.json
   create : bin\
   create : bin\www

   install dependencies:
     > npm install

   run the app:
     > SET DEBUG=01-stuprojects:* & npm start

PS F:\CodingMan\Code2Git\01-Stu\06-F2B_Advanced\03-BetterAuth\01-simpleExample> 
```

###### 认证依赖

```bash
PS F:\CodingMan\Code2Git\01-Stu\06-F2B_Advanced\03-BetterAuth\01-simpleExample> npm install better-auth

added 22 packages in 11s

6 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\06-F2B_Advanced\03-BetterAuth\01-simpleExample>
```

###### 变量加载

dotenv 是一个 Node.js 的 npm 包，它的唯一作用就是：把 .env 文件里的变量加载到 process.env 对象中，每个后端服务器都有自己的环境配置等信息，可以使用dotenv包进行管理和加载。

安装 dotenv非常简单，按照以下步骤操作即可。

```cmd
PS C:\Users\Administrator\Desktop\01-stuProjects> npm i dotenv

added 1 package in 1s

8 packages are looking for funding
  run `npm fund` for details
PS C:\Users\Administrator\Desktop\01-stuProjects> 
```

> 安装好后，就可以通过创建.env文件，并在www或其他服务文件下导入即可使用，具体参考增强方案中的环境变量章节;
>
> dotenv 默认不支持变量引用，若想使用变量引用，需要安装变量增强工具包
>
> > SERVER_IP=http://${LOCAL_IP}:${PORT}
> >
> > LOCAL_IP=192.168.10.148
> >
> > process.env.SERVER_IP      // "http://${LOCAL_IP}:${PORT}"  (字面量，不会解析)

###### 变量增强

dotenv 默认不支持变量引用，若想使用变量引用，需要安装变量增强工具包dotenv-expand，具体安装方式如下：

```bash
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i dotenv dotenv-expand      

added 1 package in 1s

10 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT>
```

> * 使用方法
>
> >     const dotenv = require("dotenv");
> >     const dotenvExpand = require("dotenv-expand");
> >     const myEnv = dotenv.config();
> >     dotenvExpand.expand(myEnv);
> >
>
> * 实现效果
>
> > SERVER_IP=http://${LOCAL_IP}:${PORT}
> >
> > LOCAL_IP=192.168.10.148
> >
> > process.env.MONGODB_DBHOST // "192.168.10.148:1234"             ✅ 正确解析

###### 数据库包

该项目统一使用MongoDB进行数据管理，需要使用mongoose包进行管理，安装方法如下：

```cmd
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i mongoose

added 18 packages in 3s

9 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> 
```

###### 加密认证

该项目由于存在的登录数据加密需求，统一使用bcrypt包进行加密和验证，当前采用纯 JavaScript，无需编译的js文件方式，相比bcrypt 稍慢（约 30%）,安装方法如下：

```cmd
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm i bcryptjs

added 1 package in 1s

9 packages are looking for funding
  run `npm fund` for details
PS F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT> npm list bcrypt js
stu_projects_manager_tool@0.0.0 F:\CodingMan\Code2Git\01-Stu\07-StuProject\01-stuProjectsMT
└── (empty)
```

> 实际生产环境，可考虑bcrypt 方式，具体查询相关资料。

##### 环境搭建

项目根目录下创建环境变量.env文件，并添加以下环境变量：

* Secret Key 秘密钥匙
* Set Base URL基础路径

```env
# 基础配置-服务器配置,process.env.LISTEN_AREA
PORT=3000
LISTEN_AREA=0.0.0.0
NODE_ENV=development
SERVER_IP=http://${LOCAL_IP}:${PORT}

# 基础配置-局域网IP
LOCAL_IP=127.0.0.1

# Better-Auth-秘密钥匙
BETTER_AUTH_SECRET=QyGWmEtofd1DlJyQCsZgvPDAybgRQWbX
BETTER_AUTH_URL=${SERVER_IP}


# MongoDB-数据库基础配置
MONGODB_DBHOST=mongodb://${LOCAL_IP}
MONGODB_DBPORT=27017
MONGODB_DBNAME=expressTest4Demo

# MongoDB-数据库地址
MONGODB_URI=${MONGODB_DBHOST}:${MONGODB_DBPORT}/${MONGODB_DBNAME}
```

##### 创建实例

###### 创建文件

在以下几个任一位置创建名为 `auth.ts` 的文件：

- Project root 
- `lib/` 文件夹
-  `utils/` 文件夹

> 也可以把这些文件夹嵌套在 `src/`、`app/` 或 `server/` 文件夹下

###### 认证实例

在auth.ts文件里，导入 Better Auth 并创建你的认证实例。确保导出带有变量名 `auth` 的认证实例，或者作为默认导出。

```ts
import { betterAuth } from "better-auth";

export const auth = betterAuth({
  //...
});
```

##### 创建数据

###### 数据客户端

* 配置环境变量

在.env文件中配置数据库连接地址配置项

```env
# 导入命令使用
# //process.env.LISTEN_AREA
#     const dotenv = require("dotenv");
#     const dotenvExpand = require("dotenv-expand");
#     const myEnv = dotenv.config();
#     dotenvExpand.expand(myEnv);


# 基础配置-服务器配置,process.env.LISTEN_AREA
PORT=3000
LISTEN_AREA=0.0.0.0
NODE_ENV=development
SERVER_IP=http://${LOCAL_IP}:${PORT}

# 基础配置-局域网IP
LOCAL_IP=172.29.32.1

# Better-Auth-秘密钥匙
BETTER_AUTH_SECRET=QyGWmEtofd1DlJyQCsZgvPDAybgRQWbX
BETTER_AUTH_URL=${SERVER_IP}


# MongoDB-数据库基础配置
MONGODB_DBHOST=mongodb://${LOCAL_IP}
MONGODB_DBPORT=27017
MONGODB_DBNAME=expressTest4Demo

# MongoDB-数据库地址
MONGODB_URI=${MONGODB_DBHOST}:${MONGODB_DBPORT}/${MONGODB_DBNAME}
```

> 如果你使用的是 MongoDB Atlas（云托管服务），连接字符串格式会是 mongodb+srv://...，确保你的 .gitignore 文件包含了 .env，这样它就不会被 Git 提交。

* 创建数据库连接服务

在确定dotnev和dotnev-expand依赖包已安装的情况下创建src/utils/auth.ts,内容如下；

```ts
import { betterAuth } from "better-auth";

export const auth = betterAuth({
  //...
});
```

###### 配置数据库

数据库我们选用MongoDB，实际上BetterAuth支持sqlite/mysql/postgres等等数据库，使用MongoDB类型的ORM，可以使用内置适配器实现。

* 更新文件

​	更新auth.js文件，通过引入db.js文件创建数据库连接。

```ts
// 1. 引入依赖包和定义变量
const { betterAuth } = require("better-auth");
const { mongodbAdapter } = require("better-auth/adapters/mongodb");
const { getDb } = require("../models/db");
let _auth = null;

// 2. 初始化Auth
async function initAuth() {
  if (_auth) return _auth;

  const db = await getDb();

  _auth = betterAuth({
    database: mongodbAdapter(db),
  });

  return _auth;
}

// 3，获取auth
function getAuth() {
  if (!_auth) {
    throw new Error("Auth 未初始化，请先调用 initAuth()");
  }
  return _auth;
}

module.exports = { initAuth, getAuth };

```

> 因为Better-Auth使用的是TypeScript，所以后缀是auth.ts，实际在生产环境前，应该要把ts文件转换为js文件，ts文件只是在开发阶段，目前为了便捷和快速，直接转换为js文件执行和演示

* 初始化Auth

在app.js文件中异步初始化Auth，可以不阻塞 app 的创建与导出，在app.js的最后增加如下代码：

```js
......
// error handler
app.use(function (err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};
  res.status(err.status || 500);
  res.render("error");
});

// 5. 异步初始化 Auth（不阻塞 app 的创建与导出）
(async () => {
  try {
    const { initAuth } = require("./src/utils/auth.js");
    await initAuth();
    console.log("✅ Better-Auth 初始化完成");
  } catch (err) {
    console.error("❌ Auth 初始化失败:", err);
    // Auth 初始化失败可以选择退出，或者仅打印警告让服务继续启动
    process.exit(1);
  }
})();

// 6. 优雅退出钩子
const { closeDb } = require("./src/models/db");
process.on("SIGINT", async () => {
  await closeDb();
  process.exit(0);
});
process.on("SIGTERM", async () => {
  await closeDb();
  process.exit(0);
});
```

> npm start结果如下：
>
> ```bash
> 🔧 开始配置环境变量...
> 🌐 检测到局域网IP: 172.29.32.1
> ...
> ✅ MongoDB 已连接至数据库: expressTest4Demo
> ✅ Better-Auth 初始化完成
> ```

##### 创建库表

















