/**
 * 文件上传路由
 * 自动注册到 /prod-api/upload 前缀下
 */
const express = require('express');
const router = express.Router();
const UploadController = require('./upload.controller');
const uploadMiddleware = require('../../middleware/upload.middleware');
const { requireAuth } = require('../../middleware/auth.middleware');

// 需要登录的接口
router.use(requireAuth);

// ==================== 本地上传路由 ====================

// 单文件上传（字段名：file）
router.post(
  '/local',
  uploadMiddleware.localSingle('file'),
  UploadController.uploadLocalSingle
);

// 多文件上传（字段名：files，最多 10 个）
router.post(
  '/local/batch',
  uploadMiddleware.localArray('files', 10),
  UploadController.uploadLocalBatch
);

// 删除本地文件
router.delete(
  '/local',
  UploadController.deleteLocalFile
);

// ==================== R2 云存储路由 ====================

// R2 单文件上传
router.post(
  '/r2',
  uploadMiddleware.r2Single('file'),
  UploadController.uploadR2Single
);

// R2 多文件上传
router.post(
  '/r2/batch',
  uploadMiddleware.r2Array('files', 10),
  UploadController.uploadR2Batch
);

// 删除 R2 文件
router.delete(
  '/r2',
  UploadController.deleteR2File
);

module.exports = router;