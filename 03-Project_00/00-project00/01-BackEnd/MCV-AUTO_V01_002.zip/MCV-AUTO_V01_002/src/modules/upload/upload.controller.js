/**
 * 文件上传控制器
 */
const UploadService = require('./upload.service');

class UploadController {
  /**
   * 本地单文件上传
   * POST /prod-api/upload/local
   * form-data: file
   */
  uploadLocalSingle(req, res, next) {
    try {
      const host = `${req.protocol}://${req.get('host')}`;
      const fileInfo = UploadService.buildLocalFileInfo(req.file, { host });
      return res.success(fileInfo, '文件上传成功');
    } catch (err) {
      next(err);
    }
  }

  /**
   * 本地多文件上传
   * POST /prod-api/upload/local/batch
   * form-data: files (多文件)
   */
  uploadLocalBatch(req, res, next) {
    try {
      const host = `${req.protocol}://${req.get('host')}`;
      const fileList = UploadService.buildLocalFileList(req.files, { host });
      return res.success(fileList, `成功上传 ${fileList.length} 个文件`);
    } catch (err) {
      next(err);
    }
  }

  /**
   * R2 单文件上传
   * POST /prod-api/upload/r2
   * form-data: file
   */
  async uploadR2Single(req, res, next) {
    try {
      const fileInfo = await UploadService.uploadToR2(req.file);
      return res.success(fileInfo, '云端上传成功');
    } catch (err) {
      next(err);
    }
  }

  /**
   * R2 多文件上传
   * POST /prod-api/upload/r2/batch
   * form-data: files (多文件)
   */
  async uploadR2Batch(req, res, next) {
    try {
      const fileList = await UploadService.uploadBatchToR2(req.files);
      return res.success(fileList, `成功上传 ${fileList.length} 个文件到云端`);
    } catch (err) {
      next(err);
    }
  }

  /**
   * 删除本地文件
   * DELETE /prod-api/upload/local
   * body: { path: "2026/08/02/xxx.jpg" }
   */
  deleteLocalFile(req, res, next) {
    try {
      const { path: filePath } = req.body;
      UploadService.deleteLocalFile(filePath);
      return res.success(null, '文件删除成功');
    } catch (err) {
      next(err);
    }
  }

  /**
   * 删除 R2 文件
   * DELETE /prod-api/upload/r2
   * body: { objectKey: "2026/08/02/xxx.jpg" }
   */
  async deleteR2File(req, res, next) {
    try {
      const { objectKey } = req.body;
      await UploadService.deleteR2File(objectKey);
      return res.success(null, '云端文件删除成功');
    } catch (err) {
      next(err);
    }
  }
}

module.exports = new UploadController();