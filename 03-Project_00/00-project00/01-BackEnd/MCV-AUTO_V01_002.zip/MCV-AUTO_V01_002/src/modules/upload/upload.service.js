/**
 * 文件上传服务层
 * 处理本地存储、R2 云存储、文件删除等业务逻辑
 */
const fs = require('fs');
const path = require('path');
const {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand
} = require('@aws-sdk/client-s3');

const uploadConfig = require('../../config/upload.config');
const fileUtil = require('../../utils/file');
const { BusinessError } = require('../../middleware/error.middleware');
const { ERROR_CODE } = require('../../constants/errorCode');

// ==================== R2 客户端初始化 ====================

let r2Client = null;

/**
 * 获取 R2 客户端实例（单例模式）
 * @returns {S3Client}
 */
function getR2Client() {
  if (!uploadConfig.r2.enabled) {
    throw new BusinessError(ERROR_CODE.R2_CONFIG_ERROR, 'R2 云存储未配置，请检查环境变量');
  }
  if (!r2Client) {
    r2Client = new S3Client({
      region: 'auto',
      endpoint: uploadConfig.r2.endpoint,
      credentials: {
        accessKeyId: uploadConfig.r2.accessKeyId,
        secretAccessKey: uploadConfig.r2.secretAccessKey
      }
    });
  }
  return r2Client;
}

// ==================== 本地上传服务 ====================

class UploadService {
  /**
   * 处理本地单文件上传结果
   * Multer diskStorage 已经将文件写入磁盘，这里只做结果封装
   * @param {Express.Multer.File} file Multer 处理后的文件对象
   * @param {Object} options 额外选项
   * @returns {Object} 文件信息
   */
  buildLocalFileInfo(file, options = {}) {
    if (!file) {
      throw new BusinessError(ERROR_CODE.FILE_NOT_EXIST, '请选择要上传的文件');
    }

    const dateDir = options.dateDir || fileUtil.generateDateDir();
    const relativePath = `${dateDir}/${file.filename}`;

    return {
      // 文件名（UUID 重命名后）
      filename: file.filename,
      // 原始文件名
      originalName: file.originalname,
      // 文件大小（字节）
      size: file.size,
      // 文件大小（格式化）
      sizeText: fileUtil.formatFileSize(file.size),
      // MIME 类型
      mimeType: file.mimetype,
      // 扩展名
      extname: fileUtil.getExtname(file.originalname),
      // 存储类型
      storageType: 'local',
      // 相对路径
      path: relativePath,
      // 访问 URL
      url: fileUtil.buildLocalFileUrl(relativePath, options.host),
      // 上传时间
      uploadTime: new Date().toISOString()
    };
  }

  /**
   * 处理本地多文件上传结果
   * @param {Express.Multer.File[]} files Multer 文件数组
   * @param {Object} options
   * @returns {Array} 文件信息数组
   */
  buildLocalFileList(files, options = {}) {
    if (!files || files.length === 0) {
      throw new BusinessError(ERROR_CODE.FILE_NOT_EXIST, '请选择要上传的文件');
    }
    return files.map(file => this.buildLocalFileInfo(file, options));
  }

  // ==================== R2 云存储服务 ====================

  /**
   * 上传单个文件到 R2
   * @param {Express.Multer.File} file Multer memoryStorage 处理后的文件（含 buffer）
   * @param {Object} options
   * @returns {Promise<Object>} 文件信息
   */
  async uploadToR2(file, options = {}) {
    if (!file) {
      throw new BusinessError(ERROR_CODE.FILE_NOT_EXIST, '请选择要上传的文件');
    }

    const client = getR2Client();
    const dateDir = fileUtil.generateDateDir();
    const newFilename = fileUtil.generateUuidFileName(file.originalname);
    const objectKey = `${dateDir}/${newFilename}`;

    try {
      const command = new PutObjectCommand({
        Bucket: uploadConfig.r2.bucketName,
        Key: objectKey,
        Body: file.buffer,
        ContentType: file.mimetype,
        // R2 不支持 ACL，不需要设置 ACL
      });

      await client.send(command);

      return {
        filename: newFilename,
        originalName: file.originalname,
        size: file.size,
        sizeText: fileUtil.formatFileSize(file.size),
        mimeType: file.mimetype,
        extname: fileUtil.getExtname(file.originalname),
        storageType: 'r2',
        path: objectKey,
        objectKey,
        url: fileUtil.buildR2FileUrl(objectKey),
        uploadTime: new Date().toISOString()
      };
    } catch (err) {
      console.error('[R2 上传失败]', err);
      throw new BusinessError(ERROR_CODE.R2_UPLOAD_FAIL, `云端上传失败：${err.message}`);
    }
  }

  /**
   * 批量上传文件到 R2
   * @param {Express.Multer.File[]} files
   * @param {Object} options
   * @returns {Promise<Array>}
   */
  async uploadBatchToR2(files, options = {}) {
    if (!files || files.length === 0) {
      throw new BusinessError(ERROR_CODE.FILE_NOT_EXIST, '请选择要上传的文件');
    }
    // 并发上传
    const promises = files.map(file => this.uploadToR2(file, options));
    return Promise.all(promises);
  }

  // ==================== 文件删除服务 ====================

  /**
   * 删除本地文件
   * @param {string} relativePath 文件相对路径（如 2026/08/02/xxx.jpg）
   * @returns {boolean}
   */
  deleteLocalFile(relativePath) {
    if (!relativePath) {
      throw new BusinessError(ERROR_CODE.FILE_NOT_EXIST, '文件路径不能为空');
    }

    // 路径安全校验：防止目录遍历攻击
    const safePath = path.normalize(relativePath).replace(/^(\.\.[/\\])+/, '');
    const fullPath = path.join(uploadConfig.local.dir, safePath);

    // 二次校验：确保最终路径在上传目录内
    if (!fullPath.startsWith(path.resolve(uploadConfig.local.dir))) {
      throw new BusinessError(ERROR_CODE.PARAM_INVALID, '非法的文件路径');
    }

    try {
      if (fs.existsSync(fullPath)) {
        fs.unlinkSync(fullPath);
      }
      return true;
    } catch (err) {
      console.error('[本地文件删除失败]', err);
      throw new BusinessError(ERROR_CODE.FILE_DELETE_FAIL, `文件删除失败：${err.message}`);
    }
  }

  /**
   * 删除 R2 文件
   * @param {string} objectKey R2 对象键
   * @returns {Promise<boolean>}
   */
  async deleteR2File(objectKey) {
    if (!objectKey) {
      throw new BusinessError(ERROR_CODE.FILE_NOT_EXIST, '文件标识不能为空');
    }

    const client = getR2Client();

    try {
      const command = new DeleteObjectCommand({
        Bucket: uploadConfig.r2.bucketName,
        Key: objectKey
      });
      await client.send(command);
      return true;
    } catch (err) {
      console.error('[R2 文件删除失败]', err);
      throw new BusinessError(ERROR_CODE.R2_DELETE_FAIL, `云端文件删除失败：${err.message}`);
    }
  }
}

module.exports = new UploadService();