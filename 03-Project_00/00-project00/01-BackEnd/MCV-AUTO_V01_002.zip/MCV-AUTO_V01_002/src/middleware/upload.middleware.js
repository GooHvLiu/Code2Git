/**
 * 文件上传中间件
 * 封装 Multer，提供本地磁盘存储和内存存储（用于R2）两种引擎
 * 统一处理文件类型校验、大小限制、错误转换
 */
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const uploadConfig = require('../config/upload.config');
const fileUtil = require('../utils/file');
const { BusinessError } = require('./error.middleware');
const { ERROR_CODE } = require('../constants/errorCode');

// ==================== 存储引擎配置 ====================

/**
 * 本地磁盘存储引擎
 * 文件名：UUID + 原扩展名
 * 路径：按 年/月/日 分层
 */
const diskStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    // 按日期生成子目录
    const dateDir = fileUtil.generateDateDir();
    const fullPath = path.join(uploadConfig.local.dir, dateDir);

    // 递归创建目录（不存在则创建）
    fs.mkdirSync(fullPath, { recursive: true });

    // 将相对目录挂到 req 上，供后续 service 使用
    req._uploadDateDir = dateDir;
    cb(null, fullPath);
  },
  filename: (req, file, cb) => {
    // UUID + 原扩展名
    const newFilename = fileUtil.generateUuidFileName(file.originalname);
    req._uploadFilename = newFilename;
    cb(null, newFilename);
  }
});

/**
 * 内存存储引擎
 * 文件以 Buffer 形式存在内存中（req.file.buffer），用于直接上传到 R2
 * 不落盘，性能更好
 */
const memoryStorage = multer.memoryStorage();

// ==================== 文件过滤 ====================

/**
 * 文件类型过滤器
 * 双重校验：MIME 类型 + 扩展名
 */
function fileFilter(req, file, cb) {
  // 校验 MIME 类型
  if (!fileUtil.isAllowedMimeType(file.mimetype)) {
    return cb(new BusinessError(
      ERROR_CODE.FILE_TYPE_NOT_ALLOWED,
      `不支持的文件类型：${file.mimetype}`
    ), false);
  }

  // 校验扩展名
  if (!fileUtil.isAllowedExtname(file.originalname)) {
    return cb(new BusinessError(
      ERROR_CODE.FILE_TYPE_NOT_ALLOWED,
      `不支持的文件扩展名：${fileUtil.getExtname(file.originalname)}`
    ), false);
  }

  cb(null, true);
}

// ==================== Multer 实例 ====================

/**
 * 本地上传 Multer 实例（磁盘存储）
 */
const localUpload = multer({
  storage: diskStorage,
  fileFilter,
  limits: {
    fileSize: uploadConfig.local.maxSize
  }
});

/**
 * R2 上传 Multer 实例（内存存储）
 */
const r2Upload = multer({
  storage: memoryStorage,
  fileFilter,
  limits: {
    fileSize: uploadConfig.r2.maxSize
  }
});

// ==================== 统一错误处理包装 ====================

/**
 * 包装 Multer 中间件，将 Multer 原生错误转换为 BusinessError
 * @param {Function} multerMiddleware Multer 中间件
 * @returns {Function} Express 中间件
 */
function wrapMulterError(multerMiddleware) {
  return (req, res, next) => {
    multerMiddleware(req, res, (err) => {
      if (err) {
        // Multer 自带错误转换
        if (err instanceof multer.MulterError) {
          switch (err.code) {
            case 'LIMIT_FILE_SIZE':
              return next(new BusinessError(
                ERROR_CODE.FILE_TOO_LARGE,
                `文件大小超出限制，最大允许 ${fileUtil.formatFileSize(uploadConfig.local.maxSize)}`
              ));
            case 'LIMIT_FILE_COUNT':
              return next(new BusinessError(
                ERROR_CODE.FILE_LIMIT_EXCEEDED,
                '上传文件数量超出限制'
              ));
            case 'LIMIT_UNEXPECTED_FILE':
              return next(new BusinessError(
                ERROR_CODE.PARAM_ERROR,
                `意外的文件字段：${err.field}`
              ));
            default:
              return next(new BusinessError(
                ERROR_CODE.FILE_UPLOAD_FAIL,
                `文件上传失败：${err.message}`
              ));
          }
        }
        // BusinessError 直接透传
        return next(err);
      }
      next();
    });
  };
}

// ==================== 导出中间件 ====================

module.exports = {
  // 本地存储 - 单文件上传（字段名 file）
  localSingle: (fieldName = 'file') => wrapMulterError(localUpload.single(fieldName)),

  // 本地存储 - 多文件上传（字段名 files，最大数量可配）
  localArray: (fieldName = 'files', maxCount = 10) =>
    wrapMulterError(localUpload.array(fieldName, maxCount)),

  // 本地存储 - 多字段上传
  localFields: (fields) => wrapMulterError(localUpload.fields(fields)),

  // R2 存储 - 单文件上传（内存模式）
  r2Single: (fieldName = 'file') => wrapMulterError(r2Upload.single(fieldName)),

  // R2 存储 - 多文件上传
  r2Array: (fieldName = 'files', maxCount = 10) =>
    wrapMulterError(r2Upload.array(fieldName, maxCount)),

  // 原始 multer 实例（特殊场景使用）
  localUpload,
  r2Upload
};