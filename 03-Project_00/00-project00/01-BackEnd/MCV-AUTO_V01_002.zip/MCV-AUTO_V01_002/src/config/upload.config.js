/**
 * 文件上传配置
 * 统一管理本地存储与 R2 云存储配置
 */
module.exports = {
  // 本地存储配置
  local: {
    // 上传根目录
    dir: process.env.UPLOAD_DIR || './uploads',
    // 单文件大小限制（默认 10MB）
    maxSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024,
    // 允许的 MIME 类型白名单
    allowedMimeTypes: [
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp',
      'image/bmp',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/plain',
      'application/zip',
      'application/x-zip-compressed'
    ],
    // 允许的扩展名白名单（与 MIME 双重校验）
    allowedExtnames: [
      '.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp',
      '.pdf', '.doc', '.docx', '.xls', '.xlsx',
      '.txt', '.zip'
    ],
    // 静态资源访问前缀（与 app.js 中 express.static 对应）
    staticPrefix: '/uploads'
  },

  // Cloudflare R2 配置（兼容 S3）
  r2: {
    enabled: !!(process.env.R2_ACCOUNT_ID && process.env.R2_ACCESS_KEY_ID),
    accountId: process.env.R2_ACCOUNT_ID || '',
    accessKeyId: process.env.R2_ACCESS_KEY_ID || '',
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || '',
    bucketName: process.env.R2_BUCKET_NAME || '',
    publicUrl: process.env.R2_PUBLIC_URL || '',
    // R2 endpoint 格式：https://<account-id>.r2.cloudflarestorage.com
    endpoint: process.env.R2_ACCOUNT_ID
      ? `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`
      : '',
    // R2 不支持 ACL，强制设为 false
    forcePathStyle: false,
    // 单文件大小限制（R2 单文件最大 5GB，这里默认给 50MB）
    maxSize: 50 * 1024 * 1024
  }
};