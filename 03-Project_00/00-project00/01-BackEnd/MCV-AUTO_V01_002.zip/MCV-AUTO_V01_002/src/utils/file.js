/**
 * 文件处理工具函数
 */
const path = require('path');
const crypto = require('crypto');
const uploadConfig = require('../config/upload.config');

/**
 * 从文件名中提取扩展名（小写，带点）
 * @param {string} filename 原始文件名
 * @returns {string} 如 .jpg .png
 */
function getExtname(filename) {
  if (!filename) return '';
  return path.extname(filename).toLowerCase();
}

/**
 * 校验文件 MIME 类型是否在白名单内
 * @param {string} mimeType MIME 类型
 * @returns {boolean}
 */
function isAllowedMimeType(mimeType) {
  return uploadConfig.local.allowedMimeTypes.includes(mimeType);
}

/**
 * 校验文件扩展名是否在白名单内
 * @param {string} filename 文件名
 * @returns {boolean}
 */
function isAllowedExtname(filename) {
  const ext = getExtname(filename);
  return uploadConfig.local.allowedExtnames.includes(ext);
}

/**
 * 生成 UUID 文件名（UUID + 原扩展名）
 * @param {string} originalName 原始文件名
 * @returns {string} 如 a1b2c3d4-e5f6-7890-abcd-ef1234567890.jpg
 */
function generateUuidFileName(originalName) {
  const ext = getExtname(originalName);
  const uuid = crypto.randomUUID();
  return `${uuid}${ext}`;
}

/**
 * 生成按日期分层的相对路径（年/月/日）
 * @returns {string} 如 2026/08/02
 */
function generateDateDir() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return path.join(year.toString(), month, day).replace(/\\/g, '/');
}

/**
 * 格式化文件大小（人类可读）
 * @param {number} bytes 字节数
 * @returns {string} 如 1.23 MB
 */
function formatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
}

/**
 * 构建本地文件的访问 URL
 * @param {string} relativePath 文件相对路径（如 2026/08/02/xxx.jpg）
 * @param {string} host 可选主机地址
 * @returns {string}
 */
function buildLocalFileUrl(relativePath, host) {
  const prefix = uploadConfig.local.staticPrefix;
  const normalizedPath = relativePath.replace(/\\/g, '/');
  if (host) {
    return `${host.replace(/\/$/, '')}${prefix}/${normalizedPath}`;
  }
  return `${prefix}/${normalizedPath}`;
}

/**
 * 构建 R2 文件的访问 URL
 * @param {string} objectKey R2 对象键
 * @returns {string}
 */
function buildR2FileUrl(objectKey) {
  const publicUrl = uploadConfig.r2.publicUrl.replace(/\/$/, '');
  const normalizedKey = objectKey.replace(/^\//, '');
  return `${publicUrl}/${normalizedKey}`;
}

module.exports = {
  getExtname,
  isAllowedMimeType,
  isAllowedExtname,
  generateUuidFileName,
  generateDateDir,
  formatFileSize,
  buildLocalFileUrl,
  buildR2FileUrl
};