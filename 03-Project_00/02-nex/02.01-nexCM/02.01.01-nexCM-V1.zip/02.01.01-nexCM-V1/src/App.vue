<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "App",
  components: {}
};
</script>

<style scoped lang="less">
html,
body,
#app {
  width: 100vw;
  height: 100vh;
}
</style>
