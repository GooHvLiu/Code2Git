<template>
  <div class="login-page">
    <div class="login-box">
      <h1>nexCM - 管理系统</h1>
      <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item label="用户名" prop="username">
          <el-input type="text" v-model="ruleForm.username" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item :label="'密\xa0\xa0\xa0码'" prop="password">
          <el-input type="password" v-model="ruleForm.password" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="验证码" prop="captchacode">
          <div class="catcha-box">
            <el-input v-model="ruleForm.captchacode"></el-input>
            <img
              height="40"
              v-if="captchaCodeSrc"
              :src="captchaCodeSrc"
              @click="getCaptchaCode"
              style="cursor: pointer"
            />
            <div v-else style="width: 120px; height: 40px; background: #eee; text-align: center; line-height: 40px">
              加载中
            </div>
          </div>
        </el-form-item>
        <el-form-item style="margin-left: -55px">
          <el-button class="loginBtn-box" type="primary" @click="submitForm('ruleForm')">登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import {
  validateUsername,
  getLocalStorage,
  setLocalStorage,
  removeLocalStorage,
  removeSessionStorage
} from "@/common/utils/index.js";
import { LOCALSTORAGE_KEYS, SESSIONSTORAGE_KEYS } from "@/common/constants/storageKey.js";
import { requestCaptchaCodeAPI, requestLoginApi } from "@/common/request/index.js";
import { mapActions } from "vuex";
export default {
  name: "UserLogin",
  components: {},
  data() {
    return {
      ruleForm: {
        username: "",
        password: "",
        captchacode: ""
      },
      rules: {
        username: [
          {
            required: true,
            message: "用户名不能为空",
            trigger: "blur"
          },
          { validator: validateUsername, trigger: "blur" }
        ],
        password: [
          {
            required: true,
            message: "密码不能为空",
            trigger: "blur"
          }
        ],
        captchacode: [
          {
            required: true,
            message: "验证码不能为空",
            trigger: "blur"
          }
        ]
      },
      captchaCodeSrc: ""
    };
  },
  computed: {},
  methods: {
    ...mapActions("userInfo", ["asyncChangeUserInfo"]),

    // 获取验证码
    async getCaptchaCode() {
      try {
        const res = await requestCaptchaCodeAPI();
        // res 一定是code=200的数据，直接使用
        this.ruleForm.captchacode = "";
        const svgText = res.data.img;
        this.captchaCodeSrc = `data:image/svg+xml;utf8,${encodeURIComponent(svgText)}`;
        // 获取到验证码后写入本地 LocalStorage
        setLocalStorage(LOCALSTORAGE_KEYS.CAPTCHA_UUID, res.data.uuid);
      } catch (err) {
        console.error("验证码异常：", err);
        // 验证码接口失败，清空旧图片
        this.captchaCodeSrc = "";
      }
    },

    // 登录提交
    async submitForm(formName) {
      this.$refs[formName].validate(async (valid) => {
        // 如果本地数据格式校验成功
        if (valid) {
          try {
            // 提交服务器校验并返回校验结果
            const ServerValidateData = await requestLoginApi({
              username: this.ruleForm.username,
              password: this.ruleForm.password,
              code: this.ruleForm.captchacode,
              uuid: getLocalStorage(LOCALSTORAGE_KEYS.CAPTCHA_UUID)
            });
            // 校验结果成功
            this.formReset({
              isClearUsername: true,
              isClearPassword: true,
              isClearCode: true,
              isRefreshCaptcha: false
            });
            // 移除本地保存的 二维码唯一标识 数据
            removeLocalStorage(LOCALSTORAGE_KEYS.CAPTCHA_UUID);
            // 移除本地保存的 菜单 数据
            removeSessionStorage(SESSIONSTORAGE_KEYS.TAG_LIST);
            // 保存服务器给的 token
            setLocalStorage(LOCALSTORAGE_KEYS.TOKEN, ServerValidateData.data.token);
            // 进入主页
            this.$router.push("/");
            // 通过 VueX 将 token 对应的全部用户信息保存在 state 里面
            this.asyncChangeUserInfo();
          } catch (err) {
            // 所有非200业务异常、网络异常全部进入catch
            this.formReset({
              isClearUsername: false,
              isClearPassword: true,
              isClearCode: true,
              isRefreshCaptcha: true
            });
          }
        } else {
          // 本地校验失败 表单内容校验失败
          this.formReset({
            isClearUsername: false,
            isClearPassword: true,
            isClearCode: true,
            isRefreshCaptcha: true
          });
        }
      });
    },

    // 状态重置 响应拦截器已经判定不是200代码的都进行了消息弹出
    formReset(clear = {}) {
      // 解析字段
      const { isClearUsername = false, isClearPassword = false, isClearCode = false, isRefreshCaptcha = false } = clear;
      // 根据字段的结果进行
      if (isClearUsername) this.ruleForm.username = "";
      if (isClearPassword) this.ruleForm.password = "";
      if (isClearCode) this.ruleForm.captchacode = "";
      if (isRefreshCaptcha) this.getCaptchaCode();
    }
  },
  created() {
    // 项目被启动时，获取二维码
    this.getCaptchaCode();
    const token = getLocalStorage(LOCALSTORAGE_KEYS.TOKEN);
    // 已有token，跳首页；增加判断：避免目标已经是首页继续跳转
    if (token && this.$route.path !== "/") {
      this.$router.replace("/");
    }
  }
};
</script>

<style scoped lang="less">
.login-page {
  width: 100vw;
  height: 100vh;
  background: linear-gradient(-45deg, #6a11cb, #2575fc, #36d1dc, #5b86e5);
  background-size: 400% 400%;
  animation: gradientMove 15s ease infinite;
  position: relative;
  .login-box {
    width: 400px;
    background-color: #fff;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    padding-right: 40px;
    border-radius: 20px;
    h1 {
      text-align: center;
      margin-top: 20px;
      margin-bottom: 40px;
      padding-left: 20px;
      font-size: 1.6rem;
      color: gray;
    }
    .catcha-box {
      display: flex;
      img {
        margin-left: 10px;
      }
    }
    .loginBtn-box {
      width: 355px;
    }
  }
}
@keyframes gradientMove {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}
</style>
