/**
 * ==========================================
 * English Language Pack
 * ==========================================
 * Grouped by module, add new text here
 * Keep structure consistent with zh-CN.js
 */
export default {
  // ==================== Common ====================
  common: {
    confirm: 'Confirm',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    edit: 'Edit',
    add: 'Add',
    search: 'Search',
    reset: 'Reset',
    export: 'Export',
    exportExcel: 'Export Excel',
    exportPdf: 'Export PDF',
    selected: 'Selected',
    import: 'Import',
    // Export PDF subtitle labels
    exportLabels: {
      exporter: 'Exporter',
      time: 'Export Time',
      countPrefix: 'Total',
      countSuffix: 'records'
    },
    refresh: 'Refresh',
    operation: 'Action',
    status: 'Status',
    index: 'No.',
    createTime: 'Create Time',
    updateTime: 'Update Time',
    loading: 'Loading...',
    success: 'Success',
    failed: 'Failed',
    tip: 'Tip',
    warning: 'Warning',
    error: 'Error',
    untitled: 'Untitled',
    redirect: 'Redirect',
    systemName: 'nexCM Basic',
    systemDESC: 'Movable Filling and Stoppering Machine',
    electronicSignature: 'Electronic Signature',
    operator: 'Operator',
    reason: 'Reason',
    reasonPlaceholder: 'Please enter the reason for operation (GMP required)',
    reasonRequired: 'Please enter the reason',
    reasonMinLength: 'Reason must be at least 2 characters',
    password: 'Password',
    passwordPlaceholder: 'Enter password for electronic signature',
    passwordRequired: 'Please enter password',
    sessionTimeout: 'Session timed out, please login again'
  },

  // ==================== Login ====================
  login: {
    title: 'Welcome',
    username: 'Username',
    password: 'Password',
    captcha: 'Captcha',
    loginBtn: 'Login',
    registerBtn: 'Register',
    registerTitle: 'Register',
    email: 'Email',
    confirmPassword: 'Confirm Password',
    hasAccount: 'Already have an account?',
    loginNow: 'Login Now',
    noAccount: "Don't have an account?",
    registerNow: 'Register Now',
    usernameRequired: 'Username is required',
    passwordRequired: 'Password is required',
    captchaRequired: 'Captcha is required',
    emailRequired: 'Email is required',
    confirmPasswordRequired: 'Please confirm your password',
    registerSuccess: 'Registration successful, please login'
  },

  // ==================== Layout ====================
  layout: {
    home: 'Home',
    profile: 'Profile',
    userManagement: 'Users',
    auditLog: 'Audit Log',
    logout: 'Logout',
    user: 'User',
    searchMenu: 'Search menu...',
    tagsView: {
      refresh: 'Refresh',
      close: 'Close',
      closeOthers: 'Close Others',
      closeLeft: 'Close Left',
      closeRight: 'Close Right',
      closeAll: 'Close All'
    }
  },

  // ==================== Error Page ====================
  error: {
    notFound: 'Page Not Found',
    backHome: 'Back Home',
    back: 'Go Back',
    countdown: 'Returning home in {count}s',
    forbidden: 'Sorry, you do not have access',
    forbiddenDesc: 'This page requires specific permissions, please contact the administrator',
    forbiddenTitle: 'Forbidden'
  },

  // ==================== Home ====================
  home: {
    welcome: 'Welcome',
    admin: 'Administrator'
  },

  // ==================== Theme Settings ====================
  theme: {
    quickMenu: 'Quick Menu',
    palette: 'Theme Palette',
    language: 'Language',
    resetAll: 'Reset All',
    reset: 'Reset',
    custom: 'Custom',
    switchedToZh: '已切换为中文',
    switchedToEn: 'Switched to English',
    sidebarBg: 'Sidebar Background Color',
    sidebarHoverText: 'Sidebar Hover Text',
    sidebarHoverBg: 'Sidebar Hover Background',
    sidebarIconColor: 'Sidebar Icon Color',
    sidebarActiveBg: 'Active Menu Background'
  },

  // ==================== Profile ====================
  profile: {
    title: 'Profile',
    basicInfo: 'Basic Info',
    username: 'Username',
    realName: 'Real Name',
    sex: 'Gender',
    email: 'Email',
    phone: 'Phone',
    role: 'Role',
    status: 'Status',
    createTime: 'Create Time',
    sexMale: 'Male',
    sexFemale: 'Female',
    sexUnknown: 'Unknown',
    roleAdministrator: 'Administrator',
    roleEngineer: 'Engineer',
    roleOperator: 'Operator',
    statusEnabled: 'Enabled',
    statusDisabled: 'Disabled',
    changePassword: 'Change Password',
    oldPassword: 'Old Password',
    newPassword: 'New Password',
    confirmPassword: 'Confirm Password'
  },

  // ==================== User Management ====================
  user: {
    title: 'User Management',
    username: 'Username',
    password: 'Password',
    realName: 'Real Name',
    sex: 'Gender',
    sexUnknown: 'Unknown',
    sexMale: 'Male',
    sexFemale: 'Female',
    email: 'Email',
    phone: 'Phone',
    role: 'Role',
    status: 'Status',
    createTime: 'Create Time',
    operation: 'Action',
    addUser: 'Add User',
    editUser: 'Edit User',
    enable: 'Enable',
    disable: 'Disable',
    resetPassword: 'Reset Password',
    remark: 'Remark',
    roleAdministrator: 'Administrator',
    roleEngineer: 'Engineer',
    roleOperator: 'Operator',
    usernamePlaceholder: 'Enter username',
    passwordPlaceholder: 'Enter password',
    realNamePlaceholder: 'Enter real name',
    emailPlaceholder: 'Enter email',
    phonePlaceholder: 'Enter phone',
    rolePlaceholder: 'Select role',
    remarkPlaceholder: 'Enter remark',
    usernameLength: 'Length between 2 and 50 characters',
    passwordLength: 'Length between 6 and 32 characters',
    emailInvalid: 'Please enter a valid email address',
    deleteConfirm: 'Are you sure to delete user "{name}"?',
    batchDeleteConfirm: 'Are you sure to delete {count} selected users?',
    deleteSuccess: 'Deleted successfully',
    batchDeleteSuccess: 'Batch deleted successfully',
    exportFileName: 'UserList',
    resetPasswordTitle: 'Reset Password',
    resetPasswordPlaceholder: 'Enter new password',
    resetPasswordError: 'Password length 6-20 characters',
    resetPasswordSuccess: 'Password reset successfully'
  },

  // ==================== Audit Log ====================
  audit: {
    title: 'Audit Log',
    myTitle: 'My Activity',
    userName: 'Operator',
    action: 'Action',
    target: 'Target',
    oldValue: 'Old Value',
    newValue: 'New Value',
    result: 'Result',
    success: 'Success',
    failed: 'Failed',
    ip: 'IP Address',
    createdAt: 'Time',
    timeRange: 'Time Range',
    startTime: 'Start Time',
    endTime: 'End Time'
  }
}
