/**
 * ==========================================
 * English Language Pack
 * ==========================================
 * Grouped by module, add new text here
 * Keep structure consistent with zh-CN.js
 */
export default {
  // ==================== Common ====================
  common: {
    confirm: 'Confirm',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    edit: 'Edit',
    add: 'Add',
    search: 'Search',
    reset: 'Reset',
    export: 'Export',
    exportExcel: 'Export Excel',
    exportPdf: 'Export PDF',
    selected: 'Selected',
    import: 'Import',
    // Export PDF subtitle labels
    exportLabels: {
      exporter: 'Exporter',
      time: 'Export Time',
      countPrefix: 'Total',
      countSuffix: 'records'
    },
    refresh: 'Refresh',
    operation: 'Action',
    status: 'Status',
    index: 'No.',
    sort: 'Sort',
    description: 'Description',
    remark: 'Remark',
    enable: 'Enable',
    all: 'All',
    disable: 'Disable',
    createTime: 'Create Time',
    updateTime: 'Update Time',
    loading: 'Loading...',
    success: 'Success',
    failed: 'Failed',
    tip: 'Tip',
    warning: 'Warning',
    error: 'Error',
    untitled: 'Untitled',
    redirect: 'Redirect',
    systemName: 'nexCM Manager Std.',
    systemDESC: 'Benchtop Filling and Stoppering Machine',
    electronicSignature: 'Electronic Signature',
    featureComingSoon: 'Coming Soon',
    noDataToExport: 'No data to export',
    operator: 'Operator',
    reason: 'Reason',
    reasonPlaceholder: 'Please enter the reason for operation (GMP required)',
    reasonRequired: 'Please enter the reason',
    reasonMinLength: 'Reason must be at least 2 characters',
    password: 'Password',
    passwordPlaceholder: 'Enter password for electronic signature',
    passwordRequired: 'Please enter password',
    sessionTimeout: 'Session timed out, please login again'
  },

  // ==================== Login ====================
  login: {
    title: 'Welcome',
    username: 'Username',
    password: 'Password',
    captcha: 'Captcha',
    loginBtn: 'Login',
    registerBtn: 'Register',
    registerTitle: 'Register',
    email: 'Email',
    confirmPassword: 'Confirm Password',
    hasAccount: 'Already have an account?',
    loginNow: 'Login Now',
    noAccount: "Don't have an account?",
    registerNow: 'Register Now',
    usernameRequired: 'Username is required',
    passwordRequired: 'Password is required',
    captchaRequired: 'Captcha is required',
    emailRequired: 'Email is required',
    confirmPasswordRequired: 'Please confirm your password',
    registerSuccess: 'Registration successful, please login'
  },

  // ==================== Layout ====================
  layout: {
    // 网站首页
    home: 'Home',
    homeOverview: 'Overview',
    homeDashboard: 'Dashboard',
    homeData: 'DataView',

    // 设备管理
    deviceManagement: 'Device',
    deviceState: 'DevState',
    alarmLog: 'AlarmLog',
    partLife: 'PartLife',

    // 生产管理
    productionManagement: 'Production',
    recipeManagement: 'RecipeDB',
    orderManagement: 'OrderLog',

    // 系统配置
    systemSettings: 'Settings',
    dictManagement: 'DictData',
    deptManagement: 'OrgMgmt',
    roleManagement: 'UserRole',
    userManagement: 'UserData',
    auditLog: 'AuditLog',
    systemConfig: 'ConfData',

    // 个人中心
    profile: 'Profile',

    // 通知中心
    notificationCenter: 'NotifLog',

    // 退出登录
    logout: 'Logout',

    // 用户
    user: 'User',

    // 搜索
    searchMenu: 'Search menu...',

    // 面包屑
    tagsView: {
      refresh: 'Refresh',
      close: 'Close',
      closeOthers: 'Close Others',
      closeLeft: 'Close Left',
      closeRight: 'Close Right',
      closeAll: 'Close All'
    }
  },

  // ==================== Data Dictionary ====================
  dict: {
    typeList: 'Dictionary Types',
    itemList: 'Dictionary Items',
    typeName: 'Type Name',
    typeCode: 'Type Code',
    typeCodePlaceholder: 'Start with letter, e.g. user_status',
    itemLabel: 'Label',
    itemValue: 'Value',
    itemValuePlaceholder: 'e.g. 1/0',
    itemStatus: 'Status',
    addType: 'Add Dictionary Type',
    editType: 'Edit Dictionary Type',
    addItem: 'Add Dictionary Item',
    editItem: 'Edit Dictionary Item',
    typeNameRequired: 'Please enter dictionary type name',
    typeCodeRequired: 'Please enter dictionary type code',
    itemLabelRequired: 'Please enter dictionary item label',
    itemValueRequired: 'Please enter dictionary item value',
    deleteTypeConfirm: 'Delete this dictionary type? All items will be deleted too.',
    deleteItemConfirm: 'Delete this dictionary item?'
  },

  // ==================== Role Management ====================
  role: {
    title: 'Role Management',
    roleName: 'Role Name',
    roleCode: 'Role Code',
    permission: 'Permission',
    permissionTitle: 'Menu Permission',
    permissionSuccess: 'Permission updated successfully',
    addRole: 'Add Role',
    editRole: 'Edit Role',
    roleNameRequired: 'Please enter role name',
    roleCodeRequired: 'Please enter role code',
    deleteConfirm: 'Delete this role?'
  },

  // ==================== Organization Management ====================
  dept: {
    title: 'Organization Management',
    deptName: 'Department Name',
    deptNamePlaceholder: 'Please enter department name',
    orderNum: 'Sort',
    leader: 'Leader',
    phone: 'Phone',
    email: 'Email',
    parentDept: 'Parent Dept',
    addChild: 'Add Child Dept',
    addDept: 'Add Department',
    editDept: 'Edit Department',
    deptNameRequired: 'Please enter department name',
    deleteConfirm: 'Delete this department?'
  },

  // ==================== Notification Center ====================
  notification: {
    // Page title
    title: 'Notification Center',
    center: 'Notifications',
    viewAll: 'View All',
    notificationSettings: 'Notification Settings',

    // General
    type: 'Type',
    content: 'Content',
    refresh: 'Refresh',
    export: 'Export',
    empty: 'No notifications',

    // Action buttons
    markAllRead: 'Mark All Read',
    markRead: 'Mark Read',
    delete: 'Delete',
    archive: 'Archive',
    unarchive: 'Restore',
    batchMarkRead: 'Batch Mark Read',
    batchArchive: 'Batch Archive',
    batchUnarchive: 'Batch Restore',
    batchDelete: 'Batch Delete',
    clearSelection: 'Clear Selection',
    selectedCount: '{count} items selected',

    // Status
    all: 'All',
    unread: 'Unread',
    read: 'Read',

    // Archive
    unarchived: 'Unarchived',
    archived: 'Archived',

    // Priority
    priority: 'Priority',
    priorityHigh: 'High Priority',
    priorityMedium: 'Medium Priority',
    priorityLow: 'Low Priority',

    // Time range
    timeRange: 'Time Range',
    today: 'Today',
    thisWeek: 'This Week',
    thisMonth: 'This Month',
    custom: 'Custom',
    startDate: 'Start Date',
    endDate: 'End Date',
    to: 'to',

    // Search
    searchPlaceholder: 'Search notification title or content',
    search: 'Search',
    reset: 'Reset',

    // Notification type names
    typeSystem: 'System Settings',
    typePlc: 'Device Management',
    typeUser: 'User Management',
    typeAudit: 'Audit Trail',
    typeDevice: 'Device Parameters',
    typeConnection: 'Connection Config',

    // Success/failure messages
    markReadSuccess: 'Marked as read',
    markAllSuccess: 'All marked as read',
    deleteSuccess: 'Deleted successfully',
    batchDeleteSuccess: 'Batch deleted successfully',
    archiveSuccess: 'Archived successfully',
    batchArchiveSuccess: 'Batch archived successfully',
    unarchiveSuccess: 'Restored successfully',
    batchUnarchiveSuccess: 'Batch restored successfully',
    operationFailed: 'Operation failed',

    // Confirm dialogs
    deleteConfirm: 'Delete this notification?',
    batchDeleteConfirm: 'Delete {count} selected notifications?',
    markAllConfirm: 'Mark all notifications as read?',
    deleteWarning: 'This cannot be undone',

    // Time display
    justNow: 'just now',
    minutesAgo: ' min ago',
    hoursAgo: ' hours ago',
    daysAgo: ' days ago',
    createdAt: 'Created At',

    // ==================== Notification content templates (i18n key + dynamic params) ====================
    // User related
    user: {
      register: {
        title: 'New User Registered',
        content: 'User {username} has registered, please review promptly'
      },
      profileUpdate: {
        title: 'User Profile Updated',
        content: 'User {username} modified their profile'
      }
    },

    // System config related
    config: {
      systemUpdate: {
        title: 'System Config Updated',
        content: 'User {username} modified {count} system config(s)'
      },
      plcConnectionUpdate: {
        title: 'Device Connection Config Updated',
        content: 'User {username} modified {count} device connection config(s)'
      },
      connectionUpdate: {
        title: 'Connection Config Updated',
        content: 'User {username} modified {count} connection config(s)'
      },
      deviceParamsUpdate: {
        title: 'Device Parameter Config Updated',
        content: 'User {username} modified {count} device parameter config(s)'
      }
    },

    // PLC related
    plc: {
      alarm: {
        title: 'Device Alarm',
        content: 'Device alarm: {alarmMessage}'
      },
      connectionLost: {
        title: 'Device Connection Lost',
        content: 'Device connection lost: {deviceName}'
      },
      connectionRestored: {
        title: 'Device Connection Restored',
        content: 'Device connection restored: {deviceName}'
      }
    },

    // ==================== Notification Settings ====================
    settings: {
      title: 'Notification Settings',
      notificationTypes: 'Notification Types',
      typeEnabled: 'Enabled',
      doNotDisturb: 'Do Not Disturb',
      doNotDisturbEnabled: 'Enable Do Not Disturb',
      startTime: 'Start Time',
      endTime: 'End Time',
      reminderMethods: 'Reminder Methods',
      reminderMethodsDesc: 'Customize notification reminder methods',
      soundEnabled: 'Notification Sound',
      popupEnabled: 'Popup Reminder',
      save: 'Save Settings',
      saveSuccess: 'Settings saved successfully',
      system: 'System Settings Notifications',
      plc: 'Device Management Notifications',
      user: 'User Management Notifications',
      audit: 'Audit Trail Notifications',
      device: 'Device Parameter Notifications',
      connection: 'Connection Config Notifications'
    }
  },

  // ==================== Error Page ====================
  errorPage: {
    notFound: 'Page Not Found',
    backHome: 'Back Home',
    back: 'Go Back',
    countdown: 'Returning home in {count}s',
    forbidden: 'Sorry, you do not have access',
    forbiddenDesc: 'This page requires specific permissions, please contact the administrator',
    forbiddenTitle: 'Forbidden'
  },

  // ==================== Home ====================
  home: {
    welcome: 'Welcome',
    admin: 'Administrator'
  },

  // ==================== Theme Settings ====================
  theme: {
    quickMenu: 'Quick Menu',
    palette: 'Theme Palette',
    language: 'Language',
    resetAll: 'Reset All',
    reset: 'Reset',
    custom: 'Custom',
    switchedToZh: '已切换为中文',
    switchedToEn: 'Switched to English',
    sidebarBg: 'Sidebar Background Color',
    sidebarHoverText: 'Sidebar Hover Text',
    sidebarHoverBg: 'Sidebar Hover Background',
    sidebarIconColor: 'Sidebar Icon Color',
    sidebarActiveBg: 'Active Menu Background'
  },

  // ==================== Profile ====================
  profile: {
    title: 'Profile',
    basicInfo: 'Basic Info',
    username: 'Username',
    realName: 'Real Name',
    sex: 'Gender',
    email: 'Email',
    phone: 'Phone',
    role: 'Role',
    status: 'Status',
    createTime: 'Create Time',
    sexMale: 'Male',
    sexFemale: 'Female',
    sexUnknown: 'Unknown',
    roleAdministrator: 'Administrator',
    roleEngineer: 'Engineer',
    roleOperator: 'Operator',
    statusEnabled: 'Enabled',
    statusDisabled: 'Disabled',
    changePassword: 'Change Password',
    oldPassword: 'Old Password',
    newPassword: 'New Password',
    confirmPassword: 'Confirm Password'
  },

  // ==================== User Management ====================
  user: {
    title: 'User Management',
    username: 'Username',
    password: 'Password',
    realName: 'Real Name',
    sex: 'Gender',
    sexUnknown: 'Unknown',
    sexMale: 'Male',
    sexFemale: 'Female',
    email: 'Email',
    phone: 'Phone',
    role: 'Role',
    dept: 'Department',
    status: 'Status',
    createTime: 'Create Time',
    operation: 'Action',
    addUser: 'Add User',
    editUser: 'Edit User',
    enable: 'Enable',
    disable: 'Disable',
    resetPassword: 'Reset Password',
    remark: 'Remark',
    roleAdministrator: 'Administrator',
    roleEngineer: 'Engineer',
    roleOperator: 'Operator',
    usernamePlaceholder: 'Enter username',
    passwordPlaceholder: 'Enter password',
    realNamePlaceholder: 'Enter real name',
    emailPlaceholder: 'Enter email',
    phonePlaceholder: 'Enter phone',
    rolePlaceholder: 'Select role',
    deptPlaceholder: 'Select department',
    remarkPlaceholder: 'Enter remark',
    usernameLength: 'Length between 2 and 50 characters',
    passwordLength: 'Length between 6 and 32 characters',
    emailInvalid: 'Please enter a valid email address',
    deleteConfirm: 'Are you sure to delete user "{name}"?',
    batchDeleteConfirm: 'Are you sure to delete {count} selected users?',
    deleteSuccess: 'Deleted successfully',
    batchDeleteSuccess: 'Batch deleted successfully',
    exportFileName: 'UserList',
    resetPasswordTitle: 'Reset Password',
    resetPasswordPlaceholder: 'Enter new password',
    resetPasswordError: 'Password length 6-20 characters',
    resetPasswordSuccess: 'Password reset successfully'
  },

  // ==================== Audit Log ====================
  audit: {
    title: 'Audit Log',
    myTitle: 'My Activity',
    userName: 'Operator',
    action: 'Action',
    target: 'Target',
    oldValue: 'Old Value',
    newValue: 'New Value',
    result: 'Result',
    success: 'Success',
    failed: 'Failed',
    ip: 'IP Address',
    createdAt: 'Time',
    timeRange: 'Time Range',
    startTime: 'Start Time',
    endTime: 'End Time'
  },

  // ==================== System Config ====================
  systemConfig: {
    title: 'System Configuration',
    desc: 'Customize system parameters, including system settings, security settings, device connection, export configuration, etc.',
    save: 'Save',
    reset: 'Reset',
    saveSuccess: 'Configuration saved successfully',
    resetSuccess: 'Configuration reset to default',
    resetConfirm: 'Are you sure to reset to default configuration?',
    loadFailed: 'Failed to load configuration',
    saveFailed: 'Failed to save configuration',
    resetFailed: 'Failed to reset configuration',
    system: {
      title: 'System Config',
      sessionTimeout: 'Session Timeout',
      minutes: 'minutes',
      defaultPageSize: 'Default Page Size',
      defaultLanguage: 'Default Language',
      dateFormat: 'Date Format'
    },
    security: {
      title: 'Security Config',
      watermarkEnabled: 'Enable Watermark',
      watermarkText: 'Watermark Text',
      watermarkPlaceholder: 'Use current username if empty'
    },
    plc: {
      title: 'Device Connect',
      protocol: 'Protocol',
      host: 'Device IP Address',
      port: 'Device Port',
      unitId: 'Unit ID',
      pollSettings: 'Poll Settings',
      pollFast: 'Fast Poll Interval',
      pollSlow: 'Slow Poll Interval'
    },
    export: {
      title: 'Export Config',
      pdfWatermarkEnabled: 'PDF Export Watermark',
      pdfWatermarkText: 'PDF Watermark Text',
      pdfWatermarkPlaceholder: 'Use current username if empty'
    },
    connection: {
      title: 'Network Config',
      heartbeatInterval: 'Heartbeat Interval'
    },
    device: {
      title: 'Device Config',
      deviceName: 'Device Name',
      deviceCode: 'Device Code',
      deviceRegion: 'Location',
      deviceInstallDate: 'Install Date',
      partLifeSettingsTitle: 'Part Life Reminder Settings',
      partLifeReminderEnabled: 'Part Life Reminder',
      partLifeReminderEnabledTip: 'When enabled, automatically pop up reminder when part life reaches threshold',
      partLifeThreshold: 'Reminder Threshold',
      partLifeThresholdTip: 'Remind when remaining life reaches this percentage',
      partLifeRemindInterval: 'Reminder Interval',
      partLifeRemindIntervalTip: 'After life expires, pop up warning at this interval. The popup is draggable and closable.',
      snoozeInterval: 'Snooze Interval',
      snoozeIntervalTip: 'After clicking "Remind Later", pop up again after this interval.',
      snooze5min: '5 Minutes',
      snooze10min: '10 Minutes',
      snooze30min: '30 Minutes',
      snooze1hour: '1 Hour',
      snooze2hour: '2 Hours',
      intervalHour: 'Every Hour',
      intervalShift: 'Every Shift',
      intervalDay: 'Every Day',
      // 警告弹窗相关
      reminderTitle: 'Part Life Reminder',
      reminderClose: 'Close',
      reminderRemindLater: 'Remind Later',
      reminderViewDetail: 'View Details',
      reminderContent: 'The following parts have reached the reminder threshold, please replace them in time:',
      reminderNoData: 'No parts need to be reminded currently'
    },
    order: {
      title: 'Order Config',
      productionControl: 'Production Control',
      statDisplay: 'Statistics Display',
      reportConfig: 'Report Settings',
      allowNoOrderProduction: 'Allow Production Without Order',
      allowNoOrderProductionTip: 'When disabled, equipment cannot run without an order',
      noOrderProductionHighlight: 'Highlight No-Order Production',
      noOrderProductionHighlightTip: 'Requires "Allow Production Without Order" enabled',
      orderSwitchConfirm: 'Confirm Before Switching Order',
      autoArchiveCompleted: 'Auto Archive Completed Orders',
      showOperatorName: 'Show Operator Name',
      showAlarmCount: 'Show Total Alarm Count',
      showRuntime: 'Show Total Runtime',
      reportIncludeAlarmDetail: 'Include Alarm Details in Report',
      reportIncludeOperatorDetail: 'Include Operator Details in Report',
      reportIncludeDownloadCount: 'Include Download Count in Report',
      allowRunningOrderDownload: 'Allow Download for Running Orders',
      allowRunningOrderDownloadTip: 'Running order data is incomplete, enable with caution'
    }
  },

  // ==================== License ====================
  license: {
    importTitle: 'License Import',
    manageTitle: 'License Mgmt',
    statusValid: 'License Valid',
    statusInvalid: 'License Invalid',
    statusChecking: 'Checking License',
    statusCheckingTip: 'Please wait...',
    statusTrial: 'Trial License',
    statusFormal: 'Formal License',
    statusPermanent: 'Permanent License',
    licenseFile: 'License File',
    importLicense: 'Import License',
    importSuccess: 'License imported successfully',
    importFailed: 'License import failed',
    selectFile: 'Select License File',
    dragFileHere: 'Drag license file here, or',
    clickUpload: 'click to upload',
    fileFormatTip: 'Only .lic license files are supported',
    noLicense: 'No license file imported yet',
    licenseInfo: 'License Info',
    customerName: 'Customer Name',
    projectName: 'Project Name',
    licenseType: 'License Type',
    expireTime: 'Expire Time',
    machineId: 'Machine ID',
    machineBind: 'Machine Binding',
    timeGuard: 'Time Protection',
    syncTime: 'Sync Time',
    syncTimeSuccess: 'Time synced successfully',
    syncTimeFailed: 'Time sync failed',
    downloadLicense: 'Download License',
    downloadFailed: 'Download failed',
    copyMachineId: 'Copy Machine ID',
    copySuccess: 'Copied successfully',
    features: 'Features',
    issuedAt: 'Issued At',
    notBound: 'Not Bound',
    refresh: 'Refresh',
    download: 'Download',
    remaining: 'Remaining',
    detailTitle: 'License Details',
    licenseId: 'License ID',
    projectId: 'Project ID',
    contact: 'Contact',
    phone: 'Phone',
    email: 'Email',
    maxUsers: 'Max Users',
    allFeatures: 'All Features',
    currentMachineId: 'Current Machine ID',
    boundMachineId: 'Bound Machine ID',
    notBoundAny: 'Not Bound (Any Machine)',
    matchStatus: 'Match Status',
    matched: 'Matched',
    notMatched: 'Not Matched',
    timeGuardStatus: 'Time Guard',
    enabled: 'Enabled',
    notInitialized: 'Not Initialized',
    lastVerified: 'Last Verified',
    serverTime: 'Server Time',
    operation: 'Operation',
    networkDiagnosis: 'Network Diagnosis',
    fileInfo: 'License File Info',
    adminOnly: 'Admin Only',
    filePath: 'File Path',
    fileName: 'File Name',
    fileSize: 'File Size',
    lastModified: 'Last Modified',
    noLicenseFile: 'License file not found, please import first',
    importDialogTitle: 'Import License File',
    importTip: 'Please upload a .lic license file issued by Beehive License Manager',
    dragUpload: 'Drag .lic file here, or click to upload',
    cancel: 'Cancel',
    confirmImport: 'Confirm Import',
    networkDiagnosisSuccess: 'Network diagnosis successful',
    networkDiagnosisFailed: 'Network diagnosis failed, please check network',
    unknownReason: 'Unknown reason',
    timeRemaining: 'Time Remaining',
    expireAt: 'Expire At',
    licenseStatus: 'License Status',
    expired: 'Expired',
    importNewLicense: 'Please import a new license file',
    // License import page
    brandTitle: 'Software License Manager',
    brandDesc: 'Beehive License Manager',
    featureRsa: 'RSA Asymmetric Signature',
    featureTimeGuard: 'Anti-Time Rollback',
    featureMachineBind: 'Machine Fingerprint Binding',
    importFormTitle: 'Import License File',
    dragUploadTip: 'Drag .lic license file here, or click to upload',
    fileSizeTip: 'Only .lic license files supported, max 1MB',
    remove: 'Remove',
    importSuccessTitle: 'License Imported Successfully',
    project: 'Project',
    unlimited: 'Unlimited',
    enterSystem: 'Enter System',
    refreshStatus: 'Refresh Status',
    cannotGetStatus: 'Cannot get license status, please check backend service',
    pleaseSelectFile: 'Please select a license file first',
    permanentValid: 'Permanent Valid',
    typeTrial: 'Trial',
    typeStandard: 'Standard',
    typeEnterprise: 'Enterprise',
    typePerpetual: 'Perpetual',
    // License invalid reasons
    reasonFileNotFound: 'License file not found or verification failed',
    reasonProjectMismatch: 'License project mismatch',
    reasonMachineMismatch: 'License does not match current machine (hardware binding)',
    reasonExpired: 'License has expired',
    reasonMissingFeatures: 'Missing feature authorization',
    reasonTimeRollback: 'Time rollback detected, please calibrate system time',
    reasonNetworkSyncFailed: 'Network calibration failed, please check network connection',
    reasonUnknown: 'License verification failed',
    // Machine ID
    copy: 'Copy',
    copyFailed: 'Copy failed',
    machineIdTip: 'For authorization, please provide this machine ID to the supplier'
  },

  // ==================== Recipe Management ====================
  recipe: {
    title: 'Recipe Management',
    desc: 'Equipment recipe parameter management and intelligent analysis',
    recipe: 'Recipe',
    recipeList: 'Recipe List',
    inUse: 'In Use',
    notInUse: 'Not In Use',
    download: 'Download',
    downloadAll: 'Download All',
    exportExcel: 'Export Excel',
    exportPdf: 'Export PDF',
    basicInfo: 'Basic Info',
    axisParams: 'Axis Parameters',
    speedParams: 'Speed Parameters',
    delayParams: 'Delay & Process Parameters',
    analysis: 'Intelligent Analysis',
    recipeCode: 'Recipe Code',
    recipeName: 'Recipe Name',
    namePlaceholder: 'Enter recipe name',
    nameNotEmpty: 'Recipe name cannot be empty',
    nameUpdateSuccess: 'Recipe name updated successfully',
    productType: 'Product Type',
    fillVolume: 'Fill Volume',
    lastUsed: 'Last Used',
    paramName: 'Parameter',
    paramValue: 'Value',
    paramUnit: 'Unit',
    fillAngle: 'Fill Angle',
    suckBackAngle: 'Suck-back Angle',
    fillAxisInit: 'Fill Axis Init Pos',
    fillAxisReach: 'Fill Axis Reach Pos',
    fixAxisInit: 'Fix Axis Init Pos',
    fixAxisReach: 'Fix Axis Reach Pos',
    fixAxisPreLift: 'Fix Axis Pre-lift Pos',
    stopperAxisInit: 'Stopper Axis Init Pos',
    stopperAxisPrePress: 'Stopper Axis Pre-press Pos',
    stopperAxisReach: 'Stopper Axis Reach Pos',
    fillAxisInitSpeed: 'Fill Axis Init Speed',
    fillAxisReachSpeed: 'Fill Axis Reach Speed',
    fixAxisInitSpeed: 'Fix Axis Init Speed',
    fixAxisReachSpeed: 'Fix Axis Reach Speed',
    fixAxisPreLiftSpeed: 'Fix Axis Pre-lift Speed',
    stopperAxisInitSpeed: 'Stopper Axis Init Speed',
    stopperAxisPrePressSpeed: 'Stopper Axis Pre-press Speed',
    stopperAxisReachSpeed: 'Stopper Axis Reach Speed',
    fillDelay: 'Fill Delay',
    vacuumDelay: 'Vacuum Delay',
    fillSpeed: 'Fill Speed',
    suckBackSpeed: 'Suck-back Speed',
    usageCount: 'Usage Count',
    faultRate: 'Fault Rate',
    avgQualifiedRate: 'Avg Qualified Rate'
  },

  // ==================== Order Management ====================
  order: {
    title: 'Order Management',
    desc: 'Production order management and report export',
    completed: 'Completed',
    running: 'In Progress',
    planned: 'Planned',
    orderNo: 'Order No.',
    productName: 'Product Name',
    recipeName: 'Recipe',
    batchNo: 'Batch No.',
    targetQty: 'Target Qty',
    completedQty: 'Completed Qty',
    qualifiedQty: 'Qualified Qty',
    unqualifiedQty: 'Unqualified Qty',
    qualifiedRate: 'Qualified Rate',
    operator: 'Operator',
    startTime: 'Start Time',
    endTime: 'End Time',
    runtime: 'Runtime',
    alarmCount: 'Alarm Count',
    status: 'Status',
    progress: 'Progress',
    estimatedEnd: 'Est. End',
    priority: 'Priority',
    queuePosition: 'Queue Pos.',
    downloadCount: 'Download Count',
    download: 'Download Report',
    downloadSelected: 'Download Selected',
    downloadAll: 'Download All',
    exportPdf: 'Export PDF Report',
    noOrderProduction: 'No-Order Production',
    orderReport: 'Production Order Report',
    reportBasicInfo: 'Basic Information',
    reportProductionStats: 'Production Statistics',
    reportQualityStats: 'Quality Statistics',
    reportAlarmDetail: 'Alarm Details',
    reportOperatorDetail: 'Operator Details',
    reportGeneratedBy: 'Generated By',
    reportGeneratedAt: 'Generated At',
    high: 'High',
    normal: 'Normal',
    low: 'Low',
    statusCompleted: 'Completed',
    statusRunning: 'In Production',
    statusPlanned: 'Pending',
    selectOrderTip: 'Please select orders to download',
    plannedNoDownload: 'Planned orders do not support report download',
    runningNoDownload: 'Running orders do not support report download yet (enable in system settings)'
  },

  // ==================== Heartbeat / Connection Status ====================
  heartbeat: {
    // Status text (shown in navbar)
    statusOnline: 'Online',
    statusOffline: 'Offline',
    statusAuthenticating: 'Authenticating...',
    statusDeviceDisconnected: 'Device Offline',
    statusReconnecting: 'Reconnecting({count})',
    // Server status
    serverConnected: 'Server: Connected',
    serverDisconnected: 'Server: Disconnected',
    serverAuthenticating: 'Server: Authenticating',
    serverReconnecting: 'Server: Reconnecting (Attempt {count})',
    // Device status
    deviceConnected: 'Device: Connected',
    deviceDisconnected: 'Device: Disconnected',
    // Detail dialog
    detailTitle: 'Connection Status Details',
    detailServerConnected: 'Server Status: Connected ✓',
    detailServerDisconnected: 'Server Status: Disconnected ✗',
    detailServerAuthenticating: 'Server Status: Authenticating...',
    detailServerReconnecting: 'Server Status: Reconnecting (Attempt {count})',
    detailDeviceConnected: 'Device Status: Connected ✓',
    detailDeviceDisconnected: 'Device Status: Disconnected ✗',
    detailLastHeartbeat: 'Last Heartbeat: {time}',
    detailHeartbeatInterval: 'Heartbeat Interval: {seconds}s',
    confirm: 'OK',
    // Relative time
    timeNever: 'Never',
    timeSecondsAgo: '{n}s ago',
    timeMinutesAgo: '{n}m ago',
    timeHoursAgo: '{n}h ago'
  },

  // ==================== Error Messages (Backend Error Code i18n) ====================
  error: {
    // Common errors
    PARAM_ERROR: 'Parameter error',
    PARAM_MISSING: 'Missing required parameter',
    PARAM_INVALID: 'Invalid parameter format',
    NOT_FOUND: '{name} not found',
    SYSTEM_ERROR: 'System error',
    DATABASE_ERROR: 'Database operation failed',
    NETWORK_ERROR: 'Network error',
    UNKNOWN_ERROR: 'Unknown error',
    // Auth errors
    UNAUTHORIZED: 'Please login first',
    TOKEN_EXPIRED: 'Session expired, please login again',
    TOKEN_INVALID: 'Invalid session',
    PERMISSION_DENIED: 'Permission denied',
    // Captcha errors
    CAPTCHA_EXPIRED: 'Captcha expired, please refresh',
    CAPTCHA_ERROR: 'Incorrect captcha',
    // Department module
    DEPT_NOT_FOUND: 'Department not found',
    DEPT_PARENT_INVALID: 'Cannot set parent to itself',
    DEPT_HAS_CHILDREN: 'Cannot delete: department has children',
    DEPT_HAS_USERS: 'Cannot delete: {count} user(s) in this department',
    // Role module
    ROLE_NOT_FOUND: 'Role not found',
    ROLE_CODE_EXISTS: 'Role code already exists',
    // User module
    USER_NOT_FOUND: 'User not found',
    USER_USERNAME_EXISTS: 'Username already exists',
    USER_PASSWORD_ERROR: 'Invalid username or password',
    USER_DISABLED: 'Account disabled',
    USER_LOCKED: 'Account locked, try again in {minutes} minutes',
    USER_REGISTER_FAIL: 'Registration failed',
    // Dictionary module
    DICT_TYPE_NOT_FOUND: 'Dictionary type not found',
    DICT_TYPE_CODE_EXISTS: 'Dictionary type code already exists',
    DICT_ITEM_NOT_FOUND: 'Dictionary item not found',
    DICT_ITEM_VALUE_DUPLICATE: 'Value already exists in this dictionary type',
    // Audit module
    AUDIT_NOT_MODIFIABLE: 'Audit logs cannot be modified',
    AUDIT_NOT_DELETABLE: 'Audit logs cannot be deleted',
    // Notification module
    NOTIFICATION_NOT_FOUND: 'Notification not found',
    // Customer module
    CUSTOMER_NOT_FOUND: 'Customer not found',
    // Menu module
    MENU_USER_ID_REQUIRED: 'User ID is required',
    // File upload module
    FILE_NOT_EXIST: 'Please select a file to upload',
    FILE_PATH_EMPTY: 'File path cannot be empty',
    FILE_PATH_INVALID: 'Invalid file path',
    FILE_TOO_LARGE: 'File size exceeds limit',
    FILE_TYPE_NOT_ALLOWED: 'File type not allowed',
    FILE_UPLOAD_FAIL: 'File upload failed',
    FILE_DELETE_FAIL: 'File delete failed',
    FILE_LIMIT_EXCEEDED: 'Upload limit exceeded',
    FILE_UNEXPECTED_FIELD: 'Unexpected file field: {field}',
    // GitHub module
    GITHUB_CONFIG_ERROR: 'GitHub config incomplete',
    GITHUB_UPLOAD_FAIL: 'GitHub upload failed: {msg}',
    GITHUB_DELETE_FAIL: 'GitHub delete failed: {msg}',
    GITHUB_API_ERROR: 'GitHub API call failed'
  }
}
