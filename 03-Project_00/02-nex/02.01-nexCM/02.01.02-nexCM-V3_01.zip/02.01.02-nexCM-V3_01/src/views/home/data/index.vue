<template>
  <div class="home-dataview-container">
    <h2>数据管理</h2>
    <p>这里是数据管理页面</p>
  </div>
</template>

<script>
export default {
  name: "DataView",
  components: {},
  data() {
    return {};
  },
  watch: {},
  computed: {},
  methods: {},
  mounted() {},
};
</script>

<style scoped lang="less">
.home-dataview-container {
  padding: 10px;
  h2 {
    padding-bottom: 10px;
  }
}
</style>
