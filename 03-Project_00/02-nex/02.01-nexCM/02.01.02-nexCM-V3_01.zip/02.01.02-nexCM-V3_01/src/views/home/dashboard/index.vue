<template>
  <div class="home-dashview-container">
    <h2>数据看板</h2>
    <p>这里是数据看板页面</p>
  </div>
</template>

<script>
export default {
  name: "DashView",
  components: {},
  data() {
    return {};
  },
  watch: {},
  computed: {},
  methods: {},
  mounted() {},
};
</script>

<style scoped lang="less">
.home-dashview-container {
  padding: 10px;
  h2 {
    padding-bottom: 10px;
  }
}
</style>
