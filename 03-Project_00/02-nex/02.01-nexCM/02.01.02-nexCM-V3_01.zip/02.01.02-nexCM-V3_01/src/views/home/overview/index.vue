<template>
  <div class="overview-container">
    <!-- ========== 第一行：设备状态 + 关键指标 ========== -->
    <el-row :gutter="16" class="top-row">
      <!-- 设备状态大卡片 -->
      <el-col :span="6">
        <div class="status-card" :class="deviceStatus.status">
          <div class="status-icon">
            <i :class="deviceStatus.icon"></i>
          </div>
          <div class="status-info">
            <div class="status-label">设备状态</div>
            <div class="status-value">{{ deviceStatus.text }}</div>
            <div class="status-time">已运行 {{ deviceStatus.duration }}</div>
          </div>
          <div class="status-pulse" v-if="deviceStatus.status === 'running'"></div>
        </div>
      </el-col>

      <!-- 当前运行速度 -->
      <el-col :span="6">
        <div class="metric-card">
          <div class="metric-icon speed">
            <i class="el-icon-speed"></i>
          </div>
          <div class="metric-info">
            <div class="metric-label">当前运行速度</div>
            <div class="metric-value">{{ metrics.currentSpeed }}<span class="metric-unit">瓶/h</span></div>
            <div class="metric-sub">目标：{{ metrics.targetSpeed }} 瓶/h</div>
          </div>
        </div>
      </el-col>

      <!-- 今日产量 -->
      <el-col :span="6">
        <div class="metric-card">
          <div class="metric-icon today">
            <i class="el-icon-date"></i>
          </div>
          <div class="metric-info">
            <div class="metric-label">今日产量</div>
            <div class="metric-value">{{ formatNumber(metrics.todayOutput) }}<span class="metric-unit">瓶</span></div>
            <div class="metric-sub">完成率：{{ metrics.todayRate }}%</div>
          </div>
          <el-progress 
            :percentage="metrics.todayRate" 
            :show-text="false" 
            :stroke-width="6"
            color="#67c23a"
            class="metric-progress"
          />
        </div>
      </el-col>

      <!-- 本班产量 -->
      <el-col :span="6">
        <div class="metric-card">
          <div class="metric-icon shift">
            <i class="el-icon-time"></i>
          </div>
          <div class="metric-info">
            <div class="metric-label">本班产量</div>
            <div class="metric-value">{{ formatNumber(metrics.shiftOutput) }}<span class="metric-unit">瓶</span></div>
            <div class="metric-sub">班次：{{ metrics.shiftName }}</div>
          </div>
        </div>
      </el-col>
    </el-row>

    <!-- ========== 第二行：产量趋势 + 实时报警 ========== -->
    <el-row :gutter="16" class="middle-row">
      <!-- 产量趋势图 -->
      <el-col :span="16">
        <el-card shadow="never" class="chart-card">
          <div slot="header" class="card-header">
            <span class="card-title">24小时产量趋势</span>
            <el-tag size="small" type="info">实时更新</el-tag>
          </div>
          <div class="chart-container">
            <!-- 简单的CSS柱状图模拟 -->
            <div class="bar-chart">
              <div 
                v-for="(item, index) in productionTrend" 
                :key="index" 
                class="bar-item"
              >
                <div class="bar-wrapper">
                  <div 
                    class="bar" 
                    :style="{ height: (item.value / maxTrendValue * 100) + '%' }"
                    :class="{ 'current': index === productionTrend.length - 1 }"
                  ></div>
                </div>
                <div class="bar-label">{{ item.hour }}</div>
              </div>
            </div>
            <div class="chart-legend">
              <span class="legend-item"><span class="legend-dot"></span>每小时产量</span>
              <span class="legend-total">今日总计：{{ formatNumber(metrics.todayOutput) }} 瓶</span>
            </div>
          </div>
        </el-card>
      </el-col>

      <!-- 实时报警列表 -->
      <el-col :span="8">
        <el-card shadow="never" class="alarm-card">
          <div slot="header" class="card-header">
            <span class="card-title">实时报警</span>
            <el-tag size="small" type="danger" v-if="activeAlarms.length > 0">
              {{ activeAlarms.length }} 条活跃
            </el-tag>
            <el-tag size="small" type="success" v-else>正常</el-tag>
          </div>
          <div class="alarm-list">
            <div 
              v-for="(alarm, index) in activeAlarms" 
              :key="index" 
              class="alarm-item"
              :class="alarm.level"
            >
              <div class="alarm-icon">
                <i :class="alarm.icon"></i>
              </div>
              <div class="alarm-content">
                <div class="alarm-title">{{ alarm.title }}</div>
                <div class="alarm-code">代码：{{ alarm.code }}</div>
              </div>
              <div class="alarm-time">{{ alarm.time }}</div>
            </div>
            <div v-if="activeAlarms.length === 0" class="no-alarm">
              <i class="el-icon-circle-check"></i>
              <span>设备运行正常，无报警</span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- ========== 第三行：运行统计 + OEE + 批次 + 累计 ========== -->
    <el-row :gutter="16" class="bottom-row">
      <!-- 设备运行时间统计 -->
      <el-col :span="6">
        <el-card shadow="never" class="stats-card">
          <div slot="header" class="card-header">
            <span class="card-title">今日运行统计</span>
          </div>
          <div class="stats-content">
            <div class="stats-item">
              <div class="stats-label">正常运行</div>
              <div class="stats-value running">{{ runtimeStats.running }}h</div>
            </div>
            <div class="stats-item">
              <div class="stats-label">停机时间</div>
              <div class="stats-value stopped">{{ runtimeStats.stopped }}h</div>
            </div>
            <div class="stats-item">
              <div class="stats-label">故障率</div>
              <div class="stats-value">{{ runtimeStats.faultRate }}%</div>
            </div>
            <el-progress 
              :percentage="runtimeStats.runningRate" 
              :stroke-width="8"
              :format="(percentage) => percentage + '%'"
              color="#67c23a"
            />
          </div>
        </el-card>
      </el-col>

      <!-- OEE综合效率 -->
      <el-col :span="6">
        <el-card shadow="never" class="oee-card">
          <div slot="header" class="card-header">
            <span class="card-title">OEE综合效率</span>
            <el-tag size="small" :type="oeeData.level">{{ oeeData.levelText }}</el-tag>
          </div>
          <div class="oee-content">
            <div class="oee-circle">
              <svg viewBox="0 0 100 100" class="circle-svg">
                <circle cx="50" cy="50" r="40" fill="none" stroke="#ebeef5" stroke-width="8"/>
                <circle 
                  cx="50" cy="50" r="40" fill="none" 
                  :stroke="oeeData.color" 
                  stroke-width="8"
                  stroke-linecap="round"
                  :stroke-dasharray="251.2"
                  :stroke-dashoffset="251.2 * (1 - oeeData.value / 100)"
                  transform="rotate(-90 50 50)"
                />
              </svg>
              <div class="oee-value">{{ oeeData.value }}%</div>
            </div>
            <div class="oee-details">
              <div class="oee-item">
                <span>可用率</span>
                <span class="oee-item-value">{{ oeeData.availability }}%</span>
              </div>
              <div class="oee-item">
                <span>性能率</span>
                <span class="oee-item-value">{{ oeeData.performance }}%</span>
              </div>
              <div class="oee-item">
                <span>合格率</span>
                <span class="oee-item-value">{{ oeeData.quality }}%</span>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>

      <!-- 批次信息 -->
      <el-col :span="6">
        <el-card shadow="never" class="batch-card">
          <div slot="header" class="card-header">
            <span class="card-title">当前批次</span>
            <el-tag size="small" type="primary" v-if="batchInfo.status === 'running'">生产中</el-tag>
            <el-tag size="small" type="info" v-else>待开始</el-tag>
          </div>
          <div class="batch-content">
            <div class="batch-item">
              <span class="batch-label">批次号</span>
              <span class="batch-value">{{ batchInfo.batchNo }}</span>
            </div>
            <div class="batch-item">
              <span class="batch-label">产品名称</span>
              <span class="batch-value">{{ batchInfo.productName }}</span>
            </div>
            <div class="batch-item">
              <span class="batch-label">填充量</span>
              <span class="batch-value">{{ batchInfo.fillVolume }} ml</span>
            </div>
            <div class="batch-item">
              <span class="batch-label">开始时间</span>
              <span class="batch-value">{{ batchInfo.startTime }}</span>
            </div>
            <div class="batch-item">
              <span class="batch-label">已生产</span>
              <span class="batch-value">{{ formatNumber(batchInfo.produced) }} / {{ formatNumber(batchInfo.target) }} 瓶</span>
            </div>
            <el-progress 
              :percentage="batchInfo.progress" 
              :stroke-width="6"
              :show-text="false"
              color="#409eff"
            />
          </div>
        </el-card>
      </el-col>

      <!-- 累计产量 -->
      <el-col :span="6">
        <el-card shadow="never" class="total-card">
          <div slot="header" class="card-header">
            <span class="card-title">累计产量</span>
          </div>
          <div class="total-content">
            <div class="total-main">
              <div class="total-value">{{ formatNumber(totalStats.total) }}</div>
              <div class="total-unit">瓶</div>
            </div>
            <div class="total-divider"></div>
            <div class="total-details">
              <div class="total-item">
                <span class="total-label">本月</span>
                <span class="total-num">{{ formatNumber(totalStats.month) }}</span>
              </div>
              <div class="total-item">
                <span class="total-label">本周</span>
                <span class="total-num">{{ formatNumber(totalStats.week) }}</span>
              </div>
              <div class="total-item">
                <span class="total-label">今日</span>
                <span class="total-num">{{ formatNumber(totalStats.today) }}</span>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
/**
 * 概况预览页面 - 工业设备监控首页
 * 
 * 数据来源说明（PLC地址映射）：
 * - 设备状态：M5001(运行) / M5002(空闲) / M5003(故障)
 * - 当前运行速度：D4010（瓶/小时）
 * - 今日产量：D4004
 * - 本班产量：D4002
 * - 累计总产量：D4000
 * - 实时报警代码：D4012
 * - 报警详情：M4000-M4110（50+种报警标志位）
 * - 每批开始时间：D4014
 * - 每批结束时间：D4016
 * - 今日正常运行时间：D4020
 * - 今日总停机时间：D4022
 * - 填充量目标设置：D4512
 * - 产量趋势图：需要后端定时采集D4004并存储历史数据
 * - OEE综合效率：需要后端计算（运行时间/计划时间 × 性能率 × 合格率）
 */
export default {
  name: 'Overview',
  data() {
    return {
      // 设备状态（对应 M5001/M5002/M5003）
      deviceStatus: {
        status: 'running', // running / idle / fault
        text: '运行中',
        icon: 'el-icon-video-play',
        duration: '6小时32分钟'
      },
      // 关键指标（对应 D4010/D4004/D4002）
      metrics: {
        currentSpeed: 1200,
        targetSpeed: 1500,
        todayOutput: 8560,
        todayRate: 71,
        shiftOutput: 3240,
        shiftName: '白班'
      },
      // 24小时产量趋势（需要后端定时采集存储）
      productionTrend: [
        { hour: '00', value: 0 },
        { hour: '02', value: 0 },
        { hour: '04', value: 0 },
        { hour: '06', value: 120 },
        { hour: '08', value: 850 },
        { hour: '10', value: 1200 },
        { hour: '12', value: 1100 },
        { hour: '14', value: 1350 },
        { hour: '16', value: 1280 },
        { hour: '18', value: 660 },
        { hour: '20', value: 0 },
        { hour: '22', value: 0 }
      ],
      // 实时报警列表（对应 D4012 + M4000-M4110）
      activeAlarms: [
        {
          level: 'warning',
          icon: 'el-icon-warning-outline',
          title: '灌装轴位置异动报警',
          code: 'M4068',
          time: '14:23'
        },
        {
          level: 'info',
          icon: 'el-icon-info',
          title: '真空异常预警',
          code: 'M4020',
          time: '14:15'
        }
      ],
      // 今日运行统计（对应 D4020/D4022）
      runtimeStats: {
        running: 6.5,
        stopped: 0.5,
        faultRate: 2.3,
        runningRate: 92.8
      },
      // OEE综合效率（需要后端计算）
      oeeData: {
        value: 85,
        level: 'success',
        levelText: '良好',
        color: '#67c23a',
        availability: 92.8,
        performance: 94.2,
        quality: 97.5
      },
      // 当前批次信息（对应 D4014/D4016/D4512）
      batchInfo: {
        batchNo: 'B20260824001',
        productName: '卡式瓶灌装',
        fillVolume: 2.0,
        startTime: '08:00:00',
        produced: 3240,
        target: 5000,
        progress: 64.8,
        status: 'running'
      },
      // 累计产量（对应 D4000/D4008/D4006/D4004）
      totalStats: {
        total: 125680,
        month: 28560,
        week: 8960,
        today: 8560
      }
    }
  },
  computed: {
    // 产量趋势图最大值
    maxTrendValue() {
      return Math.max(...this.productionTrend.map(item => item.value), 1)
    }
  },
  methods: {
    // 数字格式化（千分位）
    formatNumber(num) {
      return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
  },
  mounted() {
    // 实际项目中，这里需要：
    // 1. 通过WebSocket连接后端，实时获取PLC数据
    // 2. 定时刷新产量趋势图
    // 3. 监听报警事件，实时更新报警列表
    console.log('[概况预览] 页面已加载，等待接入实时数据')
  }
}
</script>

<style scoped lang="less">
.overview-container {
  padding: 16px;
  background: #f0f2f5;
  min-height: calc(100vh - 84px);
}

// ========== 通用卡片样式 ==========
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  .card-title {
    font-size: 15px;
    font-weight: 600;
    color: #303133;
  }
}

// ========== 第一行：状态 + 指标 ==========
.top-row {
  margin-bottom: 16px;
}

// 设备状态大卡片
.status-card {
  position: relative;
  height: 120px;
  border-radius: 8px;
  padding: 20px;
  display: flex;
  align-items: center;
  overflow: hidden;
  color: #fff;
  transition: all 0.3s;

  &.running {
    background: linear-gradient(135deg, #67c23a 0%, #529b2e 100%);
  }
  &.idle {
    background: linear-gradient(135deg, #909399 0%, #606266 100%);
  }
  &.fault {
    background: linear-gradient(135deg, #f56c6c 0%, #c45656 100%);
  }

  .status-icon {
    font-size: 48px;
    margin-right: 16px;
    opacity: 0.9;
  }
  .status-info {
    flex: 1;
    .status-label {
      font-size: 13px;
      opacity: 0.85;
      margin-bottom: 4px;
    }
    .status-value {
      font-size: 24px;
      font-weight: 700;
      margin-bottom: 4px;
    }
    .status-time {
      font-size: 12px;
      opacity: 0.75;
    }
  }
  // 运行状态脉冲动画
  .status-pulse {
    position: absolute;
    top: 50%;
    right: 30px;
    transform: translateY(-50%);
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #fff;
    animation: pulse 2s infinite;
  }
}

@keyframes pulse {
  0% { box-shadow: 0 0 0 0 rgba(255,255,255,0.7); }
  70% { box-shadow: 0 0 0 15px rgba(255,255,255,0); }
  100% { box-shadow: 0 0 0 0 rgba(255,255,255,0); }
}

// 指标卡片
.metric-card {
  position: relative;
  height: 120px;
  background: #fff;
  border-radius: 8px;
  padding: 20px;
  display: flex;
  align-items: flex-start;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.05);
  transition: all 0.3s;
  overflow: hidden;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 16px 0 rgba(0,0,0,0.08);
  }

  .metric-icon {
    width: 48px;
    height: 48px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: #fff;
    margin-right: 16px;

    &.speed { background: linear-gradient(135deg, #409eff 0%, #337ecc 100%); }
    &.today { background: linear-gradient(135deg, #67c23a 0%, #529b2e 100%); }
    &.shift { background: linear-gradient(135deg, #e6a23c 0%, #b88230 100%); }
  }
  .metric-info {
    flex: 1;
    .metric-label {
      font-size: 13px;
      color: #909399;
      margin-bottom: 8px;
    }
    .metric-value {
      font-size: 24px;
      font-weight: 700;
      color: #303133;
      line-height: 1.2;
      .metric-unit {
        font-size: 13px;
        font-weight: 400;
        color: #909399;
        margin-left: 4px;
      }
    }
    .metric-sub {
      font-size: 12px;
      color: #c0c4cc;
      margin-top: 4px;
    }
  }
  .metric-progress {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
  }
}

// ========== 第二行：趋势图 + 报警 ==========
.middle-row {
  margin-bottom: 16px;
}

.chart-card, .alarm-card {
  height: 320px;
  /deep/ .el-card__body {
    height: calc(100% - 57px);
    padding: 16px;
  }
}

// 产量趋势图
.chart-container {
  height: 100%;
  display: flex;
  flex-direction: column;
  .bar-chart {
    flex: 1;
    display: flex;
    align-items: flex-end;
    justify-content: space-around;
    padding: 10px 0;
    border-bottom: 1px solid #ebeef5;
    .bar-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      width: 6%;
      .bar-wrapper {
        height: 180px;
        display: flex;
        align-items: flex-end;
        .bar {
          width: 100%;
          background: linear-gradient(180deg, #409eff 0%, #66b1ff 100%);
          border-radius: 4px 4px 0 0;
          transition: all 0.3s;
          min-height: 2px;
          &:hover {
            background: linear-gradient(180deg, #337ecc 0%, #409eff 100%);
          }
          &.current {
            background: linear-gradient(180deg, #67c23a 0%, #85ce61 100%);
          }
        }
      }
      .bar-label {
        font-size: 11px;
        color: #909399;
        margin-top: 6px;
      }
    }
  }
  .chart-legend {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 10px;
    .legend-item {
      font-size: 12px;
      color: #606266;
      display: flex;
      align-items: center;
      .legend-dot {
        display: inline-block;
        width: 10px;
        height: 10px;
        background: #409eff;
        border-radius: 2px;
        margin-right: 6px;
      }
    }
    .legend-total {
      font-size: 13px;
      color: #303133;
      font-weight: 600;
    }
  }
}

// 实时报警列表
.alarm-list {
  height: 100%;
  overflow-y: auto;
  .alarm-item {
    display: flex;
    align-items: center;
    padding: 12px;
    border-radius: 6px;
    margin-bottom: 8px;
    background: #f5f7fa;
    transition: all 0.3s;
    &:hover {
      background: #ecf5ff;
    }
    &.danger {
      border-left: 4px solid #f56c6c;
      .alarm-icon { color: #f56c6c; }
    }
    &.warning {
      border-left: 4px solid #e6a23c;
      .alarm-icon { color: #e6a23c; }
    }
    &.info {
      border-left: 4px solid #409eff;
      .alarm-icon { color: #409eff; }
    }
    .alarm-icon {
      font-size: 20px;
      margin-right: 12px;
    }
    .alarm-content {
      flex: 1;
      .alarm-title {
        font-size: 13px;
        color: #303133;
        font-weight: 500;
        margin-bottom: 2px;
      }
      .alarm-code {
        font-size: 11px;
        color: #909399;
      }
    }
    .alarm-time {
      font-size: 12px;
      color: #c0c4cc;
    }
  }
  .no-alarm {
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #67c23a;
    i {
      font-size: 48px;
      margin-bottom: 12px;
    }
    span {
      font-size: 14px;
    }
  }
}

// ========== 第三行：统计卡片 ==========
.bottom-row {
  .stats-card, .oee-card, .batch-card, .total-card {
    height: 280px;
    /deep/ .el-card__body {
      height: calc(100% - 57px);
      padding: 16px;
    }
  }
}

// 运行统计
.stats-content {
  height: 100%;
  display: flex;
  flex-direction: column;
  .stats-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    .stats-label {
      font-size: 13px;
      color: #606266;
    }
    .stats-value {
      font-size: 18px;
      font-weight: 700;
      color: #303133;
      &.running { color: #67c23a; }
      &.stopped { color: #f56c6c; }
    }
  }
  .el-progress {
    margin-top: auto;
  }
}

// OEE效率
.oee-content {
  height: 100%;
  display: flex;
  align-items: center;
  .oee-circle {
    position: relative;
    width: 120px;
    height: 120px;
    margin-right: 16px;
    .circle-svg {
      width: 100%;
      height: 100%;
    }
    .oee-value {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-size: 24px;
      font-weight: 700;
      color: #303133;
    }
  }
  .oee-details {
    flex: 1;
    .oee-item {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
      border-bottom: 1px dashed #ebeef5;
      font-size: 13px;
      color: #606266;
      &:last-child { border-bottom: none; }
      .oee-item-value {
        font-weight: 600;
        color: #303133;
      }
    }
  }
}

// 批次信息
.batch-content {
  height: 100%;
  display: flex;
  flex-direction: column;
  .batch-item {
    display: flex;
    justify-content: space-between;
    padding: 6px 0;
    font-size: 13px;
    .batch-label {
      color: #909399;
    }
    .batch-value {
      color: #303133;
      font-weight: 500;
    }
  }
  .el-progress {
    margin-top: auto;
  }
}

// 累计产量
.total-content {
  height: 100%;
  display: flex;
  flex-direction: column;
  .total-main {
    text-align: center;
    padding: 10px 0;
    .total-value {
      font-size: 32px;
      font-weight: 700;
      color: #409eff;
      line-height: 1.2;
    }
    .total-unit {
      font-size: 14px;
      color: #909399;
      margin-top: 4px;
    }
  }
  .total-divider {
    height: 1px;
    background: #ebeef5;
    margin: 12px 0;
  }
  .total-details {
    flex: 1;
    .total-item {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
      .total-label {
        font-size: 13px;
        color: #909399;
      }
      .total-num {
        font-size: 14px;
        font-weight: 600;
        color: #303133;
      }
    }
  }
}
</style>
