/**
 * ==========================================
 * 中文语言包
 * ==========================================
 * 按模块分组，新增文案在此添加
 * 结构与 en-US.js 保持一致
 */
export default {
  // ==================== 通用 ====================
  common: {
    confirm: '确定',
    cancel: '取消',
    save: '保存',
    delete: '删除',
    edit: '编辑',
    add: '新增',
    search: '搜索',
    reset: '重置',
    export: '导出',
    exportExcel: '导出Excel',
    exportPdf: '导出PDF',
    selected: '已选中',
    import: '导入',
    // 导出 PDF 副标题标签
    exportLabels: {
      exporter: '导出人',
      time: '导出时间',
      countPrefix: '共',
      countSuffix: '条记录'
    },
    refresh: '刷新',
    operation: '操作',
    status: '状态',
    index: '序号',
    sort: '排序',
    description: '描述',
    remark: '备注',
    enable: '启用',
    disable: '禁用',
    createTime: '创建时间',
    updateTime: '更新时间',
    loading: '加载中...',
    success: '操作成功',
    failed: '操作失败',
    tip: '提示',
    warning: '警告',
    error: '错误',
    untitled: '未命名',
    redirect: '重定向',
    systemName: 'nexCM 标准Web版',
    systemDESC: '桌面式灌装加塞设备',
    electronicSignature: '电子签名',
    featureComingSoon: '功能开发中',
    noDataToExport: '没有可导出的数据',
    operator: '操作人',
    reason: '操作原因',
    reasonPlaceholder: '请输入操作原因（GMP要求）',
    reasonRequired: '请填写操作原因',
    reasonMinLength: '操作原因至少2个字符',
    password: '密码',
    passwordPlaceholder: '请输入密码进行电子签名',
    passwordRequired: '请输入密码',
    sessionTimeout: '会话超时，请重新登录'
  },

  // ==================== 登录页 ====================
  login: {
    title: '欢迎登录',
    username: '用户名',
    password: '密码',
    captcha: '验证码',
    loginBtn: '登 录',
    registerBtn: '注 册',
    registerTitle: '注册账号',
    email: '邮箱',
    confirmPassword: '确认密码',
    hasAccount: '已有账号？',
    loginNow: '立即登录',
    noAccount: '还没有账号？',
    registerNow: '立即注册',
    usernameRequired: '用户名不能为空',
    passwordRequired: '密码不能为空',
    captchaRequired: '验证码不能为空',
    emailRequired: '邮箱不能为空',
    confirmPasswordRequired: '请再次输入密码',
    registerSuccess: '注册成功，请登录'
  },

  // ==================== 布局 ====================
  layout: {
    // 网站首页
    home: '网站首页',
    homeOverview: '概况预览',
    homeDashboard: '数据看板',
    homeData: '数据管理',

    // 设备管理
    deviceManagement: '设备管理',
    deviceState: '设备状态',
    alarmLog: '报警统计',
    partLife: '部件寿命',

    // 生产管理
    productionManagement: '生产管理',
    recipeManagement: '配方管理',
    orderManagement: '订单管理',

    // 系统配置 
    systemSettings: '系统设置',
    dictManagement: '数据字典',
    roleManagement: '角色管理',
    deptManagement: '部门管理',
    userManagement: '用户管理',
    auditLog: '审计追踪',
    systemConfig: '参数配置',

    // 个人中心
    profile: '个人中心',

    // 通知中心
    notificationCenter: '通知中心',

    // 退出登录
    logout: '退出登录',

    // 用户
    user: '用户',

    // 搜索
    searchMenu: '搜索菜单...',

    // 面包屑
    tagsView: {
      refresh: '刷新',
      close: '关闭',
      closeOthers: '关闭其他',
      closeLeft: '关闭左侧',
      closeRight: '关闭右侧',
      closeAll: '关闭全部'
    }
  },

  // ==================== 数据字典 ====================
  dict: {
    typeList: '字典类型',
    itemList: '字典项',
    typeName: '类型名称',
    typeCode: '类型编码',
    typeCodePlaceholder: '字母开头，如 user_status',
    itemLabel: '标签',
    itemValue: '值',
    itemValuePlaceholder: '如 1/0',
    itemStatus: '状态',
    addType: '新增字典类型',
    editType: '编辑字典类型',
    addItem: '新增字典项',
    editItem: '编辑字典项',
    typeNameRequired: '请输入字典类型名称',
    typeCodeRequired: '请输入字典类型编码',
    itemLabelRequired: '请输入字典标签',
    itemValueRequired: '请输入字典值',
    deleteTypeConfirm: '确定删除该字典类型吗？将同时删除所有字典项',
    deleteItemConfirm: '确定删除该字典项吗？'
  },

  // ==================== 角色管理 ====================
  role: {
    title: '角色管理',
    roleName: '角色名称',
    roleCode: '角色编码',
    dataScope: '数据范围',
    dataScopeAll: '全部数据',
    dataScopeDept: '本部门',
    dataScopeDeptAndChild: '本部门及子部门',
    dataScopeSelf: '仅本人',
    permission: '权限',
    permissionTitle: '菜单权限分配',
    permissionSuccess: '权限分配成功',
    addRole: '新增角色',
    editRole: '编辑角色',
    roleNameRequired: '请输入角色名称',
    roleCodeRequired: '请输入角色编码',
    deleteConfirm: '确定删除该角色吗？'
  },

  // ==================== 部门管理 ====================
  dept: {
    title: '部门管理',
    deptName: '部门名称',
    orderNum: '排序',
    leader: '负责人',
    phone: '联系电话',
    email: '邮箱',
    parentDept: '上级部门',
    addChild: '新增子部门',
    addDept: '新增部门',
    editDept: '编辑部门',
    deptNameRequired: '请输入部门名称',
    deleteConfirm: '确定删除该部门吗？'
  },

  // ==================== 通知中心 ====================
  notification: {
    title: '通知中心',
    center: '通知中心',
    viewAll: '查看全部',
    type: '类型',
    content: '内容',
    markAllRead: '全部已读',
    all: '全部',
    unread: '未读',
    read: '已读',
    markRead: '标记已读',
    empty: '暂无通知',
    typeSystem: '系统通知',
    typePlc: 'PLC通知',
    typeUser: '用户通知',
    typeAudit: '审计通知',
    markReadSuccess: '标记成功',
    markAllSuccess: '全部标记成功',
    deleteConfirm: '确定删除该通知吗？',
    justNow: '刚刚',
    minutesAgo: '分钟前',
    hoursAgo: '小时前',
    daysAgo: '天前'
  },

  // ==================== 错误页 ====================
  error: {
    notFound: '页面不存在',
    backHome: '返回首页',
    back: '返回上一页',
    countdown: '页面将在 {count} 秒后自动返回首页',
    forbidden: '抱歉，您没有访问权限',
    forbiddenDesc: '该页面需要特定权限才能访问，请联系管理员',
    forbiddenTitle: '无权限'
  },

  // ==================== 首页 ====================
  home: {
    welcome: '欢迎使用',
    admin: '管理员'
  },

  // ==================== 主题设置 ====================
  theme: {
    quickMenu: '快捷菜单',
    palette: '主题调色',
    language: '语言切换',
    resetAll: '恢复全部默认',
    reset: '恢复默认',
    custom: '自定义',
    switchedToZh: '已切换为中文',
    switchedToEn: 'Switched to English',
    sidebarBg: '侧边栏背景颜色',
    sidebarHoverText: '侧边栏悬停文字',
    sidebarHoverBg: '侧边栏悬停背景',
    sidebarIconColor: '侧边栏图标颜色',
    sidebarActiveBg: '选中菜单背景'
  },

  // ==================== 个人中心 ====================
  profile: {
    title: '个人中心',
    basicInfo: '基本信息',
    username: '用户名',
    realName: '真实姓名',
    sex: '性别',
    email: '邮箱',
    phone: '手机号',
    role: '角色',
    status: '状态',
    createTime: '创建时间',
    sexMale: '男',
    sexFemale: '女',
    sexUnknown: '未知',
    roleAdministrator: '管理员',
    roleEngineer: '工程师',
    roleOperator: '操作员',
    statusEnabled: '启用',
    statusDisabled: '禁用',
    changePassword: '修改密码',
    oldPassword: '原密码',
    newPassword: '新密码',
    confirmPassword: '确认密码'
  },

  // ==================== 用户管理 ====================
  user: {
    title: '用户管理',
    username: '用户名',
    password: '密码',
    realName: '真实姓名',
    sex: '性别',
    sexUnknown: '未知',
    sexMale: '男',
    sexFemale: '女',
    email: '邮箱',
    phone: '手机号',
    role: '角色',
    dept: '部门',
    status: '状态',
    createTime: '创建时间',
    operation: '操作',
    addUser: '新增用户',
    editUser: '编辑用户',
    enable: '启用',
    disable: '禁用',
    resetPassword: '重置密码',
    remark: '备注',
    roleAdministrator: '管理员',
    roleEngineer: '工程师',
    roleOperator: '操作员',
    usernamePlaceholder: '请输入用户名',
    passwordPlaceholder: '请输入密码',
    realNamePlaceholder: '请输入姓名',
    emailPlaceholder: '请输入邮箱',
    phonePlaceholder: '请输入手机号',
    rolePlaceholder: '请选择角色',
    deptPlaceholder: '请选择部门',
    remarkPlaceholder: '请输入备注',
    usernameLength: '长度在 2 到 50 个字符',
    passwordLength: '长度在 6 到 32 个字符',
    emailInvalid: '请输入正确的邮箱地址',
    deleteConfirm: '确认删除用户「{name}」吗？',
    batchDeleteConfirm: '确认删除选中的 {count} 个用户吗？',
    deleteSuccess: '删除成功',
    batchDeleteSuccess: '批量删除成功',
    exportFileName: '用户列表',
    resetPasswordTitle: '重置密码',
    resetPasswordPlaceholder: '请输入新密码',
    resetPasswordError: '密码长度 6-20 位',
    resetPasswordSuccess: '密码重置成功'
  },

  // ==================== 审计追踪 ====================
  audit: {
    title: '审计追踪',
    myTitle: '我的操作记录',
    userName: '操作人',
    action: '操作类型',
    target: '操作对象',
    oldValue: '修改前',
    newValue: '修改后',
    result: '结果',
    success: '成功',
    failed: '失败',
    ip: 'IP地址',
    createdAt: '操作时间',
    timeRange: '时间范围',
    startTime: '开始时间',
    endTime: '结束时间'
  },

  // ==================== 参数配置 ====================
  systemConfig: {
    title: '参数配置',
    desc: '自定义系统参数，包括系统设置、安全设置、设备连接、导出配置等',
    save: '保存配置',
    reset: '恢复默认',
    saveSuccess: '配置保存成功',
    resetSuccess: '已恢复默认配置',
    resetConfirm: '确定要恢复默认配置吗？',
    loadFailed: '加载配置失败',
    saveFailed: '保存配置失败',
    resetFailed: '重置配置失败',
    system: {
      title: '系统设置',
      sessionTimeout: '会话超时时间',
      minutes: '分钟',
      defaultPageSize: '默认每页条数',
      defaultLanguage: '默认语言',
      dateFormat: '日期格式'
    },
    security: {
      title: '安全设置',
      watermarkEnabled: '启用水印',
      watermarkText: '水印文字',
      watermarkPlaceholder: '为空时自动使用当前用户名'
    },
    plc: {
      title: '设备连接',
      protocol: '通信协议',
      host: '设备IP地址',
      port: '设备端口',
      unitId: '单元ID',
      pollFast: '快速轮询间隔',
      pollSlow: '慢速轮询间隔'
    },
    export: {
      title: '导出设置',
      pdfWatermarkEnabled: 'PDF导出水印',
      pdfWatermarkText: 'PDF水印文字',
      pdfWatermarkPlaceholder: '为空时自动使用当前用户名'
    },
    connection: {
      title: '连接设置',
      heartbeatInterval: '心跳间隔'
    }
  },

  // ==================== 授权管理 ====================
  license: {
    importTitle: '授权导入',
    manageTitle: '授权管理',
    statusValid: '授权有效',
    statusInvalid: '授权失效',
    statusChecking: '授权查询中',
    statusCheckingTip: '请稍等...，努力查询中',
    statusTrial: '试用授权',
    statusFormal: '正式授权',
    statusPermanent: '永久授权',
    licenseFile: '授权文件',
    importLicense: '导入授权',
    importSuccess: '授权导入成功',
    importFailed: '授权导入失败',
    selectFile: '选择授权文件',
    dragFileHere: '将授权文件拖到此处，或',
    clickUpload: '点击上传',
    fileFormatTip: '仅支持 .lic 格式的授权文件',
    noLicense: '尚未导入授权文件',
    licenseInfo: '授权信息',
    customerName: '客户名称',
    projectName: '项目名称',
    licenseType: '授权类型',
    expireTime: '过期时间',
    machineId: '机器ID',
    machineBind: '机器绑定',
    timeGuard: '时间防护',
    syncTime: '联网校准',
    syncTimeSuccess: '时间校准成功',
    syncTimeFailed: '时间校准失败',
    downloadLicense: '下载授权文件',
    downloadFailed: '下载失败',
    copyMachineId: '复制机器ID',
    copySuccess: '复制成功',
    features: '功能模块',
    issuedAt: '签发时间',
    notBound: '未绑定',
    // 新增 - 参数配置页面授权管理
    refresh: '刷新',
    download: '下载授权',
    remaining: '剩余',
    detailTitle: '授权详细信息',
    licenseId: '授权ID',
    projectId: '项目ID',
    contact: '联系人',
    phone: '联系电话',
    email: '邮箱',
    maxUsers: '最大用户数',
    allFeatures: '全部功能',
    currentMachineId: '当前机器ID',
    boundMachineId: '绑定机器ID',
    notBoundAny: '未绑定（任意机器可用）',
    matchStatus: '匹配状态',
    matched: '匹配',
    notMatched: '不匹配',
    timeGuardStatus: '时间守卫',
    enabled: '已启用',
    notInitialized: '未初始化',
    lastVerified: '上次验证',
    serverTime: '服务器时间',
    networkDiagnosis: '联网诊断',
    fileInfo: '授权文件信息',
    filePath: '文件路径',
    fileName: '文件名',
    fileSize: '文件大小',
    lastModified: '最后修改',
    noLicenseFile: '授权文件不存在，请先导入授权文件',
    importDialogTitle: '导入授权文件',
    importTip: '请上传由 Beehive 授权管理系统签发的 .lic 授权文件',
    dragUpload: '将 .lic 文件拖到此处，或点击上传',
    cancel: '取消',
    confirmImport: '确认导入',
    networkDiagnosisSuccess: '联网诊断成功',
    networkDiagnosisFailed: '联网诊断失败，请检查网络连接',
    // 授权导入页面
    brandTitle: '软件授权管理',
    brandDesc: 'Beehive License Manager',
    featureRsa: 'RSA 非对称签名',
    featureTimeGuard: '防时间回退',
    featureMachineBind: '机器指纹绑定',
    importFormTitle: '导入授权文件',
    dragUploadTip: '将 .lic 授权文件拖到此处，或点击上传',
    fileSizeTip: '仅支持 .lic 格式的授权文件，最大 1MB',
    remove: '移除',
    importSuccessTitle: '授权导入成功',
    project: '项目',
    unlimited: '不限',
    enterSystem: '进入系统',
    refreshStatus: '刷新状态',
    cannotGetStatus: '无法获取授权状态，请检查后端服务',
    pleaseSelectFile: '请先选择授权文件',
    permanentValid: '永久有效',
    typeTrial: '试用版',
    typeStandard: '标准版',
    typeEnterprise: '企业版',
    typePerpetual: '永久版',
    // 授权失效原因
    reasonFileNotFound: '授权文件不存在或验证失败',
    reasonProjectMismatch: '授权项目不匹配',
    reasonMachineMismatch: '授权文件与当前机器不匹配（硬件绑定）',
    reasonExpired: '授权已过期',
    reasonMissingFeatures: '缺少功能授权',
    reasonTimeRollback: '检测到时间回退，请校准系统时间',
    reasonNetworkSyncFailed: '联网校准失败，请检查网络连接',
    reasonUnknown: '授权验证失败',
    // 机器码
    copy: '复制',
    copyFailed: '复制失败',
    machineIdTip: '如需授权，请将此机器码提供给供应商'
  }
}
