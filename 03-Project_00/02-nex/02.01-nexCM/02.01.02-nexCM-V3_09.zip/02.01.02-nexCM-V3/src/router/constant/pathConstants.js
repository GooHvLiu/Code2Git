/**
 * ==========================================
 * 路由路径常量
 * ==========================================
 * 所有页面跳转、菜单配置、标签页中的路径统一从这里引用
 * 避免 '/home'、'/login' 等字符串散落在多个文件中
 */

/** 路由路径常量 */
export const ROUTE_PATHS = {
  /** 根路径 */
  ROOT: '/',
  /** 登录页 */
  LOGIN: '/login',
  /** 首页 */
  HOME: '/home',
  /** 个人中心 */
  PROFILE: '/profile',
  /** 404 页面 */
  NOT_FOUND: '/404',
  /** 403 无权限页面 */
  FORBIDDEN: '/403',
  /** 路由重定向页（无刷新重载用） */
  REDIRECT: '/redirect',
  /** 授权导入页（软件授权失效时跳转，无需登录） */
  LICENSE_IMPORT: '/license/import',
  /** 授权管理页 */
  LICENSE_MANAGE: '/license/manage',
  /** 首页 - 概况预览（用于首页固定标签） */
  HOME_OVERVIEW: '/home/overview',
  /** 菜单配置预览页（独立窗口，无需登录布局） */
  MENU_CONFIG_PREVIEW: '/menu-config/preview'
}

/** 首页固定标签（TagsView 首页不可关闭） */
export const HOME_TAG = {
  title: 'layout.home.overview.default',
  path: ROUTE_PATHS.HOME_OVERVIEW,
  icon: 'home'
}
