-- 备份代码：
mysqldump -h 127.0.0.1 -u root -p --default-character-set=utf8mb4 --set-gtid-purged=OFF --routines --triggers --events --result-file="F:\CodingMan\Code2Git\03-Project_00\02-nex\02.02-nexSM\02.02.02-nexSM-V2\test\sql\init.sql" nexsm_v2_dev
