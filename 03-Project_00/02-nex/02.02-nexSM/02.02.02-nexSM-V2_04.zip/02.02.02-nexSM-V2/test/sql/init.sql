-- MySQL dump 10.13  Distrib 9.7.0, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: nexsm_v2_dev
-- ------------------------------------------------------
-- Server version	9.7.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nex_audit_log`
--

DROP TABLE IF EXISTS `nex_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nex_audit_log` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int NOT NULL COMMENT '操作人ID',
  `user_name` varchar(50) DEFAULT '' COMMENT '操作人姓名',
  `action` varchar(100) NOT NULL COMMENT '操作类型',
  `target` varchar(200) DEFAULT '' COMMENT '操作对象',
  `old_value` text COMMENT '修改前值',
  `new_value` text COMMENT '修改后值',
  `result` varchar(20) DEFAULT 'success' COMMENT '操作结果',
  `reason` varchar(500) DEFAULT '' COMMENT '操作原因',
  `ip` varchar(50) DEFAULT '' COMMENT '操作IP',
  `user_agent` varchar(500) DEFAULT '' COMMENT '浏览器UA',
  `prev_hash` varchar(64) DEFAULT '' COMMENT '前一条哈希',
  `current_hash` varchar(64) DEFAULT '' COMMENT '当前哈希',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='审计日志表(GMP 21CFR Part 11)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nex_audit_log`
--

LOCK TABLES `nex_audit_log` WRITE;
/*!40000 ALTER TABLE `nex_audit_log` DISABLE KEYS */;
INSERT INTO `nex_audit_log` VALUES (1,2,'liuguohui','PLC参数修改','fillVolume (灌装体积(mL))','156','156','success','','127.0.0.1','PostmanRuntime-ApipostRuntime/1.1.0','','','2026-08-20 15:01:42'),(2,2,'liuguohui','PLC参数修改','fillVolume (灌装体积(mL))','156','158','success','','127.0.0.1','PostmanRuntime-ApipostRuntime/1.1.0','','','2026-08-20 15:01:48');
/*!40000 ALTER TABLE `nex_audit_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_audit_log_no_update` BEFORE UPDATE ON `nex_audit_log` FOR EACH ROW BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '审计日志不允许修改';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_audit_log_no_delete` BEFORE DELETE ON `nex_audit_log` FOR EACH ROW BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '审计日志不允许删除';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `nex_menu`
--

DROP TABLE IF EXISTS `nex_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nex_menu` (
  `id` varchar(32) NOT NULL COMMENT '菜单唯一标识 index值',
  `parent_id` varchar(32) DEFAULT '' COMMENT '父菜单ID，顶级菜单为空',
  `name` varchar(50) NOT NULL COMMENT '路由name（组件name）',
  `path` varchar(100) NOT NULL COMMENT '前端路由path',
  `component` varchar(100) DEFAULT NULL COMMENT '前端组件名称 Layout / customer/visit',
  `redirect` varchar(100) DEFAULT 'noRedirect',
  `title` varchar(50) NOT NULL COMMENT '菜单标题',
  `title_en` varchar(100) DEFAULT NULL COMMENT '英文标题',
  `icon` varchar(50) DEFAULT NULL COMMENT '图标名称',
  `hidden` tinyint DEFAULT '0' COMMENT '是否隐藏菜单 0显示 1隐藏',
  `always_show` tinyint DEFAULT '0' COMMENT '是否永远展示父菜单（有子菜单时生效）',
  `no_cache` tinyint DEFAULT '0' COMMENT '是否不缓存页面',
  `sort` int DEFAULT '0' COMMENT '排序号',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nex_menu`
--

LOCK TABLES `nex_menu` WRITE;
/*!40000 ALTER TABLE `nex_menu` DISABLE KEYS */;
INSERT INTO `nex_menu` VALUES ('_001','','Customer','/customer',NULL,'noRedirect','客户管理','Customer','customer',0,1,0,1,'2026-08-16 12:46:11'),('_001_01','_001','Customer','customer',NULL,'noRedirect','客户档案','Customer Profile','#',0,0,0,1,'2026-08-16 12:20:00'),('_001_02','_001','Visit','visit',NULL,'noRedirect','拜访记录','Visit Records','#',0,0,0,2,'2026-08-16 12:20:01'),('_002','','Business','/business',NULL,'noRedirect','修养预约','Appointment','appointment',0,0,0,2,'2026-08-16 12:20:02'),('_002_01','_002','Appointment','appointment',NULL,'noRedirect','预约信息','Appointment Info','#',0,0,0,1,'2026-08-16 12:20:02'),('_002_02','_002','Service','service',NULL,'noRedirect','服务项目','Service Items','#',0,0,0,2,'2026-08-16 12:20:03'),('_002_03','_002','Statement','statement',NULL,'noRedirect','结算单据','Settlement','#',0,0,0,3,'2026-08-16 12:20:04'),('_003','','Flow','/flow',NULL,'noRedirect','流程管理','Flow','flow',0,0,0,3,'2026-08-16 12:46:11'),('_003_01','_003','Definition','definition',NULL,'noRedirect','流程定义','Flow Definition','#',0,0,0,1,'2026-08-16 12:20:05'),('_003_02','_003','Approve','approve',NULL,'noRedirect','审核流程','Approval Flow','#',0,0,0,2,'2026-08-16 12:20:08');
/*!40000 ALTER TABLE `nex_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nex_user`
--

DROP TABLE IF EXISTS `nex_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nex_user` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '数据库自增主键（接口对外映射为userId）',
  `username` varchar(50) NOT NULL COMMENT '登录账号(唯一)',
  `password` varchar(100) NOT NULL COMMENT 'bcrypt加密后的密码',
  `role` varchar(50) DEFAULT 'operator' COMMENT '岗位类别：administrator管理员 / engineer工程师 / operator操作员',
  `real_name` varchar(50) DEFAULT 'operator' COMMENT '用户真实姓名',
  `sex` tinyint DEFAULT '0' COMMENT '性别 1男 2女 0未知',
  `phone` varchar(20) DEFAULT '' COMMENT '联系手机号',
  `email` varchar(100) DEFAULT '' COMMENT '邮箱地址',
  `dept_id` int DEFAULT NULL COMMENT '所属部门ID，关联nex_dept表',
  `avatar` varchar(255) DEFAULT '' COMMENT '头像地址',
  `login_ip` varchar(50) DEFAULT '' COMMENT '最后登录IP',
  `login_date` datetime DEFAULT NULL COMMENT '最后登录时间',
  `remark` varchar(500) DEFAULT '' COMMENT '备注信息',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '账号状态：1启用 0禁用',
  `is_delete` tinyint NOT NULL DEFAULT '0' COMMENT '软删除：0正常 1删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(50) DEFAULT '' COMMENT '创建人账号',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_by` varchar(50) DEFAULT '' COMMENT '更新人账号',
  `is_first_login` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否首次登录 1是 0否',
  `first_login_at` datetime DEFAULT NULL COMMENT '首次登录时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_dept` (`dept_id`),
  KEY `idx_status_del` (`status`,`is_delete`),
  CONSTRAINT `chk_is_delete` CHECK ((`is_delete` in (0,1))),
  CONSTRAINT `chk_role` CHECK ((`role` in (_utf8mb4'administrator',_utf8mb4'engineer',_utf8mb4'operator'))),
  CONSTRAINT `chk_sex` CHECK ((`sex` in (0,1,2))),
  CONSTRAINT `chk_status` CHECK ((`status` in (0,1)))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统用户表 | nex 管理平台';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nex_user`
--

LOCK TABLES `nex_user` WRITE;
/*!40000 ALTER TABLE `nex_user` DISABLE KEYS */;
INSERT INTO `nex_user` VALUES (1,'admin','$2b$10$lI1m4nPUhnYEBSvHjoSIzu10hVhNjy.y6X3EJCuMy8HexrRXgw4.u','administrator','系统管理员',1,'13800000001','admin@nexcm.com',100,'administrator','127.0.0.1','2026-08-16 20:42:31','超级管理员',1,0,'2026-07-28 18:57:46','admin','2026-08-16 20:42:31','',0,NULL),(2,'liuguohui','$2b$10$lI1m4nPUhnYEBSvHjoSIzu10hVhNjy.y6X3EJCuMy8HexrRXgw4.u','administrator','刘国辉',1,'13800000002','liu@nexcm.com',100,'administrator','127.0.0.1','2026-08-20 15:47:56','设备负责人',1,0,'2026-07-28 18:57:46','admin','2026-08-20 15:47:55','',0,NULL),(3,'engineer01','$2b$10$lI1m4nPUhnYEBSvHjoSIzu10hVhNjy.y6X3EJCuMy8HexrRXgw4.u','engineer','王强',1,'13800000003','wang@nexcm.com',101,'engineer','192.168.1.105','2026-07-25 08:15:00','设备工程师',1,0,'2026-07-28 18:57:46','liuguohui','2026-08-11 10:11:53','',0,NULL),(5,'operator02','$2b$10$lI1m4nPUhnYEBSvHjoSIzu10hVhNjy.y6X3EJCuMy8HexrRXgw4.u','operator','李泽楷',1,'13800000005','li@nexcm.com',102,'operator','192.168.1.110','2026-06-30 16:20:00','已离职',0,0,'2026-07-28 18:57:46','liuguohui','2026-08-11 10:11:53','',0,NULL),(6,'engineer02','$2a$10$J6K/o9sRQNVZD1LGkpT.metMC16.NS26O0DUaAx6peVqqximnuA.O','operator','张海琪',0,'15898785847','engineer123456@test.com',NULL,'operator','127.0.0.1','2026-08-20 15:41:23','',1,0,'2026-08-16 18:29:21','','2026-08-20 15:41:23','',1,NULL);
/*!40000 ALTER TABLE `nex_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nex_user_menu`
--

DROP TABLE IF EXISTS `nex_user_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nex_user_menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL COMMENT '用户id',
  `menu_id` varchar(32) NOT NULL COMMENT '菜单id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nex_user_menu`
--

LOCK TABLES `nex_user_menu` WRITE;
/*!40000 ALTER TABLE `nex_user_menu` DISABLE KEYS */;
INSERT INTO `nex_user_menu` VALUES (21,1,'_001'),(22,1,'_001_01'),(23,1,'_001_02'),(24,1,'_002'),(25,1,'_002_01'),(26,1,'_002_02'),(27,1,'_002_03'),(28,1,'_003'),(29,1,'_003_01'),(30,1,'_003_02'),(31,2,'_001'),(32,2,'_001_01'),(33,2,'_001_02'),(34,2,'_002'),(35,2,'_002_01'),(36,2,'_002_02'),(37,2,'_002_03'),(38,2,'_003'),(39,2,'_003_01'),(40,2,'_003_02'),(41,3,'_002'),(42,3,'_002_01'),(43,3,'_002_02'),(44,3,'_002_03'),(45,3,'_003'),(46,3,'_003_01'),(47,3,'_003_02'),(48,4,'_002'),(49,4,'_002_01'),(50,4,'_002_02'),(51,4,'_002_03'),(52,6,'_001'),(53,6,'_001_01'),(54,6,'_001_02'),(55,6,'_002'),(56,6,'_002_01'),(57,6,'_002_02'),(58,6,'_002_03'),(59,6,'_003'),(60,6,'_003_01'),(61,6,'_003_02');
/*!40000 ALTER TABLE `nex_user_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'nexsm_v2_dev'
--

--
-- Dumping routines for database 'nexsm_v2_dev'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-20 17:03:51
