/**
 * 用户模块 - 控制器层
 * 负责参数接收、调用service、返回响应
 * 参数校验全部由 validate 中间件在路由层完成，这里不做格式校验
 *
 * 【审计日志】通过 auditLogger 统一记录，不直接引用 audit.service
 */
const userService = require('./user.service');
const auditLogger = require('../audit/auditLogger');
const { comparePassword } = require('../../utils/password');

class UserController {
  /**
   * 用户登录
   */
  async login(req, res, next) {
    try {
      const { username, password } = req.body;
      const ip = req.ip || req.connection.remoteAddress;
      const userAgent = req.headers['user-agent'] || '';
      const result = await userService.login(username, password, ip, userAgent);
      res.success(result, '登录成功');
    } catch (err) {
      next(err);
    }
  }

  /**
   * 用户注册（公开接口）
   */
  async register(req, res, next) {
    try {
      const result = await userService.register(req.body);
      // 记录注册审计
      await auditLogger.logUserRegister(req, '系统注册', `用户名: ${req.body.username || ''}`)
      res.success(result, '注册成功');
    } catch (err) {
      next(err);
    }
  }

  /**
   * 获取当前登录用户信息
   */
  async getCurrentUser(req, res, next) {
    try {
      const userInfo = await userService.getUserById(req.user.id);
      res.success(userInfo);
    } catch (err) {
      next(err);
    }
  }

  /**
   * 分页查询用户列表
   */
  async getUserList(req, res, next) {
    try {
      const result = await userService.getUserList(req.query);
      res.success(result);
    } catch (err) {
      next(err);
    }
  }

  /**
   * 获取用户详情
   */
  async getUserDetail(req, res, next) {
    try {
      const userInfo = await userService.getUserById(req.params.id);
      res.success(userInfo);
    } catch (err) {
      next(err);
    }
  }

  /**
   * 新增用户
   */
  async createUser(req, res, next) {
    try {
      const result = await userService.createUser(req.body);
      // 记录审计（易读文本格式，避免密码等敏感信息泄露）
      const statusText = req.body.status === 0 ? '禁用' : '启用'
      const newValueText = `用户名: ${req.body.username}, 角色: ${req.body.role}, 姓名: ${req.body.real_name || ''}, 状态: ${statusText}`
      await auditLogger.logUserCreate(req, req.body.username || '', newValueText)
      res.success(result, '新增用户成功');
    } catch (err) {
      next(err);
    }
  }

  /**
   * 更新用户
   */
  async updateUser(req, res, next) {
    try {
      // 获取修改前的数据
      const oldUser = await userService.getUserById(req.params.id).catch(() => null)
      await userService.updateUser(req.params.id, req.body);
      // 记录审计（易读文本格式）
      const oldStatusText = oldUser?.status === 0 ? '禁用' : '启用'
      const newStatusText = req.body.status !== undefined ? (req.body.status === 0 ? '禁用' : '启用') : '未变更'
      const oldValueText = oldUser ? `角色: ${oldUser.role}, 姓名: ${oldUser.real_name || ''}, 状态: ${oldStatusText}` : ''
      const newValueText = `角色: ${req.body.role || '未变更'}, 姓名: ${req.body.real_name || '未变更'}, 状态: ${newStatusText}`
      await auditLogger.logUserUpdate(req, oldUser?.username || req.params.id, oldValueText, newValueText)
      res.success(null, '更新用户成功');
    } catch (err) {
      next(err);
    }
  }

  /**
   * 删除用户（GMP：需电子签名密码验证）
   */
  async deleteUser(req, res, next) {
    try {
      // 电子签名：验证当前用户密码
      const { password } = req.body
      if (!password) {
        return res.error('电子签名：请输入密码确认')
      }
      const passwordValid = await userService.verifyPassword(req.user.id, password)
      if (!passwordValid) {
        return res.error('电子签名失败：密码错误')
      }

      const oldUser = await userService.getUserById(req.params.id).catch(() => null)
      await userService.deleteUser(req.params.id);
      // 记录审计（易读文本格式，避免密码等敏感信息泄露）
      const statusText = oldUser?.status === 0 ? '禁用' : '启用'
      const oldValueText = oldUser ? `用户名: ${oldUser.username}, 角色: ${oldUser.role}, 姓名: ${oldUser.real_name || ''}, 状态: ${statusText}` : ''
      await auditLogger.logUserDelete(req, oldUser?.username || req.params.id, oldValueText)
      res.success(null, '删除用户成功');
    } catch (err) {
      next(err);
    }
  }

  /**
   * 批量删除用户（GMP：需电子签名密码验证）
   */
  async batchDeleteUsers(req, res, next) {
    try {
      // 电子签名：验证当前用户密码
      const { password } = req.body
      if (!password) {
        return res.error('电子签名：请输入密码确认')
      }
      const passwordValid = await userService.verifyPassword(req.user.id, password)
      if (!passwordValid) {
        return res.error('电子签名失败：密码错误')
      }

      await userService.batchDeleteUsers(req.body.ids);
      // 记录审计
      await auditLogger.logUserBatchDelete(req, `ID: ${(req.body.ids || []).join(', ')}`, '')
      res.success(null, '批量删除成功');
    } catch (err) {
      next(err);
    }
  }

  /**
   * 修改用户状态
   */
  async updateUserStatus(req, res, next) {
    try {
      const oldUser = await userService.getUserById(req.params.id).catch(() => null)
      await userService.updateUserStatus(req.params.id, req.body.status);
      // 记录审计
      await auditLogger.logUserStatusChange(
        req,
        oldUser?.username || req.params.id,
        oldUser?.status !== undefined ? String(oldUser.status) : '',
        String(req.body.status)
      )
      res.success(null, '状态修改成功');
    } catch (err) {
      next(err);
    }
  }
}

module.exports = new UserController();
