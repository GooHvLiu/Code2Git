/**
 * 审计日志模块 - 业务逻辑层
 * GMP 21CFR Part 11 电子记录合规
 * 特性：哈希链防篡改、只增不改不删
 */
const auditModel = require('./audit.model');

class AuditService {
  /**
   * 创建审计日志（自动计算哈希链）
   * @param {Object} log - 日志信息
   */
  async create(log) {
    try {
      const data = {
        user_id: log.userId || 0,
        user_name: log.userName || '',
        action: log.action || '',
        target: log.target || '',
        old_value: log.oldValue !== undefined ? log.oldValue : '',
        new_value: log.newValue !== undefined ? log.newValue : '',
        result: log.result || 'success',
        reason: log.reason || '',
        ip: log.ip || '',
        user_agent: log.userAgent || '',
        created_at: new Date()
      }
      return await auditModel.insertWithHash(data)
    } catch (err) {
      console.error('[审计日志] 写入失败:', err.message)
      // 审计日志写入失败不影响主业务，但记录错误
      return null
    }
  }

  /**
   * 分页查询审计日志
   */
  async query(params = {}) {
    return await auditModel.queryLogs(params);
  }

  /**
   * 查询指定用户的操作记录
   */
  async queryByUser(userId, params = {}) {
    return await auditModel.queryLogs({ ...params, userId });
  }

  /**
   * 查询指定操作类型的记录
   */
  async queryByAction(action, params = {}) {
    return await auditModel.queryLogs({ ...params, action });
  }

  /**
   * 校验哈希链完整性（GMP 合规要求）
   * 验证所有审计日志是否被篡改
   */
  async verifyIntegrity() {
    return await auditModel.verifyHashChain()
  }
}

module.exports = new AuditService();
