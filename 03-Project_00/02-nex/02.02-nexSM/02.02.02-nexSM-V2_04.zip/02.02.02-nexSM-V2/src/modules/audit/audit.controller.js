/**
 * 审计日志模块 - 控制器层
 */
const auditService = require('./audit.service');

class AuditController {
  /**
   * 分页查询审计日志
   * GET /prod-api/v2/audit/list
   */
  async getList(req, res, next) {
    try {
      const result = await auditService.query(req.query);
      res.success(result, '查询成功');
    } catch (err) {
      next(err)
    }
  }

  /**
   * 查询当前用户的操作记录
   * GET /prod-api/v2/audit/my
   */
  async getMyLogs(req, res, next) {
    try {
      const userId = req.user?.id || req.user?.userId;
      const result = await auditService.queryByUser(userId, req.query);
      res.success(result, '查询成功');
    } catch (err) {
      next(err)
    }
  }

  /**
   * 校验哈希链完整性（管理员）
   * GET /prod-api/v2/audit/verify
   */
  async verifyIntegrity(req, res, next) {
    try {
      const result = await auditService.verifyIntegrity();
      res.success(result, result.valid ? '哈希链完整，数据未被篡改' : '检测到数据被篡改');
    } catch (err) {
      next(err)
    }
  }
}

module.exports = new AuditController();
