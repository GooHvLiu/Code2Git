/**
 * 通用业务逻辑基类
 * 所有业务 Service 继承此类，封装通用 CRUD 操作
 * 子类可以重写方法以实现特殊业务逻辑
 * 注意：数据库只存储国际化 key，翻译由前端处理，不使用 JSON 多语言字段
 */
const { BusinessError } = require('../middleware/error.middleware')
const { ERROR_CODE } = require('../constants/errorCode')

class BaseService {
  /**
   * 构造函数
   * @param {Object} model 数据模型实例（继承自 BaseModel）
   * @param {Object} options 配置选项
   * @param {string} options.name 模块名称，用于错误提示
   */
  constructor(model, options = {}) {
    this.model = model
    this.name = options.name || '数据'
  }

  /**
   * 分页查询列表
   * @param {Object} params 查询参数（page, pageSize, 筛选条件）
   * @returns {Promise<Object>} { list, total, page, pageSize }
   */
  async getList(params = {}) {
    const where = this.buildWhere(params)
    const orderBy = params.orderBy || 'id'
    const orderDir = params.orderDir || 'DESC'
    return await this.model.getPageList(params, where, orderBy, orderDir)
  }

  /**
   * 获取所有数据（下拉选择用）
   * @returns {Promise<Array>}
   */
  async getAll() {
    return await this.model.findAll({}, 'id', 'ASC')
  }

  /**
   * 根据 ID 获取详情
   * @param {number|string} id 主键值
   * @returns {Promise<Object>}
   */
  async getById(id) {
    const data = await this.model.getById(id)
    if (!data) {
      throw new BusinessError(ERROR_CODE.NOT_FOUND, null, { name: this.name })
    }
    return data
  }

  /**
   * 创建数据
   * @param {Object} data 创建数据
   * @returns {Promise<Object>} { insertId, affectedRows }
   */
  async create(data) {
    return await this.model.create(data)
  }

  /**
   * 更新数据
   * @param {number|string} id 主键值
   * @param {Object} data 更新数据
   * @returns {Promise<void>}
   */
  async update(id, data) {
    await this.getById(id)
    await this.model.update(id, data)
  }

  /**
   * 删除数据
   * @param {number|string} id 主键值
   * @returns {Promise<void>}
   */
  async delete(id) {
    await this.getById(id)
    await this.model.delete(id)
  }

  /**
   * 批量删除
   * @param {Array} ids 主键数组
   * @returns {Promise<Object>} { affectedRows }
   */
  async batchDelete(ids = []) {
    if (!Array.isArray(ids) || ids.length === 0) {
      throw new BusinessError(ERROR_CODE.PARAM_MISSING, null)
    }
    return await this.model.batchDelete(ids)
  }

  /**
   * 构建查询条件（子类可重写）
   * @param {Object} params 查询参数
   * @returns {Object} where 条件
   */
  buildWhere(params = {}) {
    return {}
  }
}

module.exports = BaseService
