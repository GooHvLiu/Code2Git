/**
 * 用户管理模块 - 业务逻辑层
 * 
 * 处理用户的登录、注册、增删改查、密码重置、状态变更等业务逻辑
 * 包含登录失败锁定、电子签名密码验证、审计日志记录等特殊功能
 * 继承 BaseService，复用通用 CRUD 操作
 * 
 * @author nexCM Team
 * @date 2026-01-01
 * @lastModified 2026-08-22
 */
const BaseService = require('../../services/BaseService')
const userModel = require('./user.model')
const { hashPassword, comparePassword } = require('../../utils/password')
const { generateToken } = require('../../utils/jwt')
const { BusinessError } = require('../../middleware/error.middleware')
const { ERROR_CODE } = require('../../constants/errorCode')
const { getExcludedRoleCodes, getRoleByCode } = require('../../utils/roleContext')
const { USER_STATUS, USER_ROLE } = require('../../constants/statusCode')
const CaptchaService = require('../captcha/captcha.service')
const audit = require('../../utils/audit')
const { triggerNotification } = require('../../utils/notification')
const configService = require('../config/config.service')
const permissionService = require('../permission/permission.service')
const wsManager = require('../../socket/wsManager')
const notificationService = require('../notification/notification.service')
const userDeviceService = require('./userDevice.service')
const emailService = require('../email/email.service')
const fs = require('fs')
const { LicenseGuard } = require('../../../beehive/sdk')
const licenseConfig = require('../../config/license.config')

// 密码重置验证码存储（内存Map）
const resetCodeStore = new Map()

// 创建授权验证实例（用于获取授权文件中的 maxDevices）
let licenseGuardInstance = null
function getLicenseGuard() {
  if (!licenseGuardInstance) {
    licenseGuardInstance = new LicenseGuard({
      projectId: licenseConfig.projectId,
      publicKey: fs.readFileSync(licenseConfig.publicKeyPath, 'utf8'),
      licensePath: licenseConfig.licensePath,
      timeGuardPath: licenseConfig.timeGuardPath,
      licenseServerUrl: licenseConfig.licenseServerUrl,
      strictMode: licenseConfig.strictMode
    })
  }
  return licenseGuardInstance
}

// 登录失败锁定默认配置（实际值从数据库配置读取）
const DEFAULT_MAX_LOGIN_ATTEMPTS = 5       // 默认最大失败次数
const DEFAULT_LOCK_DURATION_MINUTES = 30   // 默认锁定时长（分钟）

class UserService extends BaseService {
  /**
   * 构造函数
   * 初始化 BaseService，传入用户模型和配置
   */
  constructor() {
    super(userModel, {
      name: '用户',
      langFields: [] // 用户模块没有需要多语言处理的字段
    })
  }

  // ==================== 特殊功能方法 ====================

  /**
   * 用户登录
   * 
   * 包含账户锁定检查、密码校验、登录失败次数统计、Token 生成、登录信息更新、审计日志记录
   * 连续失败 5 次会锁定账户 30 分钟
   * 
   * @param {string} username - 用户名
   * @param {string} password - 密码（明文）
   * @param {string} ip - 登录 IP 地址
   * @param {string} [userAgent=''] - 浏览器 User-Agent
   * @param {string} [lang='zh-CN'] - 语言代码
   * @returns {Promise<Object>} { token, userInfo }
   * @throws {BusinessError} 用户不存在/账号禁用/密码错误/账户锁定
   * 
   * @example
   * const result = await userService.login('admin', '123456', '127.0.0.1', 'Mozilla/5.0')
   * console.log(result.token) // JWT Token
   * console.log(result.userInfo) // 用户信息（不含密码）
   */
  async login(username, password, ip, userAgent = '', lang = 'zh-CN', deviceId = '', deviceName = '') {
    // 1. 查询用户（关联角色表获取角色信息）
    const user = await userModel.getByUsernameWithRole(username)
    if (!user) {
      // 记录登录失败审计
      await audit.log({ userId: 0, userName: username, ip, userAgent }, {
        action: audit.ACTION.USER_LOGIN_FAILED,
        target: '系统登录',
        result: 'failed',
        reason: '用户不存在'
      })
      throw new BusinessError(ERROR_CODE.USER_NOT_FOUND, null)
    }

    // 2. 检查账户是否被锁定（从数据库读取 lock_until）
    if (user.lock_until && new Date(user.lock_until) > new Date()) {
      const remainMin = Math.ceil((new Date(user.lock_until) - new Date()) / 60000)
      throw new BusinessError(ERROR_CODE.USER_LOCKED, null, { minutes: remainMin })
    }

    // 3. 从数据库配置读取登录失败次数阈值和锁定时长
    let maxAttempts = DEFAULT_MAX_LOGIN_ATTEMPTS
    let lockDurationMinutes = DEFAULT_LOCK_DURATION_MINUTES
    try {
      const thresholdValue = await configService.getConfigValue('loginFailedThreshold', DEFAULT_MAX_LOGIN_ATTEMPTS)
      if (thresholdValue) {
        const val = Number(thresholdValue)
        if (!isNaN(val) && val >= 1 && val <= 20) {
          maxAttempts = val
        }
      }
      const durationValue = await configService.getConfigValue('lockDurationMinutes', DEFAULT_LOCK_DURATION_MINUTES)
      if (durationValue) {
        const val = Number(durationValue)
        if (!isNaN(val) && val >= 1 && val <= 1440) {
          lockDurationMinutes = val
        }
      }
    } catch (err) {
      console.warn('[登录] 读取登录配置失败，使用默认值:', err.message)
    }

    // 3. 校验状态
    if (user.status === USER_STATUS.DISABLED) {
      await audit.log({ userId: user.id, userName: user.username, ip, userAgent }, {
        action: audit.ACTION.USER_LOGIN_FAILED,
        target: '系统登录',
        result: 'failed',
        reason: '账号已禁用'
      })
      throw new BusinessError(ERROR_CODE.USER_DISABLED, null)
    }

    // 3. 校验密码
    const passwordValid = await comparePassword(password, user.password)
    if (!passwordValid) {
      // 记录失败次数（数据库存储）
      const attempts = await userModel.incrementFailedAttempts(user.id)

      let reason = '密码错误'
      if (attempts >= maxAttempts) {
        // 锁定账户（写入数据库）
        const lockUntil = new Date(Date.now() + lockDurationMinutes * 60 * 1000)
        await userModel.updateLockStatus(user.id, lockUntil, '连续登录失败 ' + attempts + ' 次')
        reason = '密码错误 ' + attempts + ' 次，账户已锁定 ' + lockDurationMinutes + ' 分钟'

        // 记录账户锁定审计日志
        try {
          await audit.log({ userId: user.id, userName: user.username, ip, userAgent }, {
            action: audit.ACTION.USER_LOGIN_FAILED,
            target: '账户锁定',
            result: 'locked',
            reason: reason
          })
        } catch (auditErr) {
          console.warn('[登录] 记录账户锁定审计日志失败:', auditErr.message)
        }

        // 触发通知：用户登录失败达到阈值（通知管理员）
        triggerNotification('user.login.failed', {
          username: user.username,
          count: attempts,
          ip: ip
        }, user.id).catch(err => {
          console.error('[登录失败] 触发通知失败:', err)
        })
      }

      try {
        await audit.log({ userId: user.id, userName: user.username, ip, userAgent }, {
          action: audit.ACTION.USER_LOGIN_FAILED,
          target: '系统登录',
          result: 'failed',
          reason
        })
      } catch (auditErr) {
        console.warn('[登录] 记录登录失败审计日志失败:', auditErr.message)
      }
      throw new BusinessError(ERROR_CODE.USER_PASSWORD_ERROR, reason, { reason: reason })
    }

    // 登录成功，清除失败次数和锁定状态（数据库存储）
    await userModel.clearFailedAttemptsAndLock(user.id)

    // 3.4 单点登录：先把当前用户的所有旧设备设置为离线（确保设备数检查准确）
    try {
      await userDeviceService.setAllDevicesOffline(user.id)
    } catch (err) {
      console.error('[登录-单点登录] 设置旧设备离线失败:', err.message)
    }

    // 3.5 客户端授权：检查整个系统在线设备数是否达到上限
    // 最大在线设备数从授权文件 license.lic 中读取（0表示不限制）
    let maxDevices = 0
    try {
      const guard = getLicenseGuard()
      const licenseResult = await guard.check()
      if (licenseResult.valid && licenseResult.licenseData) {
        maxDevices = Number(licenseResult.licenseData.maxDevices) || 0
      }
    } catch (err) {
      console.error('[登录-客户端授权] 读取授权文件失败:', err.message)
    }
    const loginCheck = await userDeviceService.checkLoginAllowed(maxDevices)
    if (!loginCheck.allowed) {
      throw new BusinessError(
        ERROR_CODE.DEVICE_LIMIT_EXCEEDED,
        `在线设备数已达上限（最多 ${loginCheck.maxDevices} 台），请联系管理员踢掉其他设备`,
        { currentCount: loginCheck.currentCount, maxDevices: loginCheck.maxDevices }
      )
    }

    // 4. 原子递增 Token 版本号（单点登录：旧 Token 立即失效）
    const tokenVersion = await userModel.incrementTokenVersion(user.id)

    // 5. 生成token（包含 token_version，用于单点登录踢人校验）
    const token = generateToken({
      id: user.id,
      username: user.username,
      realName: user.real_name,
      role: user.role,
      dept_id: user.dept_id || null,
      token_version: tokenVersion
    })

    // 5.1 单点登录：推送被踢下线通知给该用户的其他在线设备（旧 Token 立即失效）
    // 同时创建通知记录到通知中心
    // 只有当该用户有其他在线连接时，才推送被踢下线通知和创建通知记录
    const loginTime = new Date().toISOString()
    const onlineConnectionCount = wsManager.getUserConnectionCount(user.id)
    if (onlineConnectionCount > 0) {
      try {
        // WebSocket 实时推送 kicked_out 消息（用于前端立即跳转登录页）
        wsManager.sendToUser(user.id, {
          type: 'kicked_out',
          message: '您已在其他设备登录，当前设备已下线',
          data: {
            userId: user.id,
            username: user.username,
            loginIp: ip,
            loginTime: loginTime
          }
        })

        // 创建通知记录到通知中心（被踢下线通知）
        await notificationService.sendNotification({
          userId: user.id,
          titleKey: 'notification.kickedOutTitle',
          contentKey: 'notification.kickedOutContent',
          contentParams: JSON.stringify({ time: loginTime, ip: ip }),
          type: 'security',
          priority: 'high'
        })
      } catch (err) {
        console.error('[登录] 推送被踢通知/创建通知记录失败:', err.message)
      }
    } else {
    }

    // 5.2 安全通知：用户登录成功通知已去掉（不在通知规则配置清单内）
    // 如需恢复，请取消下方注释并在 notificationRules.config.js 中添加 user.login.success 规则

    // 6. 更新登录信息
    await userModel.updateLoginInfo(user.id, ip)

    // 6.1 客户端授权：记录设备信息（用于在线设备管理和限制）
    // 只有当 deviceId 存在时才记录（前端会生成 deviceId 并存储在 localStorage）
    if (deviceId) {
      try {
        await userDeviceService.upsertDevice({
          userId: user.id,
          deviceId: deviceId,
          deviceName: deviceName || '',
          ip: ip,
          userAgent: userAgent
        })
      } catch (err) {
        console.error('[登录-客户端授权] 记录设备信息失败:', err.message)
      }
    }

    // 6. 记录登录成功审计
    await audit.log({ userId: user.id, userName: user.username, ip, userAgent }, {
      action: audit.ACTION.USER_LOGIN,
      target: '系统登录',
      result: 'success'
    })

    // 8. 返回用户信息（去掉密码）
    const { password: _, ...userInfo } = user

    // 8.1 附加角色属性（role_level/is_super_admin/is_builtin/visible_role_levels，数据库字段驱动）
    try {
      const roleCtx = await getRoleByCode(user.role)
      if (roleCtx) {
        userInfo.role_level = roleCtx.role_level
        userInfo.is_super_admin = roleCtx.is_super_admin ? 1 : 0
        userInfo.is_builtin = roleCtx.is_builtin ? 1 : 0
        userInfo.visible_role_levels = roleCtx.visible_role_levels
      }
    } catch (err) {
      console.error('[登录] 加载角色上下文失败:', err.message)
    }

    // 9. 查询用户权限码列表和权限版本号
    const permissions = await permissionService.getUserPermissions(user.id)
    const permissionVersion = await permissionService.getUserPermissionVersion(user.id)

    return {
      token,
      userInfo,
      permissions,
      permissionVersion
    }
  }

  /**
   * 用户注册（公开接口）
   * 
   * 校验验证码后创建用户，默认角色为 operator，状态启用
   * 
   * @param {Object} data - 注册数据
   * @param {string} data.username - 用户名
   * @param {string} data.password - 密码（明文）
   * @param {string} data.email - 邮箱
   * @param {string} [data.code] - 验证码
   * @param {string} [data.uuid] - 验证码 UUID
   * @returns {Promise<Object>} { id }
   * @throws {BusinessError} 验证码错误/用户名已存在
   */
  async register(data) {
    // 1. 校验验证码
    if (data.code && data.uuid) {
      const captchaResult = CaptchaService.verifyCaptcha(data.code, data.uuid)
      if (captchaResult.code !== ERROR_CODE.SUCCESS) {
        throw new BusinessError(captchaResult.code, captchaResult.msg)
      }
    }

    // 2. 调用 createUser（默认角色 operator，状态启用）
    const result = await this.createUser({
      username: data.username,
      password: data.password,
      email: data.email,
      role: USER_ROLE.OPERATOR,
      status: USER_STATUS.ENABLED
    })

    // 3. 触发通知：新用户注册（通知管理员）
    triggerNotification('user.register', { username: data.username }, result.id).catch(err => {
      console.error('[用户注册] 触发通知失败:', err)
    })

    return result
  }

  // ==================== 通用 CRUD 方法（保留原有方法名，内部调用父类方法） ====================

  /**
   * 分页查询用户列表（关联部门表获取部门名称）
   * 
   * 支持按用户名、角色、状态筛选，自动去掉密码字段
   * 
   * @param {Object} params - 查询参数
   * @param {number} [params.page=1] - 页码
   * @param {number} [params.pageSize=10] - 每页数量
   * @param {string} [params.username] - 用户名（模糊查询）
   * @param {string} [params.role] - 角色
   * @param {number} [params.status] - 状态 1启用 0禁用
   * @param {string} [lang='zh-CN'] - 语言代码
   * @param {Object} [currentUser] - 当前登录用户（用于判断是否过滤隐藏角色的用户）
   * @returns {Promise<Object>} { list, total, page, pageSize }
   */
  async getUserList(params, lang = 'zh-CN', currentUser = null) {
    const page = parseInt(params.page) || 1
    const pageSize = parseInt(params.pageSize) || 10

    // 根据当前用户的 visible_role_levels 字段，过滤不可见角色的用户（数据库字段驱动）
    const excludeRoles = await getExcludedRoleCodes(currentUser)

    const result = await userModel.getUserListWithDept(params, page, pageSize, excludeRoles)

    // 去掉密码字段，避免敏感信息泄露
    result.list = result.list.map(item => {
      const { password, ...rest } = item
      return rest
    })

    return result
  }

  /**
   * 获取单个用户详情（关联部门表获取部门名称）
   * 
   * 自动去掉密码字段
   * 
   * @param {number} id - 用户 ID
   * @param {string} [lang='zh-CN'] - 语言代码
   * @returns {Promise<Object>} 用户信息（不含密码）
   * @throws {BusinessError} 用户不存在
   */
  async getUserById(id, lang = 'zh-CN') {
    const user = await userModel.getByIdWithDept(id)
    if (!user) {
      throw new BusinessError(ERROR_CODE.USER_NOT_FOUND, null)
    }
    const { password, ...userInfo } = user
    // 附加角色属性（数据库字段驱动，供前端做角色等级/超级管理员判断）
    try {
      const roleCtx = await getRoleByCode(user.role)
      if (roleCtx) {
        userInfo.role_level = roleCtx.role_level
        userInfo.is_super_admin = roleCtx.is_super_admin ? 1 : 0
        userInfo.is_builtin = roleCtx.is_builtin ? 1 : 0
        userInfo.visible_role_levels = roleCtx.visible_role_levels
      }
    } catch (err) {
      console.error('[用户详情] 加载角色上下文失败:', err.message)
    }
    return userInfo
  }

  /**
   * 批量获取用户详情
   * 
   * @param {Array<number>} idArray - 用户 ID 数组
   * @returns {Promise<Array>} 用户信息数组（不含密码）
   */
  async getUserByIdArray(idArray) {
    // 批量查询 -> 用户数组
    const userList = await userModel.getByIdArray(idArray)
    // 校验：非数组 / 空数组 直接返回空数组
    if (!Array.isArray(userList) || userList.length === 0) return []
    // 剔除密码字段，返回干净数组
    const safeUserList = userList.map(user => {
      const { password, ...userInfo } = user
      return userInfo
    })
    return safeUserList
  }

  /**
   * 新增用户
   * 
   * 检查用户名是否已存在，加密密码，默认启用状态
   * 
   * @param {Object} data - 用户数据
   * @param {string} data.username - 用户名（唯一）
   * @param {string} data.password - 密码（明文，会自动加密）
   * @param {string} data.role - 角色
   * @param {string} [data.real_name] - 真实姓名
   * @param {number} [data.status=1] - 状态 1启用 0禁用
   * @returns {Promise<Object>} { id }
   * @throws {BusinessError} 用户名已存在
   */
  async createUser(data) {
    // 检查用户名是否存在
    const existUser = await userModel.getByUsername(data.username)
    if (existUser) {
      throw new BusinessError(ERROR_CODE.USER_USERNAME_EXISTS, null)
    }

    // 加密密码
    if (data.password) {
      data.password = await hashPassword(data.password)
    }

    // 默认启用状态
    if (data.status === undefined) {
      data.status = USER_STATUS.ENABLED
    }

    const result = await userModel.create(data)
    return {
      id: result.insertId
    }
  }

  /**
   * 更新用户
   * 
   * 检查用户是否存在，如果修改密码需要重新加密
   * 
   * @param {number} id - 用户 ID
   * @param {Object} data - 更新数据
   * @param {string} [data.password] - 新密码（明文，会自动加密）
   * @returns {Promise<void>}
   * @throws {BusinessError} 用户不存在
   */
  async updateUser(id, data) {
    // 检查用户是否存在
    const user = await userModel.getById(id)
    if (!user) {
      throw new BusinessError(ERROR_CODE.USER_NOT_FOUND, null)
    }

    // 如果修改密码，需要加密
    if (data.password) {
      data.password = await hashPassword(data.password)
    }

    await userModel.update(id, data)
  }

  /**
   * 删除用户
   * 
   * @param {number} id - 用户 ID
   * @returns {Promise<void>}
   * @throws {BusinessError} 用户不存在
   */
  async deleteUser(id) {
    const user = await userModel.getById(id)
    if (!user) {
      throw new BusinessError(ERROR_CODE.USER_NOT_FOUND, null)
    }

    await userModel.delete(id)
  }

  /**
   * 批量删除用户
   * 
   * @param {Array<number>} ids - 用户 ID 数组
   * @returns {Promise<void>}
   * @throws {BusinessError} 请选择要删除的用户
   */
  async batchDeleteUsers(ids) {
    if (!ids || ids.length === 0) {
      throw new BusinessError(ERROR_CODE.PARAM_MISSING, null)
    }
    await userModel.batchDelete(ids)
  }

  /**
   * 修改用户状态
   * 
   * @param {number} id - 用户 ID
   * @param {number} status - 状态 1启用 0禁用
   * @returns {Promise<void>}
   * @throws {BusinessError} 用户不存在
   */
  async updateUserStatus(id, status) {
    const user = await userModel.getById(id)
    if (!user) {
      throw new BusinessError(ERROR_CODE.USER_NOT_FOUND, null)
    }

    await userModel.update(id, { status })
  }

  // ==================== 密码重置功能 ====================

  /**
   * 管理员重置用户密码
   */
  async resetPassword(id, newPassword, lang, operator) {
    const user = await userModel.getById(id)
    if (!user) {
      throw new BusinessError(ERROR_CODE.USER_NOT_FOUND, null)
    }
    if (!newPassword || newPassword.length < 8) {
      throw new BusinessError(ERROR_CODE.PARAM_ERROR, null)
    }
    const hashedPassword = await hashPassword(newPassword)
    await userModel.update(id, { password: hashedPassword })
    if (user.email) {
      try {
        await emailService.sendTemplate('passwordReset', {
          type: 'adminReset',
          username: user.username,
          newPassword: newPassword,
          operator: operator?.username || '系统管理员'
        }, { to: user.email })
      } catch (err) {
        console.error('[密码重置] 发送邮件失败:', err.message)
      }
    }
    return { id: user.id, username: user.username, email: user.email }
  }

  /**
   * 发送忘记密码验证码
   */
  async sendResetPasswordCode(username, email, lang) {
    const user = await userModel.getByUsername(username)
    if (!user) {
      throw new BusinessError(ERROR_CODE.USER_NOT_FOUND, null)
    }
    if (!user.email || user.email !== email) {
      throw new BusinessError(ERROR_CODE.PARAM_ERROR, null)
    }
    const code = Math.floor(100000 + Math.random() * 900000).toString()
    const expireAt = Date.now() + 15 * 60 * 1000
    const key = username + ':' + email
    resetCodeStore.set(key, { code, expireAt })
    try {
      await emailService.sendTemplate('passwordReset', {
        type: 'forgotPassword',
        username: user.username,
        resetCode: code,
        expireMinutes: 15
      }, { to: user.email })
    } catch (err) {
      console.error('[忘记密码] 发送验证码邮件失败:', err.message)
      throw new BusinessError(ERROR_CODE.SYSTEM_ERROR, null)
    }
  }

  /**
   * 验证验证码并重置密码
   */
  async resetPasswordByCode(username, email, code, newPassword, lang) {
    const user = await userModel.getByUsername(username)
    if (!user) {
      throw new BusinessError(ERROR_CODE.USER_NOT_FOUND, null)
    }
    if (!user.email || user.email !== email) {
      throw new BusinessError(ERROR_CODE.PARAM_ERROR, null)
    }
    const key = username + ':' + email
    const stored = resetCodeStore.get(key)
    if (!stored) {
      throw new BusinessError(ERROR_CODE.PARAM_ERROR, null)
    }
    if (stored.expireAt < Date.now()) {
      resetCodeStore.delete(key)
      throw new BusinessError(ERROR_CODE.PARAM_ERROR, null)
    }
    if (stored.code !== code) {
      throw new BusinessError(ERROR_CODE.PARAM_ERROR, null)
    }
    if (!newPassword || newPassword.length < 8) {
      throw new BusinessError(ERROR_CODE.PARAM_ERROR, null)
    }
    const hashedPassword = await hashPassword(newPassword)
    await userModel.update(user.id, { password: hashedPassword })
    resetCodeStore.delete(key)
    try {
      await emailService.sendTemplate('passwordReset', {
        type: 'resetSuccess',
        username: user.username
      }, { to: user.email })
    } catch (err) {
      console.error('[密码重置] 发送通知邮件失败:', err.message)
    }
    return { id: user.id, username: user.username, email: user.email }
  }

  /**
   * 管理员解锁用户
   * @param {number} userId - 用户ID
   * @param {Object} operator - 操作人信息 { id, username, ip, userAgent }
   * @returns {Promise<void>}
   */
  async unlockUser(userId, operator) {
    const user = await userModel.getById(userId)
    if (!user) {
      throw new BusinessError(ERROR_CODE.USER_NOT_FOUND, null)
    }
    if (!user.lock_until || new Date(user.lock_until) <= new Date()) {
      throw new BusinessError(ERROR_CODE.USER_NOT_LOCKED, null)
    }
    
    // 解锁用户
    await userModel.unlockUser(userId)
    
    // 记录解锁审计日志
    try {
      await audit.log({ userId: operator.id, userName: operator.username, ip: operator.ip, userAgent: operator.userAgent }, {
        action: 'USER_UNLOCK',
        target: '账户解锁',
        result: 'success',
        reason: '管理员手动解锁用户 ' + user.username
      })
    } catch (auditErr) {
      console.warn('[用户解锁] 记录审计日志失败:', auditErr.message)
    }
    
    return { id: user.id, username: user.username }
  }
}
module.exports = new UserService()
